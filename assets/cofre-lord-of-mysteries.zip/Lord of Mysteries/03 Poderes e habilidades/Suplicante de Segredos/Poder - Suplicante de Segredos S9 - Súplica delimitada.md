---
titulo: "Poder - Suplicante de Segredos S9 - Súplica delimitada"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Suplicante de Segredos"
sequencia: 9
nome_pacote: "Pacote de Suplicante de Segredos — Suplicante de Segredos S9"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Suplicante de Segredos S9 - Súplica delimitada

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Suplicante de Segredos, Suplicante de Segredos S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Suplicante de Segredos - Suplicante de Segredos]] ou melhor no [[Caminho do Suplicante de Segredos]]. **Referência nominal:** Secrets Suppliant. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Misticismo inquietante:** Reconhece ritos expostos de sacrifício e espíritos. Revelação vedada continua perigosa e não vira informação gratuita.

## Técnicas adquiridas

### Ler símbolo

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Examine inscrição ritual e descubra função provável e um cuidado de execução. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Preparar oferenda

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

Uma correspondência pertinente fornece +2 ao próximo teste de ritual que já possa executar; não substitui fórmula.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Sondar influência

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Verifique se um vestígio mantém conexão externa, sem contatar sua fonte. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S8 permite abrir escuta; ouvir não garante que uma voz seja confiável.

## Preparação e oposição

Purificação, recusa de pactos e exposição da fonte dos sussurros. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Suplicante de Segredos]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
