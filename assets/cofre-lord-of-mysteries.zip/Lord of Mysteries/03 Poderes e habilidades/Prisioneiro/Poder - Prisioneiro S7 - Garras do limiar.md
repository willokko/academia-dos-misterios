---
titulo: "Poder - Prisioneiro S7 - Garras do limiar"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Prisioneiro"
sequencia: 7
nome_pacote: "Pacote de Lobisomem — Prisioneiro S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Prisioneiro S7 - Garras do limiar

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Lobisomem, Prisioneiro S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Prisioneiro - Lobisomem]] ou melhor no [[Caminho do Prisioneiro]]. **Referência nominal:** Werewolf. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Forma lupina:** Pode manifestar garras e sentidos de lobo; +2 a rastrear pelo cheiro. Sua presença deixa marcas físicas.

## Técnicas adquiridas

### Transformação lupina

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

Manifeste corpo lupino pela cena: ataque corporal DES+VIG contra DEF, RA+15 físicos. Não ganha PV ou outra ação.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Regeneração do lobo

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Instantânea |
| Teste | Automático |

Recupere 20 PV próprios. Não devolve da morte e não apaga maldição.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Resistir à leitura

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

Uma divinação contra você exige AST+VON oposto à sua VON+VON enquanto sustenta a forma.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 conserva as ferramentas e muda a maldição; controlar-se precisa de preparo, não repetição de violência.

## Preparação e oposição

Recipientes preparados, purificação e reconhecimento da âncora. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Prisioneiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
