---
titulo: "Sequência 3 - Aprendiz - Andarilho"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 3
nome_ingles: "Wanderer"
---

# Sequência 3 - Aprendiz - Andarilho

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 3. **Nome de referência:** Wanderer. Tradução editorial: Andarilho.

## O que a poção transforma

O [[Poder - Aprendiz S3 - Autoridade de Andarilho|pacote completo de Andarilho]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Andarilho.

- [[Poder - Aprendiz S3 - Autoridade de Andarilho#Rota extramundana|Rota extramundana]]
- [[Poder - Aprendiz S3 - Autoridade de Andarilho#Caminho de retorno|Caminho de retorno]]

Operação: [[Poder - Aprendiz S3 - Autoridade de Andarilho#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Andarilho** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S3 - Andarilho]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Aprendiz - Feiticeiro dos Segredos]]. Próxima: [[Sequência 2 - Aprendiz - Caminhante dos Planos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
