---
titulo: "Sequência 5 - Insone - Feiticeiro dos Espíritos"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 5
nome_ingles: "Spirit Warlock"
---

# Sequência 5 - Insone - Feiticeiro dos Espíritos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 5. **Nome de referência:** Spirit Warlock. Tradução editorial: Feiticeiro dos Espíritos.

## O que a poção transforma

O [[Poder - Insone S5 - Pacto de vigília|pacote completo de Feiticeiro dos Espíritos]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Hospedaria espiritual.

- [[Poder - Insone S5 - Pacto de vigília#Acolher espírito|Acolher espírito]]
- [[Poder - Insone S5 - Pacto de vigília#Comandar manifestação|Comandar manifestação]]
- [[Poder - Insone S5 - Pacto de vigília#Lacre de repouso|Lacre de repouso]]



## Atuação e digestão

Interpretação original do papel **Feiticeiro dos Espíritos** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S5 - Feiticeiro dos Espíritos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Insone - Pacificador de Almas]]. Próxima: [[Sequência 4 - Insone - Vigilante Noturno]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
