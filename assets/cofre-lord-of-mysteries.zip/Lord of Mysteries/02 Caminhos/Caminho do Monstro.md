---
titulo: "Caminho do Monstro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
nome_divino: "Roda da Fortuna"
referencia: "https://lordofthemysteries.fandom.com/wiki/Wheel_of_Fortune_Pathway"
---

# Caminho do Monstro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Roda da Fortuna. **Tema:** Intuição, sorte, infortúnio e ciclos. **Função:** Prevenção de riscos e manipulação limitada de chances.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Monstro - Monstro|Monstro]] | [[Poder - Monstro S9 - Pressentir a ruptura|3 técnicas]] |
| 8 | [[Sequência 8 - Monstro - Robô|Robô]] | [[Poder - Monstro S8 - Rotina calculada|3 técnicas]] |
| 7 | [[Sequência 7 - Monstro - Sortudo|Sortudo]] | [[Poder - Monstro S7 - Desvio de sorte|3 técnicas]] |
| 6 | [[Sequência 6 - Monstro - Sacerdote da Calamidade|Sacerdote da Calamidade]] | [[Poder - Monstro S6 - Aviso de calamidade|3 técnicas]] |
| 5 | [[Sequência 5 - Monstro - Vencedor|Vencedor]] | [[Poder - Monstro S5 - Janela do vencedor|3 técnicas]] |
| 4 | [[Sequência 4 - Monstro - Mago do Infortúnio|Mago do Infortúnio]] | [[Poder - Monstro S4 - Autoridade de Mago do Infortúnio|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Monstro - Caminhante do Caos|Caminhante do Caos]] | [[Poder - Monstro S3 - Autoridade de Caminhante do Caos|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Monstro - Adivinho|Adivinho]] | [[Poder - Monstro S2 - Autoridade de Adivinho|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Monstro - Serpente de Mercúrio|Serpente de Mercúrio]] | [[Poder - Monstro S1 - Autoridade de Serpente de Mercúrio|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Monstro - Roda da Fortuna|Roda da Fortuna]] | [[Poder - Monstro S0 - Autoridade de Roda da Fortuna|2 técnicas + operação]] |

## Como jogar

Reconhecer acaso e escolha sem usar destino como desculpa. As ferramentas da S9 são espiritualidade anormal. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Muito alta: rolagens e destino. **Oposição:** Consequências sem teste, escolhas comprometidas e vínculos opacos. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Monstro]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Wheel_of_Fortune_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
