---
titulo: "Sequência 2 - Prisioneiro - Flagelo Antigo"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 2
nome_ingles: "Ancient Bane"
---

# Sequência 2 - Prisioneiro - Flagelo Antigo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 2. **Nome de referência:** Ancient Bane. Tradução editorial: Flagelo Antigo.

## O que a poção transforma

O [[Poder - Prisioneiro S2 - Autoridade de Flagelo Antigo|pacote completo de Flagelo Antigo]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Flagelo Antigo.

- [[Poder - Prisioneiro S2 - Autoridade de Flagelo Antigo#Eco de maldição|Eco de maldição]]
- [[Poder - Prisioneiro S2 - Autoridade de Flagelo Antigo#Antigo aprisionamento|Antigo aprisionamento]]

Operação: [[Poder - Prisioneiro S2 - Autoridade de Flagelo Antigo#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Flagelo Antigo** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S2 - Flagelo Antigo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Prisioneiro - Discípulo do Silêncio]]. Próxima: [[Sequência 1 - Prisioneiro - Abominação]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
