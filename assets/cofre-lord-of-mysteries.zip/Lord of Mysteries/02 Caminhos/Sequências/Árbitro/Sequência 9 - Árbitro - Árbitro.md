---
titulo: "Sequência 9 - Árbitro - Árbitro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 9
nome_ingles: "Arbiter"
---

# Sequência 9 - Árbitro - Árbitro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 9. **Nome de referência:** Arbiter. Tradução editorial: Árbitro.

## O que a poção transforma

O [[Poder - Árbitro S9 - Voz de mediação|pacote completo de Árbitro]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Presença de autoridade.

- [[Poder - Árbitro S9 - Voz de mediação#Advertência|Advertência]]
- [[Poder - Árbitro S9 - Voz de mediação#Comando de hesitação|Comando de hesitação]]
- [[Poder - Árbitro S9 - Voz de mediação#Ler a transgressão|Ler a transgressão]]



## Atuação e digestão

Interpretação original do papel **Árbitro** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S9 - Árbitro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Árbitro - Xerife]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
