---
titulo: "Caminho do Guerreiro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
nome_divino: "Gigante do Crepúsculo"
referencia: "https://lordofthemysteries.fandom.com/wiki/Twilight_Giant_Pathway"
---

# Caminho do Guerreiro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Gigante do Crepúsculo. **Tema:** Força, armas, proteção e declínio. **Função:** Defesa, combate e acesso físico.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Guerreiro - Guerreiro|Guerreiro]] | [[Poder - Guerreiro S9 - Força aplicada|3 técnicas]] |
| 8 | [[Sequência 8 - Guerreiro - Pugilista|Pugilista]] | [[Poder - Guerreiro S8 - Golpe de pugilista|3 técnicas]] |
| 7 | [[Sequência 7 - Guerreiro - Mestre das Armas|Mestre das Armas]] | [[Poder - Guerreiro S7 - Leitura do adversário|3 técnicas]] |
| 6 | [[Sequência 6 - Guerreiro - Paladino da Alvorada|Paladino da Alvorada]] | [[Poder - Guerreiro S6 - Arma da alvorada|3 técnicas]] |
| 5 | [[Sequência 5 - Guerreiro - Guardião|Guardião]] | [[Poder - Guerreiro S5 - Bastião de um nome|3 técnicas]] |
| 4 | [[Sequência 4 - Guerreiro - Caçador de Demônios|Caçador de Demônios]] | [[Poder - Guerreiro S4 - Autoridade de Caçador de Demônios|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Guerreiro - Cavaleiro de Prata|Cavaleiro de Prata]] | [[Poder - Guerreiro S3 - Autoridade de Cavaleiro de Prata|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Guerreiro - Glória|Glória]] | [[Poder - Guerreiro S2 - Autoridade de Glória|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Guerreiro - Mão de Deus|Mão de Deus]] | [[Poder - Guerreiro S1 - Autoridade de Mão de Deus|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Guerreiro - Gigante do Crepúsculo|Gigante do Crepúsculo]] | [[Poder - Guerreiro S0 - Autoridade de Gigante do Crepúsculo|2 técnicas + operação]] |

## Como jogar

Escolher o que proteger e conhecer o limite da força. As ferramentas da S9 são força sobre-humana, corpo de combatente. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Baixa a média: evitar imunidade ampla. **Oposição:** Riscos que exigem informação, ataques indiretos e múltiplos objetivos. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Guerreiro]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Twilight_Giant_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
