---
titulo: "Sequência 3 - Vidente - Erudito do Passado"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 3
nome_ingles: "Scholar of Yore"
---

# Sequência 3 - Vidente - Erudito do Passado

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 3. **Nome de referência:** Scholar of Yore. Tradução editorial: Erudito do Passado.

## O que a poção transforma

O [[Poder - Vidente S3 - Autoridade de Erudito do Passado|pacote completo de Erudito do Passado]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Erudito do Passado.

- [[Poder - Vidente S3 - Autoridade de Erudito do Passado#Projeção histórica|Projeção histórica]]
- [[Poder - Vidente S3 - Autoridade de Erudito do Passado#Refúgio no passado|Refúgio no passado]]

Operação: [[Poder - Vidente S3 - Autoridade de Erudito do Passado#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Erudito do Passado** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S3 - Erudito do Passado]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Vidente - Feiticeiro Bizarro]]. Próxima: [[Sequência 2 - Vidente - Invocador de Milagres]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
