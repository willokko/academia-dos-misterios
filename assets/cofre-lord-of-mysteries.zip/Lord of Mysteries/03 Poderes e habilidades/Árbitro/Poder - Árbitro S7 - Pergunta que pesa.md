---
titulo: "Poder - Árbitro S7 - Pergunta que pesa"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Árbitro"
sequencia: 7
nome_pacote: "Pacote de Interrogador — Árbitro S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Árbitro S7 - Pergunta que pesa

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Interrogador, Árbitro S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Árbitro - Interrogador]] ou melhor no [[Caminho do Árbitro]]. **Referência nominal:** Interrogator. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Interrogador:** Reconhece evasão de um assunto por comportamento, sem distinguir mentira de medo ou erro automaticamente.

## Técnicas adquiridas

### Perfuração psíquica

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+20 de dano trevas em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Pressão interrogativa

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma troca |
| Teste | AST+VON contra DEF.M |

Sobre uma contradição concreta, em sucesso NPC revela uma pista que conhece ou aceita abalado. PJ escolhe o custo e o que declara sobre seu próprio personagem.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Confrontar relato

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Compare duas afirmações e receba um ponto que pode verificar em documento, pessoa ou local acessível. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S6 proclama regras de conduta; não recebe uma magia de verdade absoluta.

## Preparação e oposição

Jurisdição ausente, regra simétrica e quebra de evidências. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Árbitro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
