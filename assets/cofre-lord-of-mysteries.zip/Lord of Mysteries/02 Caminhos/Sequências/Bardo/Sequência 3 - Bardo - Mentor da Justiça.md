---
titulo: "Sequência 3 - Bardo - Mentor da Justiça"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 3
nome_ingles: "Justice Mentor"
---

# Sequência 3 - Bardo - Mentor da Justiça

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 3. **Nome de referência:** Justice Mentor. Tradução editorial: Mentor da Justiça.

## O que a poção transforma

O [[Poder - Bardo S3 - Autoridade de Mentor da Justiça|pacote completo de Mentor da Justiça]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Mentor da Justiça.

- [[Poder - Bardo S3 - Autoridade de Mentor da Justiça#Mentoria da justiça|Mentoria da justiça]]
- [[Poder - Bardo S3 - Autoridade de Mentor da Justiça#Revelação solar|Revelação solar]]

Operação: [[Poder - Bardo S3 - Autoridade de Mentor da Justiça#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Mentor da Justiça** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S3 - Mentor da Justiça]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Bardo - Sem Sombra]]. Próxima: [[Sequência 2 - Bardo - Buscador da Luz]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
