---
titulo: "Sequência 7 - Advogado - Subornador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
sequencia: 7
nome_ingles: "Briber"
---

# Sequência 7 - Advogado - Subornador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Advogado]]. **Sequência:** 7. **Nome de referência:** Briber. Tradução editorial: Subornador.

## O que a poção transforma

O [[Poder - Advogado S7 - Presente comprometedor|pacote completo de Subornador]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Conexão de suborno.

- [[Poder - Advogado S7 - Presente comprometedor#Suborno enfraquecedor|Suborno enfraquecedor]]
- [[Poder - Advogado S7 - Presente comprometedor#Suborno da arrogância|Suborno da arrogância]]
- [[Poder - Advogado S7 - Presente comprometedor#Suborno de conexão|Suborno de conexão]]



## Atuação e digestão

Interpretação original do papel **Subornador** no tema de brechas, suborno e distorção de regras. Princípio de partida: conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Advogado#S7 - Subornador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Advogado - Bárbaro]]. Próxima: [[Sequência 6 - Advogado - Barão da Corrupção]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
