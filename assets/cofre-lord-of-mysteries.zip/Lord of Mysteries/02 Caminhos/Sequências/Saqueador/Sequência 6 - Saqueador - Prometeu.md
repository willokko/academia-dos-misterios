---
titulo: "Sequência 6 - Saqueador - Prometeu"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 6
nome_ingles: "Prometheus"
---

# Sequência 6 - Saqueador - Prometeu

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 6. **Nome de referência:** Prometheus. Tradução editorial: Prometeu.

## O que a poção transforma

O [[Poder - Saqueador S6 - Furto de chama|pacote completo de Prometeu]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Furto espiritual.

- [[Poder - Saqueador S6 - Furto de chama#Roubar poder|Roubar poder]]
- [[Poder - Saqueador S6 - Furto de chama#Furto à distância|Furto à distância]]
- [[Poder - Saqueador S6 - Furto de chama#Rastrear valor|Rastrear valor]]



## Atuação e digestão

Interpretação original do papel **Prometeu** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S6 - Prometeu]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Saqueador - Criptologista]]. Próxima: [[Sequência 5 - Saqueador - Ladrão de Sonhos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
