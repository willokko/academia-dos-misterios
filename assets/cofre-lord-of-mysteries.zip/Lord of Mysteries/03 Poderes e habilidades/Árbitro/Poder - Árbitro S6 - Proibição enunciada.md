---
titulo: "Poder - Árbitro S6 - Proibição enunciada"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Árbitro"
sequencia: 6
nome_pacote: "Pacote de Juiz — Árbitro S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Árbitro S6 - Proibição enunciada

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Juiz, Árbitro S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Árbitro - Juiz]] ou melhor no [[Caminho do Árbitro]]. **Referência nominal:** Judge. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Autoridade do juiz:** Uma regra proclamada precisa ser clara, audível e ter escopo definido. Nunca proíbe pensar, existir, vencer ou agir em geral.

## Técnicas adquiridas

### Proibição

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até seu próximo turno |
| Teste | AST+VON contra DEF.M do transgressor |

Proíba uma categoria concreta na cena, como voar ou atravessar uma porta. Teste contra cada alvo que tenta violar: em sucesso a tentativa falha, mas ele pode escolher outra ação válida. Uma proibição ativa, inclusive contra aliados.

**Limites:** Manter custa ação e 5 PM; não usa mais de uma disputa por alvo por rodada. Sem proibir respirar ou toda ação ofensiva.

### Veredito

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Após um alvo violar uma regra proclamada e resistir a ela, cause RA+20 de luz em sucesso. A infração é requisito, não acerto automático.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Pena de restrição

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Um teste |
| Teste | Automático |

Marque uma passagem: +2 ao próximo Objetivo para deter quem tenta atravessá-la, sem adicionar turno policial.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5 sustenta duas proibições por vez, mantendo uma ação e 10 PM por turno; o custo e a ação substituem os da versão anterior.

## Preparação e oposição

Jurisdição ausente, regra simétrica e quebra de evidências. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Árbitro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
