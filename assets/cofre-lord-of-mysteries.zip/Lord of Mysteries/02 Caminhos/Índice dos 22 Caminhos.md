---
titulo: "Índice dos 22 Caminhos"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Índice dos 22 Caminhos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

O índice usa o nome da S9 para navegação e o nome divino para comparar com a wiki. Todos os nomes portugueses são editoriais desta adaptação. S9–5 usam combate e investigação convencionais; S4–0 usam módulos por autoridades. Dificuldade indica risco de adaptação, não poder relativo canônico.

| Caminho de entrada | Nome divino | Função no grupo | Dificuldade |
|---|---|---|---|
| [[Caminho do Vidente|Vidente]] | Louco | Investigação, infiltração e controle preparado | Alta: informação e marionetes |
| [[Caminho do Espectador|Espectador]] | Visionário | Interação, investigação e sustentação do grupo | Alta: agência e informação privada |
| [[Caminho do Marinheiro|Marinheiro]] | Tirano | Mobilidade, resgate e pressão ofensiva | Média: ambiente e alcance |
| [[Caminho do Saqueador|Saqueador]] | Erro | Infiltração, interrupção e informação | Muito alta: roubo e cópia |
| [[Caminho do Aprendiz|Aprendiz]] | Porta | Exploração, evacuação e versatilidade preparada | Muito alta: cópia e teleporte |
| [[Caminho do Bardo|Bardo]] | Sol | Suporte, oposição a assombrações e compromissos | Média: distinguir purificação de solução universal |
| [[Caminho do Suplicante de Segredos|Suplicante de Segredos]] | Enforcado | Ocultismo, infiltração e versatilidade arriscada | Muito alta: almas e contatos |
| [[Caminho do Leitor|Leitor]] | Torre Branca | Investigação e preparação de contramedidas | Alta: cópia e onisciência limitada |
| [[Caminho do Insone|Insone]] | Escuridão | Vigília, infiltração e suporte | Alta: sono e ocultação |
| [[Caminho do Coletor de Cadáveres|Coletor de Cadáveres]] | Morte | Forense, contato espiritual e contenção | Alta: mortos não são testemunhas oniscientes |
| [[Caminho do Guerreiro|Guerreiro]] | Gigante do Crepúsculo | Defesa, combate e acesso físico | Baixa a média: evitar imunidade ampla |
| [[Caminho do Assassino|Assassino]] | Demoness | Infiltração, interferência e controle | Alta: consentimento e aflições |
| [[Caminho do Caçador|Caçador]] | Sacerdote Vermelho | Pressão ofensiva e coordenação | Média: conspiração e tropas |
| [[Caminho do Espreitador de Mistérios|Espreitador de Mistérios]] | Eremita | Ocultismo, preparação e contramedidas | Alta: conhecimento perigoso |
| [[Caminho do Sábio|Sábio]] | Paragon | Ferramentas, projetos e suporte preparado | Alta: economia de invenções |
| [[Caminho do Monstro|Monstro]] | Roda da Fortuna | Prevenção de riscos e manipulação limitada de chances | Muito alta: rolagens e destino |
| [[Caminho do Boticário|Boticário]] | Lua | Suporte, criaturas e preparação | Alta: acompanhantes e transformação |
| [[Caminho do Plantador|Plantador]] | Mãe | Suporte, sobrevivência e ambiente | Média a alta: cura e vida |
| [[Caminho do Prisioneiro|Prisioneiro]] | Acorrentado | Resistência, infiltração e controle de vínculos | Alta: possessão e autonomia |
| [[Caminho do Criminoso|Criminoso]] | Abismo | Detecção de ameaças e pressão psicológica | Alta: conteúdo cruel e desejo |
| [[Caminho do Advogado|Advogado]] | Imperador Negro | Negociação e interferência contextual | Muito alta: linguagem e leis |
| [[Caminho do Árbitro|Árbitro]] | Justiceiro | Investigação institucional e controle | Muito alta: proibições amplas |

Arquitetura: [[Arquitetura da adaptação]]. Trocas e grupos: [[Progressão e Sequências]]. Capacidades: [[Índice de poderes]]. Cânone e limites: [[Fontes de Lord of Mysteries]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
