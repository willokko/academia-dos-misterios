---
titulo: "Sequência 3 - Espreitador de Mistérios - Clarividente"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
sequencia: 3
nome_ingles: "Clairvoyant"
---

# Sequência 3 - Espreitador de Mistérios - Clarividente

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espreitador de Mistérios]]. **Sequência:** 3. **Nome de referência:** Clairvoyant. Tradução editorial: Clarividente.

## O que a poção transforma

O [[Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente|pacote completo de Clarividente]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Clarividente.

- [[Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente#Olhar distante|Olhar distante]]
- [[Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente#Reconhecer o oculto|Reconhecer o oculto]]

Operação: [[Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Clarividente** no tema de conhecimento oculto, símbolos e histórias com poder. Princípio de partida: investigar sem confundir curiosidade com direito a toda resposta. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espreitador de Mistérios#S3 - Clarividente]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Espreitador de Mistérios - Misticólogo]]. Próxima: [[Sequência 2 - Espreitador de Mistérios - Sábio Místico]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
