---
titulo: "Sequência 4 - Espectador - Manipulador"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 4
nome_ingles: "Manipulator"
---

# Sequência 4 - Espectador - Manipulador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 4. **Nome de referência:** Manipulator. Tradução editorial: Manipulador.

## O que a poção transforma

O [[Poder - Espectador S4 - Autoridade de Manipulador|pacote completo de Manipulador]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Manipulador.

- [[Poder - Espectador S4 - Autoridade de Manipulador#Semente de manipulação|Semente de manipulação]]
- [[Poder - Espectador S4 - Autoridade de Manipulador#Forma dracônica|Forma dracônica]]

Operação: [[Poder - Espectador S4 - Autoridade de Manipulador#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Manipulador** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S4 - Manipulador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Espectador - Caminhante dos Sonhos]]. Próxima: [[Sequência 3 - Espectador - Tecelão de Sonhos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
