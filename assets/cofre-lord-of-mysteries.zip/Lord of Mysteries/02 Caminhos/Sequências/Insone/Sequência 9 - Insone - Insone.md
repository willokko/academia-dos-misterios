---
titulo: "Sequência 9 - Insone - Insone"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 9
nome_ingles: "Sleepless"
---

# Sequência 9 - Insone - Insone

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 9. **Nome de referência:** Sleepless. Tradução editorial: Insone.

## O que a poção transforma

O [[Poder - Insone S9 - Vigília sensível|pacote completo de Insone]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Vigília noturna; Percepção espiritual.

- [[Poder - Insone S9 - Vigília sensível#Sentir a noite|Sentir a noite]]
- [[Poder - Insone S9 - Vigília sensível#Força noturna|Força noturna]]
- [[Poder - Insone S9 - Vigília sensível#Guarda desperta|Guarda desperta]]



## Atuação e digestão

Interpretação original do papel **Insone** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S9 - Insone]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Insone - Poeta da Meia-Noite]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
