---
titulo: "Sequência 5 - Bardo - Sacerdote da Luz"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 5
nome_ingles: "Priest of Light"
---

# Sequência 5 - Bardo - Sacerdote da Luz

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 5. **Nome de referência:** Priest of Light. Tradução editorial: Sacerdote da Luz.

## O que a poção transforma

O [[Poder - Bardo S5 - Purificação focal|pacote completo de Sacerdote da Luz]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Presença sagrada.

- [[Poder - Bardo S5 - Purificação focal#Luz sagrada|Luz sagrada]]
- [[Poder - Bardo S5 - Purificação focal#Exorcismo|Exorcismo]]
- [[Poder - Bardo S5 - Purificação focal#Santuário provisório|Santuário provisório]]



## Atuação e digestão

Interpretação original do papel **Sacerdote da Luz** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S5 - Sacerdote da Luz]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Bardo - Notário]]. Próxima: [[Sequência 4 - Bardo - Sem Sombra]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
