---
titulo: "Sequência 3 - Suplicante de Segredos - Templário da Trindade"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
sequencia: 3
nome_ingles: "Trinity Templar"
---

# Sequência 3 - Suplicante de Segredos - Templário da Trindade

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Suplicante de Segredos]]. **Sequência:** 3. **Nome de referência:** Trinity Templar. Tradução editorial: Templário da Trindade.

## O que a poção transforma

O [[Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade|pacote completo de Templário da Trindade]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Templário da Trindade.

- [[Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade#Trindade manifesta|Trindade manifesta]]
- [[Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade#Carne reconstruída|Carne reconstruída]]

Operação: [[Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Templário da Trindade** no tema de escuta perigosa, sombras, carne e almas. Princípio de partida: buscar conhecimento sem entregar a própria responsabilidade à voz que responde. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Suplicante de Segredos#S3 - Templário da Trindade]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Suplicante de Segredos - Cavaleiro Negro]]. Próxima: [[Sequência 2 - Suplicante de Segredos - Presbítero Profano]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
