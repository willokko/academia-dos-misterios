---
titulo: "Sequência 0 - Guerreiro - Gigante do Crepúsculo"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
sequencia: 0
nome_ingles: "Twilight Giant"
---

# Sequência 0 - Guerreiro - Gigante do Crepúsculo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Guerreiro]]. **Sequência:** 0. **Nome de referência:** Twilight Giant. Tradução editorial: Gigante do Crepúsculo.

## O que a poção transforma

O [[Poder - Guerreiro S0 - Autoridade de Gigante do Crepúsculo|pacote completo de Gigante do Crepúsculo]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Gigante do Crepúsculo.

- [[Poder - Guerreiro S0 - Autoridade de Gigante do Crepúsculo#Crepúsculo|Crepúsculo]]
- [[Poder - Guerreiro S0 - Autoridade de Gigante do Crepúsculo#Proteção do gigante|Proteção do gigante]]

Operação: [[Poder - Guerreiro S0 - Autoridade de Gigante do Crepúsculo#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Gigante do Crepúsculo** no tema de força, armas, proteção e declínio. Princípio de partida: escolher o que proteger e conhecer o limite da força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Guerreiro#S0 - Gigante do Crepúsculo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Guerreiro - Mão de Deus]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
