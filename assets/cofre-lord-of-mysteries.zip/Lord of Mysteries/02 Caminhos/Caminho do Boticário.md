---
titulo: "Caminho do Boticário"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
nome_divino: "Lua"
referencia: "https://lordofthemysteries.fandom.com/wiki/Moon_Pathway"
---

# Caminho do Boticário

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Lua. **Tema:** Medicina, bestas, sangue e invocação lunar. **Função:** Suporte, criaturas e preparação.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Boticário - Boticário|Boticário]] | [[Poder - Boticário S9 - Dose de socorro|3 técnicas]] |
| 8 | [[Sequência 8 - Boticário - Domador de Bestas|Domador de Bestas]] | [[Poder - Boticário S8 - Entendimento da besta|3 técnicas]] |
| 7 | [[Sequência 7 - Boticário - Vampiro|Vampiro]] | [[Poder - Boticário S7 - Vigor sanguíneo|3 técnicas]] |
| 6 | [[Sequência 6 - Boticário - Professor de Poções|Professor de Poções]] | [[Poder - Boticário S6 - Preparado de estabilidade|3 técnicas]] |
| 5 | [[Sequência 5 - Boticário - Erudito Escarlate|Erudito Escarlate]] | [[Poder - Boticário S5 - Chamado escarlate|3 técnicas]] |
| 4 | [[Sequência 4 - Boticário - Rei Xamã|Rei Xamã]] | [[Poder - Boticário S4 - Autoridade de Rei Xamã|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Boticário - Alto Invocador|Alto Invocador]] | [[Poder - Boticário S3 - Autoridade de Alto Invocador|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Boticário - Doador de Vida|Doador de Vida]] | [[Poder - Boticário S2 - Autoridade de Doador de Vida|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Boticário - Deusa da Beleza|Deusa da Beleza]] | [[Poder - Boticário S1 - Autoridade de Deusa da Beleza|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Boticário - Lua|Lua]] | [[Poder - Boticário S0 - Autoridade de Lua|2 técnicas + operação]] |

## Como jogar

Cuidar de uma vida concreta antes de tratar vida como matéria. As ferramentas da S9 são farmacopeia. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: acompanhantes e transformação. **Oposição:** Limitações de amostra, necessidade de consentimento e selos de invocação. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Boticário]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Moon_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
