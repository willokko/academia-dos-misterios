---
titulo: "Sequência 6 - Monstro - Sacerdote da Calamidade"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 6
nome_ingles: "Calamity Priest"
---

# Sequência 6 - Monstro - Sacerdote da Calamidade

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 6. **Nome de referência:** Calamity Priest. Tradução editorial: Sacerdote da Calamidade.

## O que a poção transforma

O [[Poder - Monstro S6 - Aviso de calamidade|pacote completo de Sacerdote da Calamidade]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Pressão de calamidade.

- [[Poder - Monstro S6 - Aviso de calamidade#Desencadear o risco|Desencadear o risco]]
- [[Poder - Monstro S6 - Aviso de calamidade#Má sequência|Má sequência]]
- [[Poder - Monstro S6 - Aviso de calamidade#Conter a cascata|Conter a cascata]]



## Atuação e digestão

Interpretação original do papel **Sacerdote da Calamidade** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S6 - Sacerdote da Calamidade]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Monstro - Sortudo]]. Próxima: [[Sequência 5 - Monstro - Vencedor]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
