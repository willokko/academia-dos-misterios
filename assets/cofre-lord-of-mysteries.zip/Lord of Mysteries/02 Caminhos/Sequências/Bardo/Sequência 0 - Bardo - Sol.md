---
titulo: "Sequência 0 - Bardo - Sol"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 0
nome_ingles: "Sun"
---

# Sequência 0 - Bardo - Sol

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 0. **Nome de referência:** Sun. Tradução editorial: Sol.

## O que a poção transforma

O [[Poder - Bardo S0 - Autoridade de Sol|pacote completo de Sol]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Sol.

- [[Poder - Bardo S0 - Autoridade de Sol#Dia no domínio|Dia no domínio]]
- [[Poder - Bardo S0 - Autoridade de Sol#Notarização divina|Notarização divina]]

Operação: [[Poder - Bardo S0 - Autoridade de Sol#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Sol** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S0 - Sol]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Bardo - Anjo Branco]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
