---
titulo: "Poder - Plantador S7 - Crescimento oportuno"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Plantador"
sequencia: 7
nome_pacote: "Pacote de Sacerdote da Colheita — Plantador S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Plantador S7 - Crescimento oportuno

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Sacerdote da Colheita, Plantador S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Plantador - Sacerdote da Colheita]] ou melhor no [[Caminho do Plantador]]. **Referência nominal:** Harvest Priest. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Afinidade de colheita:** Pode reconhecer vigor de plantas presentes e conduzir crescimento de vegetação existente; matéria viva ainda precisa de nutrientes.

## Técnicas adquiridas

### Crescimento

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON ND10; ND13 sob oposição |

Vegetação ocupa uma passagem pequena ou forma um apoio pela cena. Sob contestação, avance Objetivo 0/4; não cria floresta do nada.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Raízes de contenção

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica lento e raízes locais prendem o passo e podem ser cortadas ou queimadas.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

### Vigor da terra

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Toque |
| Duração | Instantânea |
| Teste | Automático |

Um voluntário recupera 20 PV e recebe +2 no próximo teste de VIG que não seja ataque.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5 faz da natureza uma rota de deslocamento e proteção, além de mera cura.

## Preparação e oposição

Ambiente estéril, escassez de amostra e contaminação da fonte. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Plantador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
