---
titulo: "Poder - Boticário S8 - Entendimento da besta"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Boticário"
sequencia: 8
nome_pacote: "Pacote de Domador de Bestas — Boticário S8"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Boticário S8 - Entendimento da besta

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Domador de Bestas, Boticário S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Boticário - Domador de Bestas]] ou melhor no [[Caminho do Boticário]]. **Referência nominal:** Beast Tamer. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Afinidade animal:** Pode interpretar sinais de animais ordinários e oferecer instruções simples com treino; não concede fala humana.

## Técnicas adquiridas

### Vínculo de besta

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até romper |
| Teste | AST+VON ND10 |

Após interação e alimento adequados, estabeleça vínculo voluntário com uma besta ordinária. Uma companheira por vez; treino não a transforma em NPC com turnos extras.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Comandar companheira

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma ação |
| Teste | Conforme uso |

Gaste sua ação para um deslocamento, Objetivo sensorial ou ataque corporal da besta: DES+VIG do controlador contra DEF, RA+10 físicos; não ataca em outro turno.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Instinto da besta

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Com companhia acessível, obtenha direção de um cheiro ou perigo que ela de fato percebeu. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S7 adiciona corpo sanguíneo; uma besta não se torna familiar imortal ou fonte de características.

## Preparação e oposição

Limitações de amostra, necessidade de consentimento e selos de invocação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Boticário]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
