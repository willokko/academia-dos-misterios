---
titulo: "Sequência 9 - Espreitador de Mistérios - Espreitador de Mistérios"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
sequencia: 9
nome_ingles: "Mystery Pryer"
---

# Sequência 9 - Espreitador de Mistérios - Espreitador de Mistérios

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espreitador de Mistérios]]. **Sequência:** 9. **Nome de referência:** Mystery Pryer. Tradução editorial: Espreitador de Mistérios.

## O que a poção transforma

O [[Poder - Espreitador de Mistérios S9 - Anotação do oculto|pacote completo de Espreitador de Mistérios]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Olhos do mistério; Conhecimento não solicitado.

- [[Poder - Espreitador de Mistérios S9 - Anotação do oculto#Escrutínio oculto|Escrutínio oculto]]
- [[Poder - Espreitador de Mistérios S9 - Anotação do oculto#Divinação por sinais|Divinação por sinais]]
- [[Poder - Espreitador de Mistérios S9 - Anotação do oculto#Traçar proteção|Traçar proteção]]



## Atuação e digestão

Interpretação original do papel **Espreitador de Mistérios** no tema de conhecimento oculto, símbolos e histórias com poder. Princípio de partida: investigar sem confundir curiosidade com direito a toda resposta. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espreitador de Mistérios#S9 - Espreitador de Mistérios]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Espreitador de Mistérios - Erudito Marcial]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
