---
titulo: "Sequência 7 - Plantador - Sacerdote da Colheita"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
sequencia: 7
nome_ingles: "Harvest Priest"
---

# Sequência 7 - Plantador - Sacerdote da Colheita

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Plantador]]. **Sequência:** 7. **Nome de referência:** Harvest Priest. Tradução editorial: Sacerdote da Colheita.

## O que a poção transforma

O [[Poder - Plantador S7 - Crescimento oportuno|pacote completo de Sacerdote da Colheita]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Afinidade de colheita.

- [[Poder - Plantador S7 - Crescimento oportuno#Crescimento|Crescimento]]
- [[Poder - Plantador S7 - Crescimento oportuno#Raízes de contenção|Raízes de contenção]]
- [[Poder - Plantador S7 - Crescimento oportuno#Vigor da terra|Vigor da terra]]



## Atuação e digestão

Interpretação original do papel **Sacerdote da Colheita** no tema de cultivo, medicina, vida e transformações orgânicas. Princípio de partida: cultivar condições para que outros vivam sem possuir seu futuro. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Plantador#S7 - Sacerdote da Colheita]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Plantador - Médico]]. Próxima: [[Sequência 6 - Plantador - Biólogo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
