---
titulo: "Roubo cópia destino e invocações"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Roubo cópia destino e invocações

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

Os estoques e procedimentos normativos de cópia, roubo, almas, espíritos e marionetes estão em [[Servos e repertórios]]. O antigo limite universal de um registro foi substituído por limites diferentes para cada método.

## Previsão e destino

Divinação responde a uma pergunta que o vínculo suporta e pode alterar o rumo da investigação. Se uma técnica realmente identifica a rota ou encontra o local, entregue esse resultado. Não transforme todo sucesso em metáfora inútil para preservar o roteiro. O mistério seguinte pode ser como alcançar, o que fazer com a descoberta e quem também a ouviu.

Distinga impressão, testemunho, memória, visão de futuro provável e fato verificado. Um testemunho pode mentir; o narrador não apresenta uma interferência como certeza falsa sem sinal de adulteração. Repetir a mesma pergunta sem nova evidência não cria mais respostas. [[Investigação e divinação]] desenvolve exemplos.

Rerrolagens não afetam crítico, não refazem uma nova rolagem e seguem o teto de [[Regras dos poderes]]. Os Pontos de Fabula mantêm seus usos oficiais; não são taxa obrigatória para toda técnica de destino.

Controle, possessão, sonhos e sugestões seguem [[Controle mental e agência]]. Uma invocação não cria iniciativas extras ou novas características. Autoridades usam [[Escala e confrontos sobrenaturais]], não registros de baixo grau.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
