---
titulo: "Sequência 8 - Espreitador de Mistérios - Erudito Marcial"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
sequencia: 8
nome_ingles: "Melee Scholar"
---

# Sequência 8 - Espreitador de Mistérios - Erudito Marcial

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espreitador de Mistérios]]. **Sequência:** 8. **Nome de referência:** Melee Scholar. Tradução editorial: Erudito Marcial.

## O que a poção transforma

O [[Poder - Espreitador de Mistérios S8 - Geometria marcial|pacote completo de Erudito Marcial]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Erudição marcial.

- [[Poder - Espreitador de Mistérios S8 - Geometria marcial#Golpe do erudito|Golpe do erudito]]
- [[Poder - Espreitador de Mistérios S8 - Geometria marcial#Forma defensiva|Forma defensiva]]
- [[Poder - Espreitador de Mistérios S8 - Geometria marcial#Ler uma escola|Ler uma escola]]



## Atuação e digestão

Interpretação original do papel **Erudito Marcial** no tema de conhecimento oculto, símbolos e histórias com poder. Princípio de partida: investigar sem confundir curiosidade com direito a toda resposta. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espreitador de Mistérios#S8 - Erudito Marcial]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Espreitador de Mistérios - Espreitador de Mistérios]]. Próxima: [[Sequência 7 - Espreitador de Mistérios - Bruxo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
