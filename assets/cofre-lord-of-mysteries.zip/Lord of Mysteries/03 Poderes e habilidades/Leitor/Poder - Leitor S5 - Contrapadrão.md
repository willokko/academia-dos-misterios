---
titulo: "Poder - Leitor S5 - Contrapadrão"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Leitor"
sequencia: 5
nome_pacote: "Pacote de Magíster do Misticismo — Leitor S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Leitor S5 - Contrapadrão

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Magíster do Misticismo, Leitor S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Leitor - Magíster do Misticismo]] ou melhor no [[Caminho do Leitor]]. **Referência nominal:** Mysticism Magister. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Oficina de artes místicas:** Pode projetar uma técnica original no domínio de conhecimento demonstrado, usando os perfis e a auditoria de Orçamento de equilíbrio, nunca por declaração irrestrita.

## Técnicas adquiridas

### Raio de análise

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+20 de dano gelo em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Selo de método

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma rodada |
| Teste | AST+VON contra DEF.M do criador |

Após identificar um efeito S9–5, conteste para suspendê-lo até o fim do próximo turno. Não anula característica nem cura Corrupção.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Artifício de resguardo

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Você e um aliado |
| Duração | Um teste por protegido |
| Teste | Automático |

Você e um aliado recebem +2 ao próximo teste para resistir ao tipo de influência previamente estudado.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 traz profecia; criar arte mística exige pesquisa, dois testes ND13 e um intervalo entre eles, sem competir com a aquisição de poções.

## Preparação e oposição

Informação falsa, fenômenos novos e acesso negado a evidências. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Leitor]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
