---
titulo: "Controle mental e agência"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Controle mental e agência

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

## Uma regra para todas as formas de domínio

Hipnose, sonho, possessão, fios e desejo são capacidades reais: podem dominar NPCs, criar servos ou alterar uma situação além de uma condição de um turno. Distinga influência pequena de dominação decisiva. Não converta todo efeito num mero -2, mas não retire o controle de outro jogador sem procedimento acordado.

| Grau de influência | Resolução |
|---|---|
| Ler emoção, impressão ou pensamento superficial | Técnica própria e alcance real; não é verdade objetiva |
| Distração, hesitação, sugestão breve | Teste e efeito impresso, preservando uma ação válida |
| Ordem simples fora de conflito, coerente com identidade de NPC | Técnica preparada e oposição; pista da fonte e quebra possíveis |
| Dominação, possessão ou transformação em servo | Relógio 6 ou 8, ações, custos e resistência repetida conforme ficha |

**Aceleração de domínio:** quando uma técnica abre um relógio pessoal de Sono, Captura, Dominação, Possessão, Petrificação ou Exílio, em sucesso acrescente +1 seção nas S9–8, ou +2 nas S7–0, além das margens normais. O custo impresso é a abertura; novas contribuições custam 5 PM, salvo outro valor explicitamente impresso. Esse ganho especial não vale para agitação de multidão, investigação, selamento coletivo ou operações de autoridade. Assim, dominar não exige sete ou oito ações médias sem resistência ativa.

Enquanto o relógio não completar, o alvo continua agindo. Ele ou um aliado pode usar Objetivo para apagar seções, em VON+VON ou AST+VON ND10 para S9–5, ND13 para santos, ND16 para autoridades angelicais, salvo ficha. Cada sucesso defensivo apaga pelas margens normais, sem aceleração. Romper linha, danificar suporte ou revelar o gatilho oferece outra contramedida concreta. Um efeito não fica impossível de romper porque a ficha disse persistente.

## NPCs e consequências

Após dominação completa, um NPC pode cumprir comandos graves se a técnica admitir; marque duração, condição de quebra e consequências. Fios podem produzir uma marionete morta persistente. Pastoreio pode prender uma alma, sem torná-la cooperativa por decreto. Assassinato, desaparecimento, detecção por facções e impressões espirituais continuam fatos do mundo. Não se exige dano cosmético para fingir que essas escolhas são inofensivas.

Não existe ciclo de deixar um chefe sem jogar: um bloqueio breve de técnica ou ação não se renova no mesmo alvo na mesma rodada; mantenha os limites da ficha. Para dominação definitiva de entidade muito superior, são necessárias chaves de escala, não uma soma de Impedimentos.

## Quando o alvo é um PJ

O jogador conserva autoria de sua pessoa. Num efeito breve, escolhe o custo impresso: mudar o gesto, hesitar, condição ou penalidade. Para um efeito decisivo, antes de iniciar o relógio combinem uma destas resoluções: cativeiro com possibilidade de resgate; conflito interno em que o jogador interpreta o impulso mantendo escolha; ou transformação em NPC quando o jogador quiser encerrar aquele personagem. Sem acordo, o sucesso aplica abalado e lento pela cena e abre vínculo investigável, sem ordenar intimidade, crença ou ataque a aliado.

Essas proteções são convenções de jogo, não alegação sobre as vítimas no romance. Não se precisa narrar uma cena íntima ou encenar trauma para usar qualquer Caminho. [[Maldições e humanidade]] trata pressão do papel; [[Perda de controle]] trata colapso sobrenatural.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
