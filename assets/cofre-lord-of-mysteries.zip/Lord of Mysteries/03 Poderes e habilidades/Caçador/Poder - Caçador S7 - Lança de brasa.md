---
titulo: "Poder - Caçador S7 - Lança de brasa"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Caçador"
sequencia: 7
nome_pacote: "Pacote de Piromaníaco — Caçador S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Caçador S7 - Lança de brasa

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Piromaníaco, Caçador S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Caçador - Piromaníaco]] ou melhor no [[Caminho do Caçador]]. **Referência nominal:** Pyromaniac. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Pirocinese:** Cria chama pequena e a modela sem custo para uso inofensivo; fogo ofensivo ou proteção usa as técnicas. Não fornece imunidade universal a fogo.

## Técnicas adquiridas

### Bola de fogo

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+20 de dano fogo em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Corvo de fogo

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON ND10 sob pressão |

Mantenha uma chama em forma de corvo para levar luz ou observar uma rota visível da cena. Para causar dano, gaste sua ação e 10 PM: AST+VON contra DEF.M, RA+15 fogo. Nunca age sozinho.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Manto de chamas

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Até o próximo turno |
| Teste | Automático |

Receba Resistência a fogo até seu próximo turno; não afeta dano de outro tipo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 une deslocamento à arma de fogo; S5 torna possível precisão contra uma fraqueza identificada.

## Preparação e oposição

Terreno estudado pelo oponente, objetivos múltiplos e proteção contra fogo. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Caçador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
