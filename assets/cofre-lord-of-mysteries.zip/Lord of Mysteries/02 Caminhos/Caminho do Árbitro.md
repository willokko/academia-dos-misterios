---
titulo: "Caminho do Árbitro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
nome_divino: "Justiceiro"
referencia: "https://lordofthemysteries.fandom.com/wiki/Justiciar_Pathway"
---

# Caminho do Árbitro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Justiceiro. **Tema:** Autoridade, julgamento, proibição e ordem. **Função:** Investigação institucional e controle.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Árbitro - Árbitro|Árbitro]] | [[Poder - Árbitro S9 - Voz de mediação|3 técnicas]] |
| 8 | [[Sequência 8 - Árbitro - Xerife|Xerife]] | [[Poder - Árbitro S8 - Olhar do xerife|3 técnicas]] |
| 7 | [[Sequência 7 - Árbitro - Interrogador|Interrogador]] | [[Poder - Árbitro S7 - Pergunta que pesa|3 técnicas]] |
| 6 | [[Sequência 6 - Árbitro - Juiz|Juiz]] | [[Poder - Árbitro S6 - Proibição enunciada|3 técnicas]] |
| 5 | [[Sequência 5 - Árbitro - Paladino Disciplinar|Paladino Disciplinar]] | [[Poder - Árbitro S5 - Sanção disciplinar|3 técnicas]] |
| 4 | [[Sequência 4 - Árbitro - Mago Imperativo|Mago Imperativo]] | [[Poder - Árbitro S4 - Autoridade de Mago Imperativo|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Árbitro - Caçador do Caos|Caçador do Caos]] | [[Poder - Árbitro S3 - Autoridade de Caçador do Caos|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Árbitro - Equilibrador|Equilibrador]] | [[Poder - Árbitro S2 - Autoridade de Equilibrador|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Árbitro - Mão da Ordem|Mão da Ordem]] | [[Poder - Árbitro S1 - Autoridade de Mão da Ordem|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Árbitro - Justiceiro|Justiceiro]] | [[Poder - Árbitro S0 - Autoridade de Justiceiro|2 técnicas + operação]] |

## Como jogar

Tornar uma regra compreensível e aceitar que ela também o limite. As ferramentas da S9 são presença de autoridade. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Muito alta: proibições amplas. **Oposição:** Jurisdição ausente, regra simétrica e quebra de evidências. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Árbitro]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Justiciar_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
