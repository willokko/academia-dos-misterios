---
titulo: "Sequência 4 - Suplicante de Segredos - Cavaleiro Negro"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
sequencia: 4
nome_ingles: "Black Knight"
---

# Sequência 4 - Suplicante de Segredos - Cavaleiro Negro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Suplicante de Segredos]]. **Sequência:** 4. **Nome de referência:** Black Knight. Tradução editorial: Cavaleiro Negro.

## O que a poção transforma

O [[Poder - Suplicante de Segredos S4 - Autoridade de Cavaleiro Negro|pacote completo de Cavaleiro Negro]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Cavaleiro Negro.

- [[Poder - Suplicante de Segredos S4 - Autoridade de Cavaleiro Negro#Armadura negra|Armadura negra]]
- [[Poder - Suplicante de Segredos S4 - Autoridade de Cavaleiro Negro#Oferenda sombria|Oferenda sombria]]

Operação: [[Poder - Suplicante de Segredos S4 - Autoridade de Cavaleiro Negro#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Cavaleiro Negro** no tema de escuta perigosa, sombras, carne e almas. Princípio de partida: buscar conhecimento sem entregar a própria responsabilidade à voz que responde. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Suplicante de Segredos#S4 - Cavaleiro Negro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Suplicante de Segredos - Pastor]]. Próxima: [[Sequência 3 - Suplicante de Segredos - Templário da Trindade]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
