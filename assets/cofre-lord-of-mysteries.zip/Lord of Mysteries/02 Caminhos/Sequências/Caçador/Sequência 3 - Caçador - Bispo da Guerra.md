---
titulo: "Sequência 3 - Caçador - Bispo da Guerra"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
sequencia: 3
nome_ingles: "War Bishop"
---

# Sequência 3 - Caçador - Bispo da Guerra

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Caçador]]. **Sequência:** 3. **Nome de referência:** War Bishop. Tradução editorial: Bispo da Guerra.

## O que a poção transforma

O [[Poder - Caçador S3 - Autoridade de Bispo da Guerra|pacote completo de Bispo da Guerra]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Bispo da Guerra.

- [[Poder - Caçador S3 - Autoridade de Bispo da Guerra#Formação de guerra|Formação de guerra]]
- [[Poder - Caçador S3 - Autoridade de Bispo da Guerra#Fogo coordenado|Fogo coordenado]]

Operação: [[Poder - Caçador S3 - Autoridade de Bispo da Guerra#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Bispo da Guerra** no tema de rastreio, provocação, fogo e guerra. Princípio de partida: conhecer a presa sem reduzir toda relação a caça. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Caçador#S3 - Bispo da Guerra]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Caçador - Cavaleiro de Sangue e Ferro]]. Próxima: [[Sequência 2 - Caçador - Feiticeiro do Clima]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
