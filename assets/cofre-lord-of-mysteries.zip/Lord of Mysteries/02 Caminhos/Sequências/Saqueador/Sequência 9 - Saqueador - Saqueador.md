---
titulo: "Sequência 9 - Saqueador - Saqueador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 9
nome_ingles: "Marauder"
---

# Sequência 9 - Saqueador - Saqueador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 9. **Nome de referência:** Marauder. Tradução editorial: Saqueador.

## O que a poção transforma

O [[Poder - Saqueador S9 - Mãos do intervalo|pacote completo de Saqueador]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Olho para o valioso.

- [[Poder - Saqueador S9 - Mãos do intervalo#Mão leve|Mão leve]]
- [[Poder - Saqueador S9 - Mãos do intervalo#Dedos extraordinários|Dedos extraordinários]]
- [[Poder - Saqueador S9 - Mãos do intervalo#Inventário observado|Inventário observado]]



## Atuação e digestão

Interpretação original do papel **Saqueador** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S9 - Saqueador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Saqueador - Vigarista]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
