---
titulo: "Sequência 1 - Aprendiz - Chave das Estrelas"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 1
nome_ingles: "Key of Stars"
---

# Sequência 1 - Aprendiz - Chave das Estrelas

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 1. **Nome de referência:** Key of Stars. Tradução editorial: Chave das Estrelas.

## O que a poção transforma

O [[Poder - Aprendiz S1 - Autoridade de Chave das Estrelas|pacote completo de Chave das Estrelas]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Chave das Estrelas.

- [[Poder - Aprendiz S1 - Autoridade de Chave das Estrelas#Fixar coordenada|Fixar coordenada]]
- [[Poder - Aprendiz S1 - Autoridade de Chave das Estrelas#Chave estelar|Chave estelar]]

Operação: [[Poder - Aprendiz S1 - Autoridade de Chave das Estrelas#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Chave das Estrelas** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S1 - Chave das Estrelas]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Aprendiz - Caminhante dos Planos]]. Próxima: [[Sequência 0 - Aprendiz - Porta]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
