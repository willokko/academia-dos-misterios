---
titulo: "Sequência 6 - Prisioneiro - Zumbi"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 6
nome_ingles: "Zombie"
---

# Sequência 6 - Prisioneiro - Zumbi

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 6. **Nome de referência:** Zombie. Tradução editorial: Zumbi.

## O que a poção transforma

O [[Poder - Prisioneiro S6 - Corpo do frio|pacote completo de Zumbi]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Corpo de zumbi.

- [[Poder - Prisioneiro S6 - Corpo do frio#Gelo sepulcral|Gelo sepulcral]]
- [[Poder - Prisioneiro S6 - Corpo do frio#Aura de decadência|Aura de decadência]]
- [[Poder - Prisioneiro S6 - Corpo do frio#Recuperação cadavérica|Recuperação cadavérica]]



## Atuação e digestão

Interpretação original do papel **Zumbi** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S6 - Zumbi]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Prisioneiro - Lobisomem]]. Próxima: [[Sequência 5 - Prisioneiro - Espectro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
