---
titulo: "Sequência 8 - Guerreiro - Pugilista"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
sequencia: 8
nome_ingles: "Pugilist"
---

# Sequência 8 - Guerreiro - Pugilista

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Guerreiro]]. **Sequência:** 8. **Nome de referência:** Pugilist. Tradução editorial: Pugilista.

## O que a poção transforma

O [[Poder - Guerreiro S8 - Golpe de pugilista|pacote completo de Pugilista]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Punhos de aço.

- [[Poder - Guerreiro S8 - Golpe de pugilista#Golpe demolidor|Golpe demolidor]]
- [[Poder - Guerreiro S8 - Golpe de pugilista#Imobilização|Imobilização]]
- [[Poder - Guerreiro S8 - Golpe de pugilista#Defesa corporal|Defesa corporal]]



## Atuação e digestão

Interpretação original do papel **Pugilista** no tema de força, armas, proteção e declínio. Princípio de partida: escolher o que proteger e conhecer o limite da força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Guerreiro#S8 - Pugilista]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Guerreiro - Guerreiro]]. Próxima: [[Sequência 7 - Guerreiro - Mestre das Armas]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
