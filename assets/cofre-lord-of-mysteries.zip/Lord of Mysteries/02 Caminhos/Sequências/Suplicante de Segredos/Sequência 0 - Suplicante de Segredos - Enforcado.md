---
titulo: "Sequência 0 - Suplicante de Segredos - Enforcado"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
sequencia: 0
nome_ingles: "Hanged Man"
---

# Sequência 0 - Suplicante de Segredos - Enforcado

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Suplicante de Segredos]]. **Sequência:** 0. **Nome de referência:** Hanged Man. Tradução editorial: Enforcado.

## O que a poção transforma

O [[Poder - Suplicante de Segredos S0 - Autoridade de Enforcado|pacote completo de Enforcado]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Enforcado.

- [[Poder - Suplicante de Segredos S0 - Autoridade de Enforcado#Sombra devoradora|Sombra devoradora]]
- [[Poder - Suplicante de Segredos S0 - Autoridade de Enforcado#Carregar o fardo|Carregar o fardo]]

Operação: [[Poder - Suplicante de Segredos S0 - Autoridade de Enforcado#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Enforcado** no tema de escuta perigosa, sombras, carne e almas. Princípio de partida: buscar conhecimento sem entregar a própria responsabilidade à voz que responde. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Suplicante de Segredos#S0 - Enforcado]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Suplicante de Segredos - Anjo Sombrio]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
