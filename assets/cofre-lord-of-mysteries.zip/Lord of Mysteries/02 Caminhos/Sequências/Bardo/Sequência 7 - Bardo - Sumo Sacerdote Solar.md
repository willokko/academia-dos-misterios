---
titulo: "Sequência 7 - Bardo - Sumo Sacerdote Solar"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 7
nome_ingles: "Solar High Priest"
---

# Sequência 7 - Bardo - Sumo Sacerdote Solar

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 7. **Nome de referência:** Solar High Priest. Tradução editorial: Sumo Sacerdote Solar.

## O que a poção transforma

O [[Poder - Bardo S7 - Bênção de vigília|pacote completo de Sumo Sacerdote Solar]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Ofício solar.

- [[Poder - Bardo S7 - Bênção de vigília#Bênção de luz|Bênção de luz]]
- [[Poder - Bardo S7 - Bênção de vigília#Chama purificadora|Chama purificadora]]
- [[Poder - Bardo S7 - Bênção de vigília#Círculo consagrado|Círculo consagrado]]



## Atuação e digestão

Interpretação original do papel **Sumo Sacerdote Solar** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S7 - Sumo Sacerdote Solar]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Bardo - Suplicante da Luz]]. Próxima: [[Sequência 6 - Bardo - Notário]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
