---
titulo: "Sequência 9 - Coletor de Cadáveres - Coletor de Cadáveres"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 9
nome_ingles: "Corpse Collector"
---

# Sequência 9 - Coletor de Cadáveres - Coletor de Cadáveres

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 9. **Nome de referência:** Corpse Collector. Tradução editorial: Coletor de Cadáveres.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S9 - Exame do último vestígio|pacote completo de Coletor de Cadáveres]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Olho da morte; Ofício funerário.

- [[Poder - Coletor de Cadáveres S9 - Exame do último vestígio#Ler os restos|Ler os restos]]
- [[Poder - Coletor de Cadáveres S9 - Exame do último vestígio#Preservar o vestígio|Preservar o vestígio]]
- [[Poder - Coletor de Cadáveres S9 - Exame do último vestígio#Perceber o fim|Perceber o fim]]



## Atuação e digestão

Interpretação original do papel **Coletor de Cadáveres** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S9 - Coletor de Cadáveres]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Coletor de Cadáveres - Coveiro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
