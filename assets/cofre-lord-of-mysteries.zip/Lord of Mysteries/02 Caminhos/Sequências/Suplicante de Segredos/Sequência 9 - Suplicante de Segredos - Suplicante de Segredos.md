---
titulo: "Sequência 9 - Suplicante de Segredos - Suplicante de Segredos"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
sequencia: 9
nome_ingles: "Secrets Suppliant"
---

# Sequência 9 - Suplicante de Segredos - Suplicante de Segredos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Suplicante de Segredos]]. **Sequência:** 9. **Nome de referência:** Secrets Suppliant. Tradução editorial: Suplicante de Segredos.

## O que a poção transforma

O [[Poder - Suplicante de Segredos S9 - Súplica delimitada|pacote completo de Suplicante de Segredos]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Misticismo inquietante.

- [[Poder - Suplicante de Segredos S9 - Súplica delimitada#Ler símbolo|Ler símbolo]]
- [[Poder - Suplicante de Segredos S9 - Súplica delimitada#Preparar oferenda|Preparar oferenda]]
- [[Poder - Suplicante de Segredos S9 - Súplica delimitada#Sondar influência|Sondar influência]]



## Atuação e digestão

Interpretação original do papel **Suplicante de Segredos** no tema de escuta perigosa, sombras, carne e almas. Princípio de partida: buscar conhecimento sem entregar a própria responsabilidade à voz que responde. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Suplicante de Segredos#S9 - Suplicante de Segredos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Suplicante de Segredos - Ouvinte]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
