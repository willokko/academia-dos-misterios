---
titulo: "Sequência 7 - Espreitador de Mistérios - Bruxo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
sequencia: 7
nome_ingles: "Warlock"
---

# Sequência 7 - Espreitador de Mistérios - Bruxo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espreitador de Mistérios]]. **Sequência:** 7. **Nome de referência:** Warlock. Tradução editorial: Bruxo.

## O que a poção transforma

O [[Poder - Espreitador de Mistérios S7 - Fórmula breve|pacote completo de Bruxo]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Feitiçaria.

- [[Poder - Espreitador de Mistérios S7 - Fórmula breve#Raio do bruxo|Raio do bruxo]]
- [[Poder - Espreitador de Mistérios S7 - Fórmula breve#Selo de perturbação|Selo de perturbação]]
- [[Poder - Espreitador de Mistérios S7 - Fórmula breve#Barreira escrita|Barreira escrita]]



## Atuação e digestão

Interpretação original do papel **Bruxo** no tema de conhecimento oculto, símbolos e histórias com poder. Princípio de partida: investigar sem confundir curiosidade com direito a toda resposta. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espreitador de Mistérios#S7 - Bruxo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Espreitador de Mistérios - Erudito Marcial]]. Próxima: [[Sequência 6 - Espreitador de Mistérios - Professor de Pergaminhos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
