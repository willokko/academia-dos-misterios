---
titulo: "Sequência 3 - Boticário - Alto Invocador"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 3
nome_ingles: "High Summoner"
---

# Sequência 3 - Boticário - Alto Invocador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 3. **Nome de referência:** High Summoner. Tradução editorial: Alto Invocador.

## O que a poção transforma

O [[Poder - Boticário S3 - Autoridade de Alto Invocador|pacote completo de Alto Invocador]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Alto Invocador.

- [[Poder - Boticário S3 - Autoridade de Alto Invocador#Chamado superior|Chamado superior]]
- [[Poder - Boticário S3 - Autoridade de Alto Invocador#Portal do pacto|Portal do pacto]]

Operação: [[Poder - Boticário S3 - Autoridade de Alto Invocador#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Alto Invocador** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S3 - Alto Invocador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Boticário - Rei Xamã]]. Próxima: [[Sequência 2 - Boticário - Doador de Vida]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
