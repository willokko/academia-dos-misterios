---
titulo: "Sequência 6 - Coletor de Cadáveres - Guia Espiritual"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 6
nome_ingles: "Spirit Guide"
---

# Sequência 6 - Coletor de Cadáveres - Guia Espiritual

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 6. **Nome de referência:** Spirit Guide. Tradução editorial: Guia Espiritual.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S6 - Guia do limiar|pacote completo de Guia Espiritual]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Guia de almas.

- [[Poder - Coletor de Cadáveres S6 - Guia do limiar#Mensageiro espiritual|Mensageiro espiritual]]
- [[Poder - Coletor de Cadáveres S6 - Guia do limiar#Saída do corpo|Saída do corpo]]
- [[Poder - Coletor de Cadáveres S6 - Guia do limiar#Correntes funerárias|Correntes funerárias]]



## Atuação e digestão

Interpretação original do papel **Guia Espiritual** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S6 - Guia Espiritual]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Coletor de Cadáveres - Médium Espiritual]]. Próxima: [[Sequência 5 - Coletor de Cadáveres - Guardião do Portão]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
