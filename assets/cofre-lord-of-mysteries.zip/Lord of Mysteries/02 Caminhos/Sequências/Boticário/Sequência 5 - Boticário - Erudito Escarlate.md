---
titulo: "Sequência 5 - Boticário - Erudito Escarlate"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 5
nome_ingles: "Scarlet Scholar"
---

# Sequência 5 - Boticário - Erudito Escarlate

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 5. **Nome de referência:** Scarlet Scholar. Tradução editorial: Erudito Escarlate.

## O que a poção transforma

O [[Poder - Boticário S5 - Chamado escarlate|pacote completo de Erudito Escarlate]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Luar escarlate.

- [[Poder - Boticário S5 - Chamado escarlate#Arco lunar|Arco lunar]]
- [[Poder - Boticário S5 - Chamado escarlate#Abrigo escarlate|Abrigo escarlate]]
- [[Poder - Boticário S5 - Chamado escarlate#Invocação lunar|Invocação lunar]]



## Atuação e digestão

Interpretação original do papel **Erudito Escarlate** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S5 - Erudito Escarlate]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Boticário - Professor de Poções]]. Próxima: [[Sequência 4 - Boticário - Rei Xamã]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
