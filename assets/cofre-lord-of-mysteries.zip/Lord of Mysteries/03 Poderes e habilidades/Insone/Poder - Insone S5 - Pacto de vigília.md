---
titulo: "Poder - Insone S5 - Pacto de vigília"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Insone"
sequencia: 5
nome_pacote: "Pacote de Feiticeiro dos Espíritos — Insone S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Insone S5 - Pacto de vigília

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Feiticeiro dos Espíritos, Insone S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Insone - Feiticeiro dos Espíritos]] ou melhor no [[Caminho do Insone]]. **Referência nominal:** Spirit Warlock. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Hospedaria espiritual:** Mantém três espíritos vinculados, um manifesto por vez. Cada qual fornece uma técnica ativa S9–5 da ficha real; não uma iniciativa adicional.

## Técnicas adquiridas

### Acolher espírito

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até liberar |
| Teste | AST+VON ND13 |

Após acordo ou contenção completa, abrigue um espírito disponível. Registre nome, técnica, obrigação e forma de liberá-lo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Comandar manifestação

| Parâmetro | Regra |
|---|---|
| Custo | PM da técnica; trocar custa 0 PM e ação |
| Ação | Conforme técnica |
| Alcance | Cena |
| Duração | Conforme técnica |
| Teste | Conforme técnica |

Use a técnica do espírito ativo com sua ação, atributos e PM. Trocar o espírito manifesto exige uma ação sem custo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Lacre de repouso

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o próximo descanso |
| Teste | AST+VON contra DEF.M |

Uma alma exposta de igual patamar ou menor entra em Lacre 0/6; ao completar, fica dormente num receptáculo preparado até o próximo descanso, sem ser destruída.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 combina vigília e horror local; S2 pode ocultar lugares inteiros, em outro modo de oposição.

## Preparação e oposição

Claridade preparada, alarmes independentes e recusa de isolamento. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Insone]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
