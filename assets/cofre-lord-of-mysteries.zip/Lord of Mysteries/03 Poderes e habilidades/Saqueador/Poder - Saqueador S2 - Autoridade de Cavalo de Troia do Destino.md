---
titulo: "Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Saqueador"
sequencia: 2
nome_pacote: "Pacote de Cavalo de Troia do Destino — Saqueador S2"
quantidade_tecnicas: 2
quantidade_capacidades: 1
quantidade_operacoes: 1
---

# Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Cavalo de Troia do Destino, Saqueador S2.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 2 - Saqueador - Cavalo de Troia do Destino]] ou melhor no [[Caminho do Saqueador]]. **Referência nominal:** Trojan Horse of Destiny. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Transformação de Cavalo de Troia do Destino:** Pode perceber vínculo entre identidade pública e destino quando há história e evidência suficientes.

## Técnicas adquiridas

### Identidade usurpada

| Parâmetro | Regra |
|---|---|
| Custo | 30 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND13 em obstáculo sem ficha |

Assuma uma identidade de NPC previamente dominado por uma cena, incluindo reconhecimento superficial de seus vínculos; não duplica memória sem pesquisa.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

### Roubar conexão

| Parâmetro | Regra |
|---|---|
| Custo | 30 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND13 em obstáculo sem ficha |

Suspenda um vínculo externo percebido por uma rodada; não rouba a autoridade inteira da fonte.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

## Feito de operação

Trocar a identidade de destino de um pacto investigado sem produzir novas características.

**Procedimento:** [[Módulo angelical e divino]]. Reúna três chaves, declare alvo, transformação e consequência do perigo. O portador inicia uma vez por operação, ação Poder, 30 PM e primeiro teste ND13; objetivo de 12 seções. Cada PJ contribui uma vez por rodada com Objetivo e margens normais, sem pagar novamente a taxa. Não use esse relógio para atrasar as aplicações locais sem oposição equivalente.

## Evolução e acúmulo

Conserva todos os pacotes anteriores. O novo grau amplia a natureza do que pode fazer, não soma automaticamente dano ou bônus de todas as formas. Capacidades de operação seguem seu módulo e Escala e confrontos sobrenaturais.

## Preparação e oposição

Vigilância cruzada, vínculos protegidos e ações sem habilidade ativa. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Saqueador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
