---
titulo: "Sequência 8 - Sábio - Arqueólogo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 8
nome_ingles: "Archaeologist"
---

# Sequência 8 - Sábio - Arqueólogo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 8. **Nome de referência:** Archaeologist. Tradução editorial: Arqueólogo.

## O que a poção transforma

O [[Poder - Sábio S8 - Camadas do tempo|pacote completo de Arqueólogo]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Olhar arqueológico.

- [[Poder - Sábio S8 - Camadas do tempo#Ler a ruína|Ler a ruína]]
- [[Poder - Sábio S8 - Camadas do tempo#Verificar autenticidade|Verificar autenticidade]]
- [[Poder - Sábio S8 - Camadas do tempo#Desmontagem prudente|Desmontagem prudente]]



## Atuação e digestão

Interpretação original do papel **Arqueólogo** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S8 - Arqueólogo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Sábio - Sábio]]. Próxima: [[Sequência 7 - Sábio - Avaliador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
