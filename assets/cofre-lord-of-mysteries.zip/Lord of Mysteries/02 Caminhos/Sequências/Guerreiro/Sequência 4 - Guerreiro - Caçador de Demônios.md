---
titulo: "Sequência 4 - Guerreiro - Caçador de Demônios"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
sequencia: 4
nome_ingles: "Demon Hunter"
---

# Sequência 4 - Guerreiro - Caçador de Demônios

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Guerreiro]]. **Sequência:** 4. **Nome de referência:** Demon Hunter. Tradução editorial: Caçador de Demônios.

## O que a poção transforma

O [[Poder - Guerreiro S4 - Autoridade de Caçador de Demônios|pacote completo de Caçador de Demônios]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Caçador de Demônios.

- [[Poder - Guerreiro S4 - Autoridade de Caçador de Demônios#Marca do caçador|Marca do caçador]]
- [[Poder - Guerreiro S4 - Autoridade de Caçador de Demônios#Unguento de caça|Unguento de caça]]

Operação: [[Poder - Guerreiro S4 - Autoridade de Caçador de Demônios#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Caçador de Demônios** no tema de força, armas, proteção e declínio. Princípio de partida: escolher o que proteger e conhecer o limite da força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Guerreiro#S4 - Caçador de Demônios]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Guerreiro - Guardião]]. Próxima: [[Sequência 3 - Guerreiro - Cavaleiro de Prata]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
