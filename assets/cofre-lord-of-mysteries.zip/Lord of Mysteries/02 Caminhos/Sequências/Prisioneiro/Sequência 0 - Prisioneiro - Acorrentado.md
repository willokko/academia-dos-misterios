---
titulo: "Sequência 0 - Prisioneiro - Acorrentado"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 0
nome_ingles: "Chained"
---

# Sequência 0 - Prisioneiro - Acorrentado

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 0. **Nome de referência:** Chained. Tradução editorial: Acorrentado.

## O que a poção transforma

O [[Poder - Prisioneiro S0 - Autoridade de Acorrentado|pacote completo de Acorrentado]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Acorrentado.

- [[Poder - Prisioneiro S0 - Autoridade de Acorrentado#Grilhão de autoridade|Grilhão de autoridade]]
- [[Poder - Prisioneiro S0 - Autoridade de Acorrentado#Prisão e libertação|Prisão e libertação]]

Operação: [[Poder - Prisioneiro S0 - Autoridade de Acorrentado#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Acorrentado** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S0 - Acorrentado]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Prisioneiro - Abominação]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
