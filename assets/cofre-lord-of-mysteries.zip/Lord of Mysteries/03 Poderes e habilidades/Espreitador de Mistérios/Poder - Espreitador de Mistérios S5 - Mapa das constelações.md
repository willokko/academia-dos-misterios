---
titulo: "Poder - Espreitador de Mistérios S5 - Mapa das constelações"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espreitador de Mistérios"
sequencia: 5
nome_pacote: "Pacote de Mestre das Constelações — Espreitador de Mistérios S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Espreitador de Mistérios S5 - Mapa das constelações

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Mestre das Constelações, Espreitador de Mistérios S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Espreitador de Mistérios - Mestre das Constelações]] ou melhor no [[Caminho do Espreitador de Mistérios]]. **Referência nominal:** Constellations Master. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Leitura estelar:** Percebe correspondências entre símbolos estelares e vínculos presentes; não inventa poderes de outras entidades.

## Técnicas adquiridas

### Ponte constelada

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON ND13 |

Una dois pontos conhecidos da cena por projeção luminosa. Até dois voluntários podem atravessar com suas ações; não atravessa selo superior.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Lança das constelações

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+25 de dano luz em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Mapa das correspondências

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Com carta e vestígio, encontre uma chave simbólica para um ritual maior ou uma ocultação investigada. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S4 usa histórias e correspondências como fontes de fenômenos; cada mito precisa ser pesquisado, não inventado na ativação.

## Preparação e oposição

Informação falsa, falta de correspondência e revelação vedada. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espreitador de Mistérios]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
