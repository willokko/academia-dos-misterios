---
titulo: "Caminho do Vidente"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
nome_divino: "Louco"
referencia: "https://lordofthemysteries.fandom.com/wiki/Fool_Pathway"
---

# Caminho do Vidente

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Louco. **Tema:** Presságios, máscaras e controle por vínculos espirituais. **Função:** Investigação, infiltração e controle preparado.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Vidente - Vidente|Vidente]] | [[Poder - Vidente S9 - Olhar para o presságio|3 técnicas]] |
| 8 | [[Sequência 8 - Vidente - Palhaço|Palhaço]] | [[Poder - Vidente S8 - Equilíbrio do palhaço|3 técnicas]] |
| 7 | [[Sequência 7 - Vidente - Mágico|Mágico]] | [[Poder - Vidente S7 - Truques do palco velado|6 técnicas]] |
| 6 | [[Sequência 6 - Vidente - Sem Rosto|Sem Rosto]] | [[Poder - Vidente S6 - Máscara sem rosto|3 técnicas]] |
| 5 | [[Sequência 5 - Vidente - Marionetista|Marionetista]] | [[Poder - Vidente S5 - Fios da marionete|3 técnicas]] |
| 4 | [[Sequência 4 - Vidente - Feiticeiro Bizarro|Feiticeiro Bizarro]] | [[Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Vidente - Erudito do Passado|Erudito do Passado]] | [[Poder - Vidente S3 - Autoridade de Erudito do Passado|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Vidente - Invocador de Milagres|Invocador de Milagres]] | [[Poder - Vidente S2 - Autoridade de Invocador de Milagres|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Vidente - Servidor dos Mistérios|Servidor dos Mistérios]] | [[Poder - Vidente S1 - Autoridade de Servidor dos Mistérios|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Vidente - Louco|Louco]] | [[Poder - Vidente S0 - Autoridade de Louco|2 técnicas + operação]] |

## Como jogar

Interpretar sinais sem confundir previsão com certeza. As ferramentas da S9 são visão espiritual, artes divinatórias. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: informação e marionetes. **Oposição:** Ocultação de vínculos, identidades verificadas por relações e interrupção de preparação. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Vidente]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Fool_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
