---
titulo: "Sequência 1 - Árbitro - Mão da Ordem"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 1
nome_ingles: "Hand of Order"
---

# Sequência 1 - Árbitro - Mão da Ordem

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 1. **Nome de referência:** Hand of Order. Tradução editorial: Mão da Ordem.

## O que a poção transforma

O [[Poder - Árbitro S1 - Autoridade de Mão da Ordem|pacote completo de Mão da Ordem]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Mão da Ordem.

- [[Poder - Árbitro S1 - Autoridade de Mão da Ordem#Mão da ordem|Mão da ordem]]
- [[Poder - Árbitro S1 - Autoridade de Mão da Ordem#Domínio legislado|Domínio legislado]]

Operação: [[Poder - Árbitro S1 - Autoridade de Mão da Ordem#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Mão da Ordem** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S1 - Mão da Ordem]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Árbitro - Equilibrador]]. Próxima: [[Sequência 0 - Árbitro - Justiceiro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
