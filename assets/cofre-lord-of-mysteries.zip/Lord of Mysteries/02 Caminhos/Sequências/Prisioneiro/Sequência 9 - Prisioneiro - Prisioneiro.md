---
titulo: "Sequência 9 - Prisioneiro - Prisioneiro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 9
nome_ingles: "Prisoner"
---

# Sequência 9 - Prisioneiro - Prisioneiro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 9. **Nome de referência:** Prisoner. Tradução editorial: Prisioneiro.

## O que a poção transforma

O [[Poder - Prisioneiro S9 - Limites da cela|pacote completo de Prisioneiro]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Corpo encarcerado.

- [[Poder - Prisioneiro S9 - Limites da cela#Romper grilhões|Romper grilhões]]
- [[Poder - Prisioneiro S9 - Limites da cela#Violência contida|Violência contida]]
- [[Poder - Prisioneiro S9 - Limites da cela#Disciplina do limite|Disciplina do limite]]



## Atuação e digestão

Interpretação original do papel **Prisioneiro** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S9 - Prisioneiro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Prisioneiro - Lunático]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
