---
titulo: "Poder - Espreitador de Mistérios S9 - Anotação do oculto"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espreitador de Mistérios"
sequencia: 9
nome_pacote: "Pacote de Espreitador de Mistérios — Espreitador de Mistérios S9"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Espreitador de Mistérios S9 - Anotação do oculto

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Espreitador de Mistérios, Espreitador de Mistérios S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Espreitador de Mistérios - Espreitador de Mistérios]] ou melhor no [[Caminho do Espreitador de Mistérios]]. **Referência nominal:** Mystery Pryer. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Olhos do mistério:** Vê espíritos e inscrições ocultas expostas a percepção espiritual. Não deve encarar revelação vedada sem proteção; pode fechar o foco.
- **Conhecimento não solicitado:** Uma fonte de saber intrusiva é tratada como perigo anunciado em cena, nunca como licença para o mestre punir qualquer falha.

## Técnicas adquiridas

### Escrutínio oculto

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Descubra função e uma correspondência de símbolo espiritual acessível. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Divinação por sinais

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Com vestígio e instrumento, receba tendência ou direção limitada, sem solução completa. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Traçar proteção

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

Um sinal pertinente dá +2 ao próximo teste de ritual de proteção que já possa realizar.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S8 acrescenta corpo e combate; olhar não autoriza conhecer toda fórmula.

## Preparação e oposição

Informação falsa, falta de correspondência e revelação vedada. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espreitador de Mistérios]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
