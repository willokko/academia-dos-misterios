---
titulo: "Sequência 3 - Plantador - Portador do Caixão"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
sequencia: 3
nome_ingles: "Pallbearer"
---

# Sequência 3 - Plantador - Portador do Caixão

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Plantador]]. **Sequência:** 3. **Nome de referência:** Pallbearer. Tradução editorial: Portador do Caixão.

## O que a poção transforma

O [[Poder - Plantador S3 - Autoridade de Portador do Caixão|pacote completo de Portador do Caixão]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Portador do Caixão.

- [[Poder - Plantador S3 - Autoridade de Portador do Caixão#Caixão de contenção|Caixão de contenção]]
- [[Poder - Plantador S3 - Autoridade de Portador do Caixão#Fardo compartilhado|Fardo compartilhado]]

Operação: [[Poder - Plantador S3 - Autoridade de Portador do Caixão#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Portador do Caixão** no tema de cultivo, medicina, vida e transformações orgânicas. Princípio de partida: cultivar condições para que outros vivam sem possuir seu futuro. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Plantador#S3 - Portador do Caixão]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Plantador - Alquimista Antigo]]. Próxima: [[Sequência 2 - Plantador - Matriarca da Desolação]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
