---
titulo: "Sequência 0 - Advogado - Imperador Negro"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
sequencia: 0
nome_ingles: "Black Emperor"
---

# Sequência 0 - Advogado - Imperador Negro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Advogado]]. **Sequência:** 0. **Nome de referência:** Black Emperor. Tradução editorial: Imperador Negro.

## O que a poção transforma

O [[Poder - Advogado S0 - Autoridade de Imperador Negro|pacote completo de Imperador Negro]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Imperador Negro.

- [[Poder - Advogado S0 - Autoridade de Imperador Negro#Distorção soberana|Distorção soberana]]
- [[Poder - Advogado S0 - Autoridade de Imperador Negro#Retorno pela ordem|Retorno pela ordem]]

Operação: [[Poder - Advogado S0 - Autoridade de Imperador Negro#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Imperador Negro** no tema de brechas, suborno e distorção de regras. Princípio de partida: conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Advogado#S0 - Imperador Negro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Advogado - Príncipe da Abolição]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
