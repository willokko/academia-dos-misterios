---
titulo: "Sequência 9 - Plantador - Plantador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
sequencia: 9
nome_ingles: "Planter"
---

# Sequência 9 - Plantador - Plantador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Plantador]]. **Sequência:** 9. **Nome de referência:** Planter. Tradução editorial: Plantador.

## O que a poção transforma

O [[Poder - Plantador S9 - Leitura do solo|pacote completo de Plantador]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Mestre do cultivo.

- [[Poder - Plantador S9 - Leitura do solo#Ler o tempo|Ler o tempo]]
- [[Poder - Plantador S9 - Leitura do solo#Examinar a terra|Examinar a terra]]
- [[Poder - Plantador S9 - Leitura do solo#Força de cultivo|Força de cultivo]]



## Atuação e digestão

Interpretação original do papel **Plantador** no tema de cultivo, medicina, vida e transformações orgânicas. Princípio de partida: cultivar condições para que outros vivam sem possuir seu futuro. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Plantador#S9 - Plantador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Plantador - Médico]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
