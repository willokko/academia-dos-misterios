---
titulo: "Sequência 4 - Advogado - Conde dos Caídos"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
sequencia: 4
nome_ingles: "Earl of the Fallen"
---

# Sequência 4 - Advogado - Conde dos Caídos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Advogado]]. **Sequência:** 4. **Nome de referência:** Earl of the Fallen. Tradução editorial: Conde dos Caídos.

## O que a poção transforma

O [[Poder - Advogado S4 - Autoridade de Conde dos Caídos|pacote completo de Conde dos Caídos]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Conde dos Caídos.

- [[Poder - Advogado S4 - Autoridade de Conde dos Caídos#Explorar estado|Explorar estado]]
- [[Poder - Advogado S4 - Autoridade de Conde dos Caídos#Magnificar efeito|Magnificar efeito]]

Operação: [[Poder - Advogado S4 - Autoridade de Conde dos Caídos#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Conde dos Caídos** no tema de brechas, suborno e distorção de regras. Princípio de partida: conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Advogado#S4 - Conde dos Caídos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Advogado - Mentor da Desordem]]. Próxima: [[Sequência 3 - Advogado - Mago Frenético]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
