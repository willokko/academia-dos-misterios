---
titulo: "Condições"
tipo: "regras-fundamentais"
origem: "oficial-fu"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/oficial-fu"]
---

# Condições

> [!info] Regra oficial resumida
> Paráfrase do livro básico local. Consulte [[Fontes de Fabula Ultima]] para páginas e limitações.

| Condição | Redução temporária |
|---|---|
| Abalado | VON em um passo |
| Atordoado | AST em um passo |
| Fraco | VIG em um passo |
| Lento | DES em um passo |
| Enfurecido | DES e AST em um passo |
| Envenenado | VIG e VON em um passo |

O dado nunca cai abaixo de d6. Condições diferentes acumulam suas reduções; repetir a mesma condição não acrescenta outra redução. Alterar dado atual não altera os máximos de PV/PM calculados pelo dado básico. Reduzir DES ou AST altera as defesas que usam o dado atual. Recuperação e imunidade seguem o básico, pp. 94–95.

Sono, petrificação e transformação não são automaticamente condições desta tabela. Os poderes desta adaptação dizem precisamente o que restringem. Nenhuma menção a medo ou influência emocional concede controle total sobre um PJ.

[[Corrupção]] e [[Digestão e atuação]] são relógios originais, não condições removidas por Purificar. Um alvo pode ficar abalado por um susto sem adquirir Corrupção.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
