---
titulo: "Sequência 7 - Criminoso - Assassino em Série"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 7
nome_ingles: "Serial Killer"
---

# Sequência 7 - Criminoso - Assassino em Série

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 7. **Nome de referência:** Serial Killer. Tradução editorial: Assassino em Série.

## O que a poção transforma

O [[Poder - Criminoso S7 - Padrão predatório|pacote completo de Assassino em Série]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Ritual de perseguição.

- [[Poder - Criminoso S7 - Padrão predatório#Marca predatória|Marca predatória]]
- [[Poder - Criminoso S7 - Padrão predatório#Pressão da presa|Pressão da presa]]
- [[Poder - Criminoso S7 - Padrão predatório#Ataque ritualizado|Ataque ritualizado]]



## Atuação e digestão

Interpretação original do papel **Assassino em Série** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S7 - Assassino em Série]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Criminoso - Anjo sem Asas]]. Próxima: [[Sequência 6 - Criminoso - Diabo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
