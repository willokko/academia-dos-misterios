---
titulo: "Sequência 9 - Bardo - Bardo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 9
nome_ingles: "Bard"
---

# Sequência 9 - Bardo - Bardo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 9. **Nome de referência:** Bard. Tradução editorial: Bardo.

## O que a poção transforma

O [[Poder - Bardo S9 - Verso de coragem|pacote completo de Bardo]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Inspiração.

- [[Poder - Bardo S9 - Verso de coragem#Canto de coragem|Canto de coragem]]
- [[Poder - Bardo S9 - Verso de coragem#Canto de vigor|Canto de vigor]]
- [[Poder - Bardo S9 - Verso de coragem#Conhecer a assembleia|Conhecer a assembleia]]



## Atuação e digestão

Interpretação original do papel **Bardo** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S9 - Bardo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Bardo - Suplicante da Luz]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
