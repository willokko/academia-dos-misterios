---
titulo: "Sequência 6 - Assassino - Prazer"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 6
nome_ingles: "Pleasure"
---

# Sequência 6 - Assassino - Prazer

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 6. **Nome de referência:** Pleasure. Tradução editorial: Prazer.

## O que a poção transforma

O [[Poder - Assassino S6 - Fio de fascínio|pacote completo de Prazer]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Fios sutis.

- [[Poder - Assassino S6 - Fio de fascínio#Fios de contenção|Fios de contenção]]
- [[Poder - Assassino S6 - Fio de fascínio#Casulo|Casulo]]
- [[Poder - Assassino S6 - Fio de fascínio#Presença fascinante|Presença fascinante]]



## Atuação e digestão

Interpretação original do papel **Prazer** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S6 - Prazer]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Assassino - Bruxa]]. Próxima: [[Sequência 5 - Assassino - Aflição]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
