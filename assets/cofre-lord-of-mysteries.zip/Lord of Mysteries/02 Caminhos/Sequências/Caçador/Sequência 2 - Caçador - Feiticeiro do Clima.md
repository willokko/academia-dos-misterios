---
titulo: "Sequência 2 - Caçador - Feiticeiro do Clima"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
sequencia: 2
nome_ingles: "Weather Warlock"
---

# Sequência 2 - Caçador - Feiticeiro do Clima

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Caçador]]. **Sequência:** 2. **Nome de referência:** Weather Warlock. Tradução editorial: Feiticeiro do Clima.

## O que a poção transforma

O [[Poder - Caçador S2 - Autoridade de Feiticeiro do Clima|pacote completo de Feiticeiro do Clima]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Feiticeiro do Clima.

- [[Poder - Caçador S2 - Autoridade de Feiticeiro do Clima#Clima de batalha|Clima de batalha]]
- [[Poder - Caçador S2 - Autoridade de Feiticeiro do Clima#Arma da tormenta|Arma da tormenta]]

Operação: [[Poder - Caçador S2 - Autoridade de Feiticeiro do Clima#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Feiticeiro do Clima** no tema de rastreio, provocação, fogo e guerra. Princípio de partida: conhecer a presa sem reduzir toda relação a caça. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Caçador#S2 - Feiticeiro do Clima]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Caçador - Bispo da Guerra]]. Próxima: [[Sequência 1 - Caçador - Conquistador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
