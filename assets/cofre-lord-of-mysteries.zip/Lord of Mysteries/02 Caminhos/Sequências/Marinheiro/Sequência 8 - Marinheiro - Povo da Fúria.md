---
titulo: "Sequência 8 - Marinheiro - Povo da Fúria"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 8
nome_ingles: "Folk of Rage"
---

# Sequência 8 - Marinheiro - Povo da Fúria

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 8. **Nome de referência:** Folk of Rage. Tradução editorial: Povo da Fúria.

## O que a poção transforma

O [[Poder - Marinheiro S8 - Investida da fúria|pacote completo de Povo da Fúria]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Vigor tempestuoso; Fúria escolhida.

- [[Poder - Marinheiro S8 - Investida da fúria#Ira da tempestade|Ira da tempestade]]
- [[Poder - Marinheiro S8 - Investida da fúria#Impacto furioso|Impacto furioso]]
- [[Poder - Marinheiro S8 - Investida da fúria#Acumular o golpe|Acumular o golpe]]



## Atuação e digestão

Interpretação original do papel **Povo da Fúria** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S8 - Povo da Fúria]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Marinheiro - Marinheiro]]. Próxima: [[Sequência 7 - Marinheiro - Navegante]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
