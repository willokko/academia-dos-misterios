---
titulo: "Sequência 2 - Advogado - Duque da Entropia"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
sequencia: 2
nome_ingles: "Duke of Entropy"
---

# Sequência 2 - Advogado - Duque da Entropia

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Advogado]]. **Sequência:** 2. **Nome de referência:** Duke of Entropy. Tradução editorial: Duque da Entropia.

## O que a poção transforma

O [[Poder - Advogado S2 - Autoridade de Duque da Entropia|pacote completo de Duque da Entropia]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Duque da Entropia.

- [[Poder - Advogado S2 - Autoridade de Duque da Entropia#Entropia local|Entropia local]]
- [[Poder - Advogado S2 - Autoridade de Duque da Entropia#Distância desordenada|Distância desordenada]]

Operação: [[Poder - Advogado S2 - Autoridade de Duque da Entropia#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Duque da Entropia** no tema de brechas, suborno e distorção de regras. Princípio de partida: conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Advogado#S2 - Duque da Entropia]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Advogado - Mago Frenético]]. Próxima: [[Sequência 1 - Advogado - Príncipe da Abolição]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
