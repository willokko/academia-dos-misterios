---
titulo: "Sequência 0 - Boticário - Lua"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 0
nome_ingles: "Moon"
---

# Sequência 0 - Boticário - Lua

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 0. **Nome de referência:** Moon. Tradução editorial: Lua.

## O que a poção transforma

O [[Poder - Boticário S0 - Autoridade de Lua|pacote completo de Lua]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Lua.

- [[Poder - Boticário S0 - Autoridade de Lua#Lua no domínio|Lua no domínio]]
- [[Poder - Boticário S0 - Autoridade de Lua#Pacto de vida|Pacto de vida]]

Operação: [[Poder - Boticário S0 - Autoridade de Lua#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Lua** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S0 - Lua]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Boticário - Deusa da Beleza]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
