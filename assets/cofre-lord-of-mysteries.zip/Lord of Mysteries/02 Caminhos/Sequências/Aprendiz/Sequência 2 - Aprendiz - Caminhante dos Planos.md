---
titulo: "Sequência 2 - Aprendiz - Caminhante dos Planos"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 2
nome_ingles: "Planeswalker"
---

# Sequência 2 - Aprendiz - Caminhante dos Planos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 2. **Nome de referência:** Planeswalker. Tradução editorial: Caminhante dos Planos.

## O que a poção transforma

O [[Poder - Aprendiz S2 - Autoridade de Caminhante dos Planos|pacote completo de Caminhante dos Planos]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Caminhante dos Planos.

- [[Poder - Aprendiz S2 - Autoridade de Caminhante dos Planos#Replicar passagem|Replicar passagem]]
- [[Poder - Aprendiz S2 - Autoridade de Caminhante dos Planos#Plano projetado|Plano projetado]]

Operação: [[Poder - Aprendiz S2 - Autoridade de Caminhante dos Planos#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Caminhante dos Planos** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S2 - Caminhante dos Planos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Aprendiz - Andarilho]]. Próxima: [[Sequência 1 - Aprendiz - Chave das Estrelas]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
