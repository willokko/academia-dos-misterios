---
titulo: "Contrato de campanha"
tipo: "início"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Contrato de campanha

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

Antes de jogar, registre época, cidade e se os jogadores conhecem o romance. Spoilers são permitidos neste cofre, mas a mesa pode preferir descobertas graduais. A aventura inclui possessão, coerção e mortos; ajuste sua descrição ao combinado.

Defina como serão tratadas transformações corporais, perda de identidade, horror e atuação de Caminhos cruéis. Mudanças de corpo ou gênero importantes na obra são discutidas previamente com quem joga; esta adaptação não impõe uma transformação pessoal sem acordo. O princípio ficcional pode ser representado por máscara, manifestação, sonho ou transformação escolhida, registrando a alteração de cenário.

Os PJs precisam de um motivo para cooperar e de pelo menos uma pessoa que pretendem proteger. Controle mental da camada de Caminho não autoriza PvP involuntário. O jogador pode resumir uma cena desconfortável, pedir pausa ou alterar sua representação, sem perder digestão por isso.

**Registro da mesa:** época __; cidade __; tema __; assuntos fora de cena __; formas de pausa __; política de spoiler __; limite de progressão __; mudanças de cenário aprovadas __.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
