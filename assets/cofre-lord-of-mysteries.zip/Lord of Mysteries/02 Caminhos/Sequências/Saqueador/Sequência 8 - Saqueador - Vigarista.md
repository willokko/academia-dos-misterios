---
titulo: "Sequência 8 - Saqueador - Vigarista"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 8
nome_ingles: "Swindler"
---

# Sequência 8 - Saqueador - Vigarista

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 8. **Nome de referência:** Swindler. Tradução editorial: Vigarista.

## O que a poção transforma

O [[Poder - Saqueador S8 - Proposta enviesada|pacote completo de Vigarista]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Persuasão do vigarista.

- [[Poder - Saqueador S8 - Proposta enviesada#Pergunta enviesada|Pergunta enviesada]]
- [[Poder - Saqueador S8 - Proposta enviesada#Desviar atenção|Desviar atenção]]
- [[Poder - Saqueador S8 - Proposta enviesada#Cobertura convincente|Cobertura convincente]]



## Atuação e digestão

Interpretação original do papel **Vigarista** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S8 - Vigarista]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Saqueador - Saqueador]]. Próxima: [[Sequência 7 - Saqueador - Criptologista]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
