---
titulo: "Sequência 5 - Saqueador - Ladrão de Sonhos"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 5
nome_ingles: "Dream Stealer"
---

# Sequência 5 - Saqueador - Ladrão de Sonhos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 5. **Nome de referência:** Dream Stealer. Tradução editorial: Ladrão de Sonhos.

## O que a poção transforma

O [[Poder - Saqueador S5 - Subtrair a intenção|pacote completo de Ladrão de Sonhos]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Intenção imediata.

- [[Poder - Saqueador S5 - Subtrair a intenção#Subtrair intenção|Subtrair intenção]]
- [[Poder - Saqueador S5 - Subtrair a intenção#Roubar um ataque|Roubar um ataque]]
- [[Poder - Saqueador S5 - Subtrair a intenção#Tomar uma faculdade|Tomar uma faculdade]]



## Atuação e digestão

Interpretação original do papel **Ladrão de Sonhos** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S5 - Ladrão de Sonhos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Saqueador - Prometeu]]. Próxima: [[Sequência 4 - Saqueador - Parasita]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
