---
titulo: "Sequência 7 - Saqueador - Criptologista"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 7
nome_ingles: "Cryptologist"
---

# Sequência 7 - Saqueador - Criptologista

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 7. **Nome de referência:** Cryptologist. Tradução editorial: Criptologista.

## O que a poção transforma

O [[Poder - Saqueador S7 - Chave de leitura|pacote completo de Criptologista]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Decifração.

- [[Poder - Saqueador S7 - Chave de leitura#Quebrar a cifra|Quebrar a cifra]]
- [[Poder - Saqueador S7 - Chave de leitura#Decifrar uma técnica|Decifrar uma técnica]]
- [[Poder - Saqueador S7 - Chave de leitura#Ruído na leitura|Ruído na leitura]]



## Atuação e digestão

Interpretação original do papel **Criptologista** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S7 - Criptologista]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Saqueador - Vigarista]]. Próxima: [[Sequência 6 - Saqueador - Prometeu]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
