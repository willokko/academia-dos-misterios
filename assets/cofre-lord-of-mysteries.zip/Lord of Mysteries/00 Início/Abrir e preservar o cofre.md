---
titulo: "Abrir e preservar o cofre"
tipo: "início"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Abrir e preservar o cofre

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

No Obsidian, escolha **Abrir outro cofre → Abrir pasta como cofre** e selecione `D:\Documentos\Obsidian\Lord of Mysteries`. Abra [[Início]], ou use o marcador de mesmo nome. Não é preciso instalar plugins comunitários.

Para usar a versão compactada, extraia o ZIP em um local de sua escolha e abra a pasta extraída `Lord of Mysteries`, que contém as notas e `.obsidian`. Não tente abrir o ZIP diretamente como cofre. Os PDFs dos livros permanecem na pasta original informada pelo usuário; não estão incluídos.

A pasta `_desenvolvimento` contém os scripts e resultados de auditoria desta edição; não é necessária durante a sessão. **Não execute o construtor sobre suas notas depois de editá-las:** ele regrava os arquivos gerados. Faça uma cópia do cofre antes de experimentar nova geração. Os modelos nativos em `10 Modelos` podem ser inseridos em notas novas sem executar scripts.

O ZIP é uma fotografia da entrega, não sincronização automática. Notas modificadas no Obsidian depois da compactação não aparecem retroativamente no arquivo. Pastas de mestre organizam spoilers, sem impedir acesso aos arquivos.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
