---
titulo: "Sequência 2 - Marinheiro - Calamidade"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 2
nome_ingles: "Calamity"
---

# Sequência 2 - Marinheiro - Calamidade

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 2. **Nome de referência:** Calamity. Tradução editorial: Calamidade.

## O que a poção transforma

O [[Poder - Marinheiro S2 - Autoridade de Calamidade|pacote completo de Calamidade]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Calamidade.

- [[Poder - Marinheiro S2 - Autoridade de Calamidade#Calamidade localizada|Calamidade localizada]]
- [[Poder - Marinheiro S2 - Autoridade de Calamidade#Olho da tormenta|Olho da tormenta]]

Operação: [[Poder - Marinheiro S2 - Autoridade de Calamidade#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Calamidade** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S2 - Calamidade]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Marinheiro - Rei do Mar]]. Próxima: [[Sequência 1 - Marinheiro - Deus do Trovão]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
