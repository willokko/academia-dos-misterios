---
titulo: "Sequência 5 - Vidente - Marionetista"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 5
nome_ingles: "Marionettist"
---

# Sequência 5 - Vidente - Marionetista

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 5. **Nome de referência:** Marionettist. Tradução editorial: Marionetista.

## O que a poção transforma

O [[Poder - Vidente S5 - Fios da marionete|pacote completo de Marionetista]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Visão dos fios; Repertório acumulado.

- [[Poder - Vidente S5 - Fios da marionete#Capturar os fios|Capturar os fios]]
- [[Poder - Vidente S5 - Fios da marionete#Operar marionete|Operar marionete]]
- [[Poder - Vidente S5 - Fios da marionete#Olhos emprestados|Olhos emprestados]]



## Atuação e digestão

Interpretação original do papel **Marionetista** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S5 - Marionetista]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Vidente - Sem Rosto]]. Próxima: [[Sequência 4 - Vidente - Feiticeiro Bizarro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
