---
titulo: "Sequência 1 - Criminoso - Monarca da Imundície"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 1
nome_ingles: "Filthy Monarch"
---

# Sequência 1 - Criminoso - Monarca da Imundície

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 1. **Nome de referência:** Filthy Monarch. Tradução editorial: Monarca da Imundície.

## O que a poção transforma

O [[Poder - Criminoso S1 - Autoridade de Monarca da Imundície|pacote completo de Monarca da Imundície]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Monarca da Imundície.

- [[Poder - Criminoso S1 - Autoridade de Monarca da Imundície#Corromper suporte|Corromper suporte]]
- [[Poder - Criminoso S1 - Autoridade de Monarca da Imundície#Refúgio impuro|Refúgio impuro]]

Operação: [[Poder - Criminoso S1 - Autoridade de Monarca da Imundície#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Monarca da Imundície** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S1 - Monarca da Imundície]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Criminoso - Arquiduque Sangrento]]. Próxima: [[Sequência 0 - Criminoso - Abismo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
