---
titulo: "Sequência 4 - Coletor de Cadáveres - Imorredouro"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 4
nome_ingles: "Undying"
---

# Sequência 4 - Coletor de Cadáveres - Imorredouro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 4. **Nome de referência:** Undying. Tradução editorial: Imorredouro.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro|pacote completo de Imorredouro]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Imorredouro.

- [[Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro#Corpo imorredouro|Corpo imorredouro]]
- [[Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro#Retorno funerário|Retorno funerário]]

Operação: [[Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Imorredouro** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S4 - Imorredouro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Coletor de Cadáveres - Guardião do Portão]]. Próxima: [[Sequência 3 - Coletor de Cadáveres - Barqueiro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
