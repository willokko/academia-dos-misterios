---
titulo: "Sequência 0 - Criminoso - Abismo"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 0
nome_ingles: "Abyss"
---

# Sequência 0 - Criminoso - Abismo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 0. **Nome de referência:** Abyss. Tradução editorial: Abismo.

## O que a poção transforma

O [[Poder - Criminoso S0 - Autoridade de Abismo|pacote completo de Abismo]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Abismo.

- [[Poder - Criminoso S0 - Autoridade de Abismo#Abismo manifesto|Abismo manifesto]]
- [[Poder - Criminoso S0 - Autoridade de Abismo#Vínculo de queda|Vínculo de queda]]

Operação: [[Poder - Criminoso S0 - Autoridade de Abismo#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Abismo** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S0 - Abismo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Criminoso - Monarca da Imundície]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
