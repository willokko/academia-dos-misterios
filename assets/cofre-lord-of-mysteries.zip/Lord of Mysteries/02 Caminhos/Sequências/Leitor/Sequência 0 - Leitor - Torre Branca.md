---
titulo: "Sequência 0 - Leitor - Torre Branca"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 0
nome_ingles: "White Tower"
---

# Sequência 0 - Leitor - Torre Branca

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 0. **Nome de referência:** White Tower. Tradução editorial: Torre Branca.

## O que a poção transforma

O [[Poder - Leitor S0 - Autoridade de Torre Branca|pacote completo de Torre Branca]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Torre Branca.

- [[Poder - Leitor S0 - Autoridade de Torre Branca#Lei compreendida|Lei compreendida]]
- [[Poder - Leitor S0 - Autoridade de Torre Branca#Arquivo manifesto|Arquivo manifesto]]

Operação: [[Poder - Leitor S0 - Autoridade de Torre Branca#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Torre Branca** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S0 - Torre Branca]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Leitor - Olho Onisciente]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
