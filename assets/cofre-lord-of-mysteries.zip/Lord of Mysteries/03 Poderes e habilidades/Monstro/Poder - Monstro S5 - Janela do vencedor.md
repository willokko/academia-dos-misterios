---
titulo: "Poder - Monstro S5 - Janela do vencedor"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Monstro"
sequencia: 5
nome_pacote: "Pacote de Vencedor — Monstro S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Monstro S5 - Janela do vencedor

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Vencedor, Monstro S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Monstro - Vencedor]] ou melhor no [[Caminho do Monstro]]. **Referência nominal:** Winner. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Reserva de sorte:** Pode manter um único presságio favorável preparado, sem nova moeda. Ele é consumido ao usar a técnica associada, não pelo repouso.

## Técnicas adquiridas

### Acumular boa fortuna

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Até gastar |
| Teste | Automático |

Após aceitar um contratempo real sem usar rerrolagem, pague o custo e registre um presságio. Não fabrica contratempos inofensivos nem acumula mais de um.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Virada do vencedor

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Um teste |
| Teste | Automático |

Consuma o presságio para transformar falha comum sua em sucesso básico numa ação de risco plausível. Não muda crítico, concede oportunidade ou vence autoridade superior.

**Limites:** Uma reação por rodada, uma virada por sessão. Um relógio avança uma seção, sem margens extras.

### Maldição de infortúnio

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até um teste nesta cena |
| Teste | AST+VON contra DEF.M |

Em sucesso, o alvo deve refazer um dado de seu próximo teste não crítico e manter o novo resultado. Nunca encadeia nova rolagem.

**Limites:** Um alvo por cena; não obriga refazer crítico. Teto de uma rerrolagem forçada por usuário por rodada.

## Evolução e acúmulo

S4 governa infortúnio deliberado; S1 introduz retorno cíclico por operação, não um botão de desfazer toda sessão.

## Preparação e oposição

Consequências sem teste, escolhas comprometidas e vínculos opacos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Monstro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
