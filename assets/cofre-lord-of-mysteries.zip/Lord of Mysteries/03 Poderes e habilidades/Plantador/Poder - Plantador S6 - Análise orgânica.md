---
titulo: "Poder - Plantador S6 - Análise orgânica"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Plantador"
sequencia: 6
nome_pacote: "Pacote de Biólogo — Plantador S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Plantador S6 - Análise orgânica

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Biólogo, Plantador S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Plantador - Biólogo]] ou melhor no [[Caminho do Plantador]]. **Referência nominal:** Biologist. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Olho do biólogo:** Identifica estrutura funcional de organismo acessível e seus limites prováveis. Mudança não é aprendida por um olhar sobre entidade desconhecida.

## Técnicas adquiridas

### Estudar organismo

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Descubra uma resistência, vulnerabilidade fisiológica ou necessidade ambiental de um ser observado. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Adaptação temporária

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON ND13 |

Você ou voluntário recebe uma adaptação pesquisada: respirar submerso por dez minutos, suportar frio ordinário ou filtrar toxina ordinária conhecida. Um traço por vez.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Cultivar tecido

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Um intervalo de trabalho |
| Alcance | Cena |
| Duração | Permanente ao concluir |
| Teste | AST+AST ND13 |

Com material vivo e atendimento, repare uma função corporal de voluntário por Objetivo 0/6. Uma contribuição por intervalo, sem regeneração instantânea em combate.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5 acrescenta formas e magia terrestre. Alterações corporais de PJ dependem de escolha dele; não imprimem poderes de outros Caminhos.

## Preparação e oposição

Ambiente estéril, escassez de amostra e contaminação da fonte. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Plantador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
