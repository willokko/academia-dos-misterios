---
titulo: "Sequência 2 - Coletor de Cadáveres - Cônsul da Morte"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 2
nome_ingles: "Death Consul"
---

# Sequência 2 - Coletor de Cadáveres - Cônsul da Morte

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 2. **Nome de referência:** Death Consul. Tradução editorial: Cônsul da Morte.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte|pacote completo de Cônsul da Morte]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Cônsul da Morte.

- [[Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte#Ordem dos mortos|Ordem dos mortos]]
- [[Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte#Morte localizada|Morte localizada]]

Operação: [[Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Cônsul da Morte** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S2 - Cônsul da Morte]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Coletor de Cadáveres - Barqueiro]]. Próxima: [[Sequência 1 - Coletor de Cadáveres - Imperador Pálido]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
