---
titulo: "Caminho do Bardo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
nome_divino: "Sol"
referencia: "https://lordofthemysteries.fandom.com/wiki/Sun_Pathway"
---

# Caminho do Bardo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Sol. **Tema:** Luz, purificação, contratos e inspiração. **Função:** Suporte, oposição a assombrações e compromissos.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Bardo - Bardo|Bardo]] | [[Poder - Bardo S9 - Verso de coragem|3 técnicas]] |
| 8 | [[Sequência 8 - Bardo - Suplicante da Luz|Suplicante da Luz]] | [[Poder - Bardo S8 - Luz que denuncia|3 técnicas]] |
| 7 | [[Sequência 7 - Bardo - Sumo Sacerdote Solar|Sumo Sacerdote Solar]] | [[Poder - Bardo S7 - Bênção de vigília|3 técnicas]] |
| 6 | [[Sequência 6 - Bardo - Notário|Notário]] | [[Poder - Bardo S6 - Pacto testemunhado|3 técnicas]] |
| 5 | [[Sequência 5 - Bardo - Sacerdote da Luz|Sacerdote da Luz]] | [[Poder - Bardo S5 - Purificação focal|3 técnicas]] |
| 4 | [[Sequência 4 - Bardo - Sem Sombra|Sem Sombra]] | [[Poder - Bardo S4 - Autoridade de Sem Sombra|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Bardo - Mentor da Justiça|Mentor da Justiça]] | [[Poder - Bardo S3 - Autoridade de Mentor da Justiça|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Bardo - Buscador da Luz|Buscador da Luz]] | [[Poder - Bardo S2 - Autoridade de Buscador da Luz|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Bardo - Anjo Branco|Anjo Branco]] | [[Poder - Bardo S1 - Autoridade de Anjo Branco|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Bardo - Sol|Sol]] | [[Poder - Bardo S0 - Autoridade de Sol|2 técnicas + operação]] |

## Como jogar

Inspirar coragem sem confundir fé com submissão. As ferramentas da S9 são inspiração. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Média: distinguir purificação de solução universal. **Oposição:** Obscurecimento, pactos incompatíveis e fontes superiores. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Bardo]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Sun_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
