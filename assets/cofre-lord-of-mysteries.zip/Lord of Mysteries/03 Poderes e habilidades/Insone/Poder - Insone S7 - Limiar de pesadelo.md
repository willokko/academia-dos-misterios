---
titulo: "Poder - Insone S7 - Limiar de pesadelo"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Insone"
sequencia: 7
nome_pacote: "Pacote de Pesadelo — Insone S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Insone S7 - Limiar de pesadelo

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Pesadelo, Insone S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Insone - Pesadelo]] ou melhor no [[Caminho do Insone]]. **Referência nominal:** Nightmare. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Estado de pesadelo:** Pode separar a percepção do corpo adormecido para visitar sonhos próximos; o corpo fica vulnerável e não ganha outro turno.

## Técnicas adquiridas

### Entrar no sonho

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Uma cena onírica |
| Teste | AST+VON contra DEF.M se resistente |

Entre no sonho de alvo adormecido na mesma região urbana, com vínculo pertinente. Obtenha interação e uma imagem verificável, sem garantia de verdade de toda a memória.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Arrastar ao sonho

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena onírica |
| Teste | AST+VON contra DEF.M |

Abra Sono 0/4 em um alvo da cena e entre com ele ao completar. Seu corpo permanece imóvel; qualquer dano pode romper o contato.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Membros do pesadelo

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+20 de dano trevas em sucesso. Os membros não têm iniciativa ou PV separados.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 amplia apoio à alma; o sonho não é uma ordem que automaticamente se manifesta acordado.

## Preparação e oposição

Claridade preparada, alarmes independentes e recusa de isolamento. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Insone]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
