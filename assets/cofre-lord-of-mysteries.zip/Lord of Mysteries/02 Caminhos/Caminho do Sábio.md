---
titulo: "Caminho do Sábio"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
nome_divino: "Paragon"
referencia: "https://lordofthemysteries.fandom.com/wiki/Paragon_Pathway"
---

# Caminho do Sábio

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Paragon. **Tema:** Memória, técnica, avaliação e fabricação. **Função:** Ferramentas, projetos e suporte preparado.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Sábio - Sábio|Sábio]] | [[Poder - Sábio S9 - Memória de oficina|3 técnicas]] |
| 8 | [[Sequência 8 - Sábio - Arqueólogo|Arqueólogo]] | [[Poder - Sábio S8 - Camadas do tempo|3 técnicas]] |
| 7 | [[Sequência 7 - Sábio - Avaliador|Avaliador]] | [[Poder - Sábio S7 - Avaliar o perigo|3 técnicas]] |
| 6 | [[Sequência 6 - Sábio - Artesão|Artesão]] | [[Poder - Sábio S6 - Oficina de urgência|3 técnicas]] |
| 5 | [[Sequência 5 - Sábio - Astrônomo|Astrônomo]] | [[Poder - Sábio S5 - Instrumento estelar|3 técnicas]] |
| 4 | [[Sequência 4 - Sábio - Alquimista|Alquimista]] | [[Poder - Sábio S4 - Autoridade de Alquimista|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Sábio - Erudito Arcano|Erudito Arcano]] | [[Poder - Sábio S3 - Autoridade de Erudito Arcano|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Sábio - Magíster do Conhecimento|Magíster do Conhecimento]] | [[Poder - Sábio S2 - Autoridade de Magíster do Conhecimento|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Sábio - Iluminador|Iluminador]] | [[Poder - Sábio S1 - Autoridade de Iluminador|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Sábio - Paragon|Paragon]] | [[Poder - Sábio S0 - Autoridade de Paragon|2 técnicas + operação]] |

## Como jogar

Compreender como algo funciona e responder pelas consequências de construí-lo. As ferramentas da S9 são conhecimento do sábio. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: economia de invenções. **Oposição:** Materiais escassos, falta de oficina e defeitos conhecidos. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Sábio]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Paragon_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
