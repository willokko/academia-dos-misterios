---
titulo: "Sequência 8 - Insone - Poeta da Meia-Noite"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 8
nome_ingles: "Midnight Poet"
---

# Sequência 8 - Insone - Poeta da Meia-Noite

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 8. **Nome de referência:** Midnight Poet. Tradução editorial: Poeta da Meia-Noite.

## O que a poção transforma

O [[Poder - Insone S8 - Poema do repouso|pacote completo de Poeta da Meia-Noite]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Voz da meia-noite.

- [[Poder - Insone S8 - Poema do repouso#Poema de serenidade|Poema de serenidade]]
- [[Poder - Insone S8 - Poema do repouso#Canção de sono|Canção de sono]]
- [[Poder - Insone S8 - Poema do repouso#Refrão de amparo|Refrão de amparo]]



## Atuação e digestão

Interpretação original do papel **Poeta da Meia-Noite** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S8 - Poeta da Meia-Noite]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Insone - Insone]]. Próxima: [[Sequência 7 - Insone - Pesadelo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
