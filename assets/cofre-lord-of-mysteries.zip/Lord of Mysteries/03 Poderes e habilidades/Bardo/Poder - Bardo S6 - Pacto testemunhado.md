---
titulo: "Poder - Bardo S6 - Pacto testemunhado"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Bardo"
sequencia: 6
nome_pacote: "Pacote de Notário — Bardo S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Bardo S6 - Pacto testemunhado

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Notário, Bardo S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Bardo - Notário]] ou melhor no [[Caminho do Bardo]]. **Referência nominal:** Notary. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Testemunha sobrenatural:** Pode atestar termos que os participantes conhecem, sem decidir secretamente o significado do contrato.

## Técnicas adquiridas

### Reconhecer pacto

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até cumprir ou um descanso |
| Teste | Automático se voluntário |

Um compromisso voluntário marca aviso de quebra ou perda de benefício, conforme combinado. Não obriga comportamento ou causa morte.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Notarizar técnica

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Um aliado |
| Duração | Próximo uso |
| Teste | Automático |

O próximo uso de uma técnica de um aliado recebe +2 no teste nesta cena, sem copiar a técnica.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Ato inválido

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma rodada |
| Teste | AST+VON contra DEF.M do criador |

Mostre contradição entre um efeito e o pacto conhecido que o sustenta: em sucesso suspende seu bônus por uma rodada. Exige evidência real dos termos.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5 pode notarizar dois aliados por 10 PM; mantém teto +2 por teste da camada de Caminho.

## Preparação e oposição

Obscurecimento, pactos incompatíveis e fontes superiores. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Bardo]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
