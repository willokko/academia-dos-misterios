---
titulo: "Sequência 6 - Advogado - Barão da Corrupção"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
sequencia: 6
nome_ingles: "Baron of Corruption"
---

# Sequência 6 - Advogado - Barão da Corrupção

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Advogado]]. **Sequência:** 6. **Nome de referência:** Baron of Corruption. Tradução editorial: Barão da Corrupção.

## O que a poção transforma

O [[Poder - Advogado S6 - Distorção de percurso|pacote completo de Barão da Corrupção]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Leitura da distorção.

- [[Poder - Advogado S6 - Distorção de percurso#Desviar trajetória|Desviar trajetória]]
- [[Poder - Advogado S6 - Distorção de percurso#Distorcer passagem|Distorcer passagem]]
- [[Poder - Advogado S6 - Distorção de percurso#Corroer a intenção|Corroer a intenção]]



## Atuação e digestão

Interpretação original do papel **Barão da Corrupção** no tema de brechas, suborno e distorção de regras. Princípio de partida: conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Advogado#S6 - Barão da Corrupção]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Advogado - Subornador]]. Próxima: [[Sequência 5 - Advogado - Mentor da Desordem]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
