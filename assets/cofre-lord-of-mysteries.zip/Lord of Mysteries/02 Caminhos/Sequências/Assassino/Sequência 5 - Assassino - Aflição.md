---
titulo: "Sequência 5 - Assassino - Aflição"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 5
nome_ingles: "Affliction"
---

# Sequência 5 - Assassino - Aflição

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 5. **Nome de referência:** Affliction. Tradução editorial: Aflição.

## O que a poção transforma

O [[Poder - Assassino S5 - Aflição marcada|pacote completo de Aflição]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Afinidade com aflição.

- [[Poder - Assassino S5 - Aflição marcada#Aflição|Aflição]]
- [[Poder - Assassino S5 - Aflição marcada#Cena de espelhos|Cena de espelhos]]
- [[Poder - Assassino S5 - Aflição marcada#Maldição refletida|Maldição refletida]]



## Atuação e digestão

Interpretação original do papel **Aflição** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S5 - Aflição]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Assassino - Prazer]]. Próxima: [[Sequência 4 - Assassino - Desespero]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
