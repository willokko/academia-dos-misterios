---
titulo: "Sequência 6 - Vidente - Sem Rosto"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 6
nome_ingles: "Faceless"
---

# Sequência 6 - Vidente - Sem Rosto

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 6. **Nome de referência:** Faceless. Tradução editorial: Sem Rosto.

## O que a poção transforma

O [[Poder - Vidente S6 - Máscara sem rosto|pacote completo de Sem Rosto]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Memória de rostos; Controle da carne.

- [[Poder - Vidente S6 - Máscara sem rosto#Máscara sem rosto|Máscara sem rosto]]
- [[Poder - Vidente S6 - Máscara sem rosto#Estudar uma identidade|Estudar uma identidade]]
- [[Poder - Vidente S6 - Máscara sem rosto#Preparar a troca|Preparar a troca]]



## Atuação e digestão

Interpretação original do papel **Sem Rosto** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S6 - Sem Rosto]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Vidente - Mágico]]. Próxima: [[Sequência 5 - Vidente - Marionetista]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
