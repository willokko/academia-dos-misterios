---
titulo: "Caminho do Aprendiz"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
nome_divino: "Porta"
referencia: "https://lordofthemysteries.fandom.com/wiki/Door_Pathway"
---

# Caminho do Aprendiz

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Porta. **Tema:** Passagem, registro de poderes e espaço. **Função:** Exploração, evacuação e versatilidade preparada.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Aprendiz - Aprendiz|Aprendiz]] | [[Poder - Aprendiz S9 - Porta simbólica|3 técnicas]] |
| 8 | [[Sequência 8 - Aprendiz - Mestre dos Truques|Mestre dos Truques]] | [[Poder - Aprendiz S8 - Truque oportuno|3 técnicas]] |
| 7 | [[Sequência 7 - Aprendiz - Astrólogo|Astrólogo]] | [[Poder - Aprendiz S7 - Carta celeste|3 técnicas]] |
| 6 | [[Sequência 6 - Aprendiz - Escriba|Escriba]] | [[Poder - Aprendiz S6 - Registro único|3 técnicas]] |
| 5 | [[Sequência 5 - Aprendiz - Viajante|Viajante]] | [[Poder - Aprendiz S5 - Travessia conhecida|3 técnicas]] |
| 4 | [[Sequência 4 - Aprendiz - Feiticeiro dos Segredos|Feiticeiro dos Segredos]] | [[Poder - Aprendiz S4 - Autoridade de Feiticeiro dos Segredos|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Aprendiz - Andarilho|Andarilho]] | [[Poder - Aprendiz S3 - Autoridade de Andarilho|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Aprendiz - Caminhante dos Planos|Caminhante dos Planos]] | [[Poder - Aprendiz S2 - Autoridade de Caminhante dos Planos|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Aprendiz - Chave das Estrelas|Chave das Estrelas]] | [[Poder - Aprendiz S1 - Autoridade de Chave das Estrelas|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Aprendiz - Porta|Porta]] | [[Poder - Aprendiz S0 - Autoridade de Porta|2 técnicas + operação]] |

## Como jogar

Abrir possibilidades e preparar uma rota de retorno. As ferramentas da S9 são sentido de passagem. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Muito alta: cópia e teleporte. **Oposição:** Selos, destinos não conhecidos e falta de observação prévia. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Aprendiz]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Door_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
