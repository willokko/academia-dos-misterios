---
titulo: "Caminho do Insone"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
nome_divino: "Escuridão"
referencia: "https://lordofthemysteries.fandom.com/wiki/Darkness_Pathway"
---

# Caminho do Insone

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Escuridão. **Tema:** Noite, sono, espíritos e ocultação. **Função:** Vigília, infiltração e suporte.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Insone - Insone|Insone]] | [[Poder - Insone S9 - Vigília sensível|3 técnicas]] |
| 8 | [[Sequência 8 - Insone - Poeta da Meia-Noite|Poeta da Meia-Noite]] | [[Poder - Insone S8 - Poema do repouso|3 técnicas]] |
| 7 | [[Sequência 7 - Insone - Pesadelo|Pesadelo]] | [[Poder - Insone S7 - Limiar de pesadelo|3 técnicas]] |
| 6 | [[Sequência 6 - Insone - Pacificador de Almas|Pacificador de Almas]] | [[Poder - Insone S6 - Quietude da alma|3 técnicas]] |
| 5 | [[Sequência 5 - Insone - Feiticeiro dos Espíritos|Feiticeiro dos Espíritos]] | [[Poder - Insone S5 - Pacto de vigília|3 técnicas]] |
| 4 | [[Sequência 4 - Insone - Vigilante Noturno|Vigilante Noturno]] | [[Poder - Insone S4 - Autoridade de Vigilante Noturno|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Insone - Bispo do Horror|Bispo do Horror]] | [[Poder - Insone S3 - Autoridade de Bispo do Horror|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Insone - Servo da Ocultação|Servo da Ocultação]] | [[Poder - Insone S2 - Autoridade de Servo da Ocultação|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Insone - Cavaleiro do Infortúnio|Cavaleiro do Infortúnio]] | [[Poder - Insone S1 - Autoridade de Cavaleiro do Infortúnio|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Insone - Escuridão|Escuridão]] | [[Poder - Insone S0 - Autoridade de Escuridão|2 técnicas + operação]] |

## Como jogar

Velar por alguém sem vigiar todos os aspectos de sua vida. As ferramentas da S9 são vigília noturna, percepção espiritual. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: sono e ocultação. **Oposição:** Claridade preparada, alarmes independentes e recusa de isolamento. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Insone]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Darkness_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
