---
titulo: "Índice de poderes"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Índice de poderes

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

Cada uma das 220 fichas é um **pacote de Sequência**, não um poder isolado. S9–5 têm pelo menos três técnicas, permanências e evolução. S4–0 têm duas aplicações locais e um feito de operação. [[Regras dos poderes]] é a referência comum.

## Vidente

- S9: [[Poder - Vidente S9 - Olhar para o presságio|Pacote de Vidente]]
- S8: [[Poder - Vidente S8 - Equilíbrio do palhaço|Pacote de Palhaço]]
- S7: [[Poder - Vidente S7 - Truques do palco velado|Pacote de Mágico]]
- S6: [[Poder - Vidente S6 - Máscara sem rosto|Pacote de Sem Rosto]]
- S5: [[Poder - Vidente S5 - Fios da marionete|Pacote de Marionetista]]
- S4: [[Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro|Pacote de Feiticeiro Bizarro]]
- S3: [[Poder - Vidente S3 - Autoridade de Erudito do Passado|Pacote de Erudito do Passado]]
- S2: [[Poder - Vidente S2 - Autoridade de Invocador de Milagres|Pacote de Invocador de Milagres]]
- S1: [[Poder - Vidente S1 - Autoridade de Servidor dos Mistérios|Pacote de Servidor dos Mistérios]]
- S0: [[Poder - Vidente S0 - Autoridade de Louco|Pacote de Louco]]

## Espectador

- S9: [[Poder - Espectador S9 - Leitura da plateia|Pacote de Espectador]]
- S8: [[Poder - Espectador S8 - Eco de pensamento|Pacote de Telepata]]
- S7: [[Poder - Espectador S7 - Recompor a identidade|Pacote de Psiquiatra]]
- S6: [[Poder - Espectador S6 - Sugestão de um gesto|Pacote de Hipnotizador]]
- S5: [[Poder - Espectador S5 - Passo no sonho|Pacote de Caminhante dos Sonhos]]
- S4: [[Poder - Espectador S4 - Autoridade de Manipulador|Pacote de Manipulador]]
- S3: [[Poder - Espectador S3 - Autoridade de Tecelão de Sonhos|Pacote de Tecelão de Sonhos]]
- S2: [[Poder - Espectador S2 - Autoridade de Discernidor|Pacote de Discernidor]]
- S1: [[Poder - Espectador S1 - Autoridade de Autor|Pacote de Autor]]
- S0: [[Poder - Espectador S0 - Autoridade de Visionário|Pacote de Visionário]]

## Marinheiro

- S9: [[Poder - Marinheiro S9 - Corpo das marés|Pacote de Marinheiro]]
- S8: [[Poder - Marinheiro S8 - Investida da fúria|Pacote de Povo da Fúria]]
- S7: [[Poder - Marinheiro S7 - Rumo contra a tempestade|Pacote de Navegante]]
- S6: [[Poder - Marinheiro S6 - Passagem do vento|Pacote de Abençoado pelo Vento]]
- S5: [[Poder - Marinheiro S5 - Voz do oceano|Pacote de Cantor do Oceano]]
- S4: [[Poder - Marinheiro S4 - Autoridade de Sepultador de Cataclismos|Pacote de Sepultador de Cataclismos]]
- S3: [[Poder - Marinheiro S3 - Autoridade de Rei do Mar|Pacote de Rei do Mar]]
- S2: [[Poder - Marinheiro S2 - Autoridade de Calamidade|Pacote de Calamidade]]
- S1: [[Poder - Marinheiro S1 - Autoridade de Deus do Trovão|Pacote de Deus do Trovão]]
- S0: [[Poder - Marinheiro S0 - Autoridade de Tirano|Pacote de Tirano]]

## Saqueador

- S9: [[Poder - Saqueador S9 - Mãos do intervalo|Pacote de Saqueador]]
- S8: [[Poder - Saqueador S8 - Proposta enviesada|Pacote de Vigarista]]
- S7: [[Poder - Saqueador S7 - Chave de leitura|Pacote de Criptologista]]
- S6: [[Poder - Saqueador S6 - Furto de chama|Pacote de Prometeu]]
- S5: [[Poder - Saqueador S5 - Subtrair a intenção|Pacote de Ladrão de Sonhos]]
- S4: [[Poder - Saqueador S4 - Autoridade de Parasita|Pacote de Parasita]]
- S3: [[Poder - Saqueador S3 - Autoridade de Mentor do Engano|Pacote de Mentor do Engano]]
- S2: [[Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino|Pacote de Cavalo de Troia do Destino]]
- S1: [[Poder - Saqueador S1 - Autoridade de Verme do Tempo|Pacote de Verme do Tempo]]
- S0: [[Poder - Saqueador S0 - Autoridade de Erro|Pacote de Erro]]

## Aprendiz

- S9: [[Poder - Aprendiz S9 - Porta simbólica|Pacote de Aprendiz]]
- S8: [[Poder - Aprendiz S8 - Truque oportuno|Pacote de Mestre dos Truques]]
- S7: [[Poder - Aprendiz S7 - Carta celeste|Pacote de Astrólogo]]
- S6: [[Poder - Aprendiz S6 - Registro único|Pacote de Escriba]]
- S5: [[Poder - Aprendiz S5 - Travessia conhecida|Pacote de Viajante]]
- S4: [[Poder - Aprendiz S4 - Autoridade de Feiticeiro dos Segredos|Pacote de Feiticeiro dos Segredos]]
- S3: [[Poder - Aprendiz S3 - Autoridade de Andarilho|Pacote de Andarilho]]
- S2: [[Poder - Aprendiz S2 - Autoridade de Caminhante dos Planos|Pacote de Caminhante dos Planos]]
- S1: [[Poder - Aprendiz S1 - Autoridade de Chave das Estrelas|Pacote de Chave das Estrelas]]
- S0: [[Poder - Aprendiz S0 - Autoridade de Porta|Pacote de Porta]]

## Bardo

- S9: [[Poder - Bardo S9 - Verso de coragem|Pacote de Bardo]]
- S8: [[Poder - Bardo S8 - Luz que denuncia|Pacote de Suplicante da Luz]]
- S7: [[Poder - Bardo S7 - Bênção de vigília|Pacote de Sumo Sacerdote Solar]]
- S6: [[Poder - Bardo S6 - Pacto testemunhado|Pacote de Notário]]
- S5: [[Poder - Bardo S5 - Purificação focal|Pacote de Sacerdote da Luz]]
- S4: [[Poder - Bardo S4 - Autoridade de Sem Sombra|Pacote de Sem Sombra]]
- S3: [[Poder - Bardo S3 - Autoridade de Mentor da Justiça|Pacote de Mentor da Justiça]]
- S2: [[Poder - Bardo S2 - Autoridade de Buscador da Luz|Pacote de Buscador da Luz]]
- S1: [[Poder - Bardo S1 - Autoridade de Anjo Branco|Pacote de Anjo Branco]]
- S0: [[Poder - Bardo S0 - Autoridade de Sol|Pacote de Sol]]

## Suplicante de Segredos

- S9: [[Poder - Suplicante de Segredos S9 - Súplica delimitada|Pacote de Suplicante de Segredos]]
- S8: [[Poder - Suplicante de Segredos S8 - Escuta vedada|Pacote de Ouvinte]]
- S7: [[Poder - Suplicante de Segredos S7 - Abrigo de sombra|Pacote de Asceta das Sombras]]
- S6: [[Poder - Suplicante de Segredos S6 - Carne maleável|Pacote de Bispo da Rosa]]
- S5: [[Poder - Suplicante de Segredos S5 - Pastoreio de eco|Pacote de Pastor]]
- S4: [[Poder - Suplicante de Segredos S4 - Autoridade de Cavaleiro Negro|Pacote de Cavaleiro Negro]]
- S3: [[Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade|Pacote de Templário da Trindade]]
- S2: [[Poder - Suplicante de Segredos S2 - Autoridade de Presbítero Profano|Pacote de Presbítero Profano]]
- S1: [[Poder - Suplicante de Segredos S1 - Autoridade de Anjo Sombrio|Pacote de Anjo Sombrio]]
- S0: [[Poder - Suplicante de Segredos S0 - Autoridade de Enforcado|Pacote de Enforcado]]

## Leitor

- S9: [[Poder - Leitor S9 - Índice mental|Pacote de Leitor]]
- S8: [[Poder - Leitor S8 - Hipótese contrastada|Pacote de Estudante do Raciocínio]]
- S7: [[Poder - Leitor S7 - Dedução de campo|Pacote de Detetive]]
- S6: [[Poder - Leitor S6 - Imitação estudada|Pacote de Polímata]]
- S5: [[Poder - Leitor S5 - Contrapadrão|Pacote de Magíster do Misticismo]]
- S4: [[Poder - Leitor S4 - Autoridade de Profeta|Pacote de Profeta]]
- S3: [[Poder - Leitor S3 - Autoridade de Conhecedor|Pacote de Conhecedor]]
- S2: [[Poder - Leitor S2 - Autoridade de Anjo da Sabedoria|Pacote de Anjo da Sabedoria]]
- S1: [[Poder - Leitor S1 - Autoridade de Olho Onisciente|Pacote de Olho Onisciente]]
- S0: [[Poder - Leitor S0 - Autoridade de Torre Branca|Pacote de Torre Branca]]

## Insone

- S9: [[Poder - Insone S9 - Vigília sensível|Pacote de Insone]]
- S8: [[Poder - Insone S8 - Poema do repouso|Pacote de Poeta da Meia-Noite]]
- S7: [[Poder - Insone S7 - Limiar de pesadelo|Pacote de Pesadelo]]
- S6: [[Poder - Insone S6 - Quietude da alma|Pacote de Pacificador de Almas]]
- S5: [[Poder - Insone S5 - Pacto de vigília|Pacote de Feiticeiro dos Espíritos]]
- S4: [[Poder - Insone S4 - Autoridade de Vigilante Noturno|Pacote de Vigilante Noturno]]
- S3: [[Poder - Insone S3 - Autoridade de Bispo do Horror|Pacote de Bispo do Horror]]
- S2: [[Poder - Insone S2 - Autoridade de Servo da Ocultação|Pacote de Servo da Ocultação]]
- S1: [[Poder - Insone S1 - Autoridade de Cavaleiro do Infortúnio|Pacote de Cavaleiro do Infortúnio]]
- S0: [[Poder - Insone S0 - Autoridade de Escuridão|Pacote de Escuridão]]

## Coletor de Cadáveres

- S9: [[Poder - Coletor de Cadáveres S9 - Exame do último vestígio|Pacote de Coletor de Cadáveres]]
- S8: [[Poder - Coletor de Cadáveres S8 - Voz junto à sepultura|Pacote de Coveiro]]
- S7: [[Poder - Coletor de Cadáveres S7 - Audiência dos mortos|Pacote de Médium Espiritual]]
- S6: [[Poder - Coletor de Cadáveres S6 - Guia do limiar|Pacote de Guia Espiritual]]
- S5: [[Poder - Coletor de Cadáveres S5 - Portão contido|Pacote de Guardião do Portão]]
- S4: [[Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro|Pacote de Imorredouro]]
- S3: [[Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro|Pacote de Barqueiro]]
- S2: [[Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte|Pacote de Cônsul da Morte]]
- S1: [[Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido|Pacote de Imperador Pálido]]
- S0: [[Poder - Coletor de Cadáveres S0 - Autoridade de Morte|Pacote de Morte]]

## Guerreiro

- S9: [[Poder - Guerreiro S9 - Força aplicada|Pacote de Guerreiro]]
- S8: [[Poder - Guerreiro S8 - Golpe de pugilista|Pacote de Pugilista]]
- S7: [[Poder - Guerreiro S7 - Leitura do adversário|Pacote de Mestre das Armas]]
- S6: [[Poder - Guerreiro S6 - Arma da alvorada|Pacote de Paladino da Alvorada]]
- S5: [[Poder - Guerreiro S5 - Bastião de um nome|Pacote de Guardião]]
- S4: [[Poder - Guerreiro S4 - Autoridade de Caçador de Demônios|Pacote de Caçador de Demônios]]
- S3: [[Poder - Guerreiro S3 - Autoridade de Cavaleiro de Prata|Pacote de Cavaleiro de Prata]]
- S2: [[Poder - Guerreiro S2 - Autoridade de Glória|Pacote de Glória]]
- S1: [[Poder - Guerreiro S1 - Autoridade de Mão de Deus|Pacote de Mão de Deus]]
- S0: [[Poder - Guerreiro S0 - Autoridade de Gigante do Crepúsculo|Pacote de Gigante do Crepúsculo]]

## Assassino

- S9: [[Poder - Assassino S9 - Passo de emboscada|Pacote de Assassino]]
- S8: [[Poder - Assassino S8 - Centelha de discórdia|Pacote de Instigador]]
- S7: [[Poder - Assassino S7 - Reflexo substituto|Pacote de Bruxa]]
- S6: [[Poder - Assassino S6 - Fio de fascínio|Pacote de Prazer]]
- S5: [[Poder - Assassino S5 - Aflição marcada|Pacote de Aflição]]
- S4: [[Poder - Assassino S4 - Autoridade de Desespero|Pacote de Desespero]]
- S3: [[Poder - Assassino S3 - Autoridade de Sem Idade|Pacote de Sem Idade]]
- S2: [[Poder - Assassino S2 - Autoridade de Catástrofe|Pacote de Catástrofe]]
- S1: [[Poder - Assassino S1 - Autoridade de Apocalipse|Pacote de Apocalipse]]
- S0: [[Poder - Assassino S0 - Autoridade de Demoness|Pacote de Demoness]]

## Caçador

- S9: [[Poder - Caçador S9 - Rastro escolhido|Pacote de Caçador]]
- S8: [[Poder - Caçador S8 - Provocação calculada|Pacote de Provocador]]
- S7: [[Poder - Caçador S7 - Lança de brasa|Pacote de Piromaníaco]]
- S6: [[Poder - Caçador S6 - Plano em camadas|Pacote de Conspirador]]
- S5: [[Poder - Caçador S5 - Golpe na abertura|Pacote de Ceifador]]
- S4: [[Poder - Caçador S4 - Autoridade de Cavaleiro de Sangue e Ferro|Pacote de Cavaleiro de Sangue e Ferro]]
- S3: [[Poder - Caçador S3 - Autoridade de Bispo da Guerra|Pacote de Bispo da Guerra]]
- S2: [[Poder - Caçador S2 - Autoridade de Feiticeiro do Clima|Pacote de Feiticeiro do Clima]]
- S1: [[Poder - Caçador S1 - Autoridade de Conquistador|Pacote de Conquistador]]
- S0: [[Poder - Caçador S0 - Autoridade de Sacerdote Vermelho|Pacote de Sacerdote Vermelho]]

## Espreitador de Mistérios

- S9: [[Poder - Espreitador de Mistérios S9 - Anotação do oculto|Pacote de Espreitador de Mistérios]]
- S8: [[Poder - Espreitador de Mistérios S8 - Geometria marcial|Pacote de Erudito Marcial]]
- S7: [[Poder - Espreitador de Mistérios S7 - Fórmula breve|Pacote de Bruxo]]
- S6: [[Poder - Espreitador de Mistérios S6 - Pergaminho preparado|Pacote de Professor de Pergaminhos]]
- S5: [[Poder - Espreitador de Mistérios S5 - Mapa das constelações|Pacote de Mestre das Constelações]]
- S4: [[Poder - Espreitador de Mistérios S4 - Autoridade de Misticólogo|Pacote de Misticólogo]]
- S3: [[Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente|Pacote de Clarividente]]
- S2: [[Poder - Espreitador de Mistérios S2 - Autoridade de Sábio Místico|Pacote de Sábio Místico]]
- S1: [[Poder - Espreitador de Mistérios S1 - Autoridade de Imperador do Conhecimento|Pacote de Imperador do Conhecimento]]
- S0: [[Poder - Espreitador de Mistérios S0 - Autoridade de Eremita|Pacote de Eremita]]

## Sábio

- S9: [[Poder - Sábio S9 - Memória de oficina|Pacote de Sábio]]
- S8: [[Poder - Sábio S8 - Camadas do tempo|Pacote de Arqueólogo]]
- S7: [[Poder - Sábio S7 - Avaliar o perigo|Pacote de Avaliador]]
- S6: [[Poder - Sábio S6 - Oficina de urgência|Pacote de Artesão]]
- S5: [[Poder - Sábio S5 - Instrumento estelar|Pacote de Astrônomo]]
- S4: [[Poder - Sábio S4 - Autoridade de Alquimista|Pacote de Alquimista]]
- S3: [[Poder - Sábio S3 - Autoridade de Erudito Arcano|Pacote de Erudito Arcano]]
- S2: [[Poder - Sábio S2 - Autoridade de Magíster do Conhecimento|Pacote de Magíster do Conhecimento]]
- S1: [[Poder - Sábio S1 - Autoridade de Iluminador|Pacote de Iluminador]]
- S0: [[Poder - Sábio S0 - Autoridade de Paragon|Pacote de Paragon]]

## Monstro

- S9: [[Poder - Monstro S9 - Pressentir a ruptura|Pacote de Monstro]]
- S8: [[Poder - Monstro S8 - Rotina calculada|Pacote de Robô]]
- S7: [[Poder - Monstro S7 - Desvio de sorte|Pacote de Sortudo]]
- S6: [[Poder - Monstro S6 - Aviso de calamidade|Pacote de Sacerdote da Calamidade]]
- S5: [[Poder - Monstro S5 - Janela do vencedor|Pacote de Vencedor]]
- S4: [[Poder - Monstro S4 - Autoridade de Mago do Infortúnio|Pacote de Mago do Infortúnio]]
- S3: [[Poder - Monstro S3 - Autoridade de Caminhante do Caos|Pacote de Caminhante do Caos]]
- S2: [[Poder - Monstro S2 - Autoridade de Adivinho|Pacote de Adivinho]]
- S1: [[Poder - Monstro S1 - Autoridade de Serpente de Mercúrio|Pacote de Serpente de Mercúrio]]
- S0: [[Poder - Monstro S0 - Autoridade de Roda da Fortuna|Pacote de Roda da Fortuna]]

## Boticário

- S9: [[Poder - Boticário S9 - Dose de socorro|Pacote de Boticário]]
- S8: [[Poder - Boticário S8 - Entendimento da besta|Pacote de Domador de Bestas]]
- S7: [[Poder - Boticário S7 - Vigor sanguíneo|Pacote de Vampiro]]
- S6: [[Poder - Boticário S6 - Preparado de estabilidade|Pacote de Professor de Poções]]
- S5: [[Poder - Boticário S5 - Chamado escarlate|Pacote de Erudito Escarlate]]
- S4: [[Poder - Boticário S4 - Autoridade de Rei Xamã|Pacote de Rei Xamã]]
- S3: [[Poder - Boticário S3 - Autoridade de Alto Invocador|Pacote de Alto Invocador]]
- S2: [[Poder - Boticário S2 - Autoridade de Doador de Vida|Pacote de Doador de Vida]]
- S1: [[Poder - Boticário S1 - Autoridade de Deusa da Beleza|Pacote de Deusa da Beleza]]
- S0: [[Poder - Boticário S0 - Autoridade de Lua|Pacote de Lua]]

## Plantador

- S9: [[Poder - Plantador S9 - Leitura do solo|Pacote de Plantador]]
- S8: [[Poder - Plantador S8 - Cuidados de campo|Pacote de Médico]]
- S7: [[Poder - Plantador S7 - Crescimento oportuno|Pacote de Sacerdote da Colheita]]
- S6: [[Poder - Plantador S6 - Análise orgânica|Pacote de Biólogo]]
- S5: [[Poder - Plantador S5 - Forma de travessia|Pacote de Druida]]
- S4: [[Poder - Plantador S4 - Autoridade de Alquimista Antigo|Pacote de Alquimista Antigo]]
- S3: [[Poder - Plantador S3 - Autoridade de Portador do Caixão|Pacote de Portador do Caixão]]
- S2: [[Poder - Plantador S2 - Autoridade de Matriarca da Desolação|Pacote de Matriarca da Desolação]]
- S1: [[Poder - Plantador S1 - Autoridade de Caminhante da Natureza|Pacote de Caminhante da Natureza]]
- S0: [[Poder - Plantador S0 - Autoridade de Mãe|Pacote de Mãe]]

## Prisioneiro

- S9: [[Poder - Prisioneiro S9 - Limites da cela|Pacote de Prisioneiro]]
- S8: [[Poder - Prisioneiro S8 - Instinto contido|Pacote de Lunático]]
- S7: [[Poder - Prisioneiro S7 - Garras do limiar|Pacote de Lobisomem]]
- S6: [[Poder - Prisioneiro S6 - Corpo do frio|Pacote de Zumbi]]
- S5: [[Poder - Prisioneiro S5 - Visita espectral|Pacote de Espectro]]
- S4: [[Poder - Prisioneiro S4 - Autoridade de Marionete|Pacote de Marionete]]
- S3: [[Poder - Prisioneiro S3 - Autoridade de Discípulo do Silêncio|Pacote de Discípulo do Silêncio]]
- S2: [[Poder - Prisioneiro S2 - Autoridade de Flagelo Antigo|Pacote de Flagelo Antigo]]
- S1: [[Poder - Prisioneiro S1 - Autoridade de Abominação|Pacote de Abominação]]
- S0: [[Poder - Prisioneiro S0 - Autoridade de Acorrentado|Pacote de Acorrentado]]

## Criminoso

- S9: [[Poder - Criminoso S9 - Sentido de ameaça|Pacote de Criminoso]]
- S8: [[Poder - Criminoso S8 - Frieza calculada|Pacote de Anjo sem Asas]]
- S7: [[Poder - Criminoso S7 - Padrão predatório|Pacote de Assassino em Série]]
- S6: [[Poder - Criminoso S6 - Chama do diabo|Pacote de Diabo]]
- S5: [[Poder - Criminoso S5 - Desejo exposto|Pacote de Apóstolo do Desejo]]
- S4: [[Poder - Criminoso S4 - Autoridade de Demônio|Pacote de Demônio]]
- S3: [[Poder - Criminoso S3 - Autoridade de Tagarela|Pacote de Tagarela]]
- S2: [[Poder - Criminoso S2 - Autoridade de Arquiduque Sangrento|Pacote de Arquiduque Sangrento]]
- S1: [[Poder - Criminoso S1 - Autoridade de Monarca da Imundície|Pacote de Monarca da Imundície]]
- S0: [[Poder - Criminoso S0 - Autoridade de Abismo|Pacote de Abismo]]

## Advogado

- S9: [[Poder - Advogado S9 - Brecha contratual|Pacote de Advogado]]
- S8: [[Poder - Advogado S8 - Autoridade da força|Pacote de Bárbaro]]
- S7: [[Poder - Advogado S7 - Presente comprometedor|Pacote de Subornador]]
- S6: [[Poder - Advogado S6 - Distorção de percurso|Pacote de Barão da Corrupção]]
- S5: [[Poder - Advogado S5 - Desordem focal|Pacote de Mentor da Desordem]]
- S4: [[Poder - Advogado S4 - Autoridade de Conde dos Caídos|Pacote de Conde dos Caídos]]
- S3: [[Poder - Advogado S3 - Autoridade de Mago Frenético|Pacote de Mago Frenético]]
- S2: [[Poder - Advogado S2 - Autoridade de Duque da Entropia|Pacote de Duque da Entropia]]
- S1: [[Poder - Advogado S1 - Autoridade de Príncipe da Abolição|Pacote de Príncipe da Abolição]]
- S0: [[Poder - Advogado S0 - Autoridade de Imperador Negro|Pacote de Imperador Negro]]

## Árbitro

- S9: [[Poder - Árbitro S9 - Voz de mediação|Pacote de Árbitro]]
- S8: [[Poder - Árbitro S8 - Olhar do xerife|Pacote de Xerife]]
- S7: [[Poder - Árbitro S7 - Pergunta que pesa|Pacote de Interrogador]]
- S6: [[Poder - Árbitro S6 - Proibição enunciada|Pacote de Juiz]]
- S5: [[Poder - Árbitro S5 - Sanção disciplinar|Pacote de Paladino Disciplinar]]
- S4: [[Poder - Árbitro S4 - Autoridade de Mago Imperativo|Pacote de Mago Imperativo]]
- S3: [[Poder - Árbitro S3 - Autoridade de Caçador do Caos|Pacote de Caçador do Caos]]
- S2: [[Poder - Árbitro S2 - Autoridade de Equilibrador|Pacote de Equilibrador]]
- S1: [[Poder - Árbitro S1 - Autoridade de Mão da Ordem|Pacote de Mão da Ordem]]
- S0: [[Poder - Árbitro S0 - Autoridade de Justiceiro|Pacote de Justiceiro]]

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
