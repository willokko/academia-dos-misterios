---
titulo: "Sequência 1 - Marinheiro - Deus do Trovão"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 1
nome_ingles: "Thunder God"
---

# Sequência 1 - Marinheiro - Deus do Trovão

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 1. **Nome de referência:** Thunder God. Tradução editorial: Deus do Trovão.

## O que a poção transforma

O [[Poder - Marinheiro S1 - Autoridade de Deus do Trovão|pacote completo de Deus do Trovão]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Deus do Trovão.

- [[Poder - Marinheiro S1 - Autoridade de Deus do Trovão#Corpo de trovão|Corpo de trovão]]
- [[Poder - Marinheiro S1 - Autoridade de Deus do Trovão#Julgamento elétrico|Julgamento elétrico]]

Operação: [[Poder - Marinheiro S1 - Autoridade de Deus do Trovão#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Deus do Trovão** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S1 - Deus do Trovão]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Marinheiro - Calamidade]]. Próxima: [[Sequência 0 - Marinheiro - Tirano]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
