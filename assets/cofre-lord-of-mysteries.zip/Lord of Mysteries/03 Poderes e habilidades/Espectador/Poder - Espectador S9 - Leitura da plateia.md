---
titulo: "Poder - Espectador S9 - Leitura da plateia"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espectador"
sequencia: 9
nome_pacote: "Pacote de Espectador — Espectador S9"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Espectador S9 - Leitura da plateia

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Espectador, Espectador S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Espectador - Espectador]] ou melhor no [[Caminho do Espectador]]. **Referência nominal:** Spectator. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Atenção da plateia:** +2 a Estudo de comportamento de pessoas presentes; expressão e contexto fornecem sinais, sem detectar mentira automaticamente.
- **Memória de detalhes:** Recorda gestos e disposições sociais observados nesta cena, sem recuperar informação que não percebeu.

## Técnicas adquiridas

### Ler emoção

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Observe uma pessoa: receba sua emoção predominante e um sinal corporal que a sustenta. Isso não prova culpa nem verdade. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Mapear a plateia

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Observe um grupo pequeno e descubra quem busca aprovação de quem por comportamento visível. Pode haver uma hipótese errada dos próprios participantes. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Preparar a abordagem

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Um interlocutor |
| Duração | Próximo teste na cena |
| Teste | Automático |

Após ler uma emoção, diga como adapta sua fala: +2 ao próximo teste de interação com essa pessoa. Não torna uma proposta impossível aceitável.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S8 torna possível perceber pensamento superficial; antes disso, toda leitura é inferência. S7 permite usar uma leitura para localizar o foco de uma crise mental.

## Preparação e oposição

Máscaras sociais treinadas, registros materiais e sujeitos sem mente acessível. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espectador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
