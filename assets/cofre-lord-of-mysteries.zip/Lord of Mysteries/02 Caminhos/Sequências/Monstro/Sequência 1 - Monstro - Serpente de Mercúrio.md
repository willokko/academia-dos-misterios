---
titulo: "Sequência 1 - Monstro - Serpente de Mercúrio"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 1
nome_ingles: "Snake of Mercury"
---

# Sequência 1 - Monstro - Serpente de Mercúrio

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 1. **Nome de referência:** Snake of Mercury. Tradução editorial: Serpente de Mercúrio.

## O que a poção transforma

O [[Poder - Monstro S1 - Autoridade de Serpente de Mercúrio|pacote completo de Serpente de Mercúrio]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Serpente de Mercúrio.

- [[Poder - Monstro S1 - Autoridade de Serpente de Mercúrio#Marca do ciclo|Marca do ciclo]]
- [[Poder - Monstro S1 - Autoridade de Serpente de Mercúrio#Recomeço pessoal|Recomeço pessoal]]

Operação: [[Poder - Monstro S1 - Autoridade de Serpente de Mercúrio#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Serpente de Mercúrio** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S1 - Serpente de Mercúrio]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Monstro - Adivinho]]. Próxima: [[Sequência 0 - Monstro - Roda da Fortuna]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
