---
titulo: "Sequência 1 - Leitor - Olho Onisciente"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 1
nome_ingles: "Omniscient Eye"
---

# Sequência 1 - Leitor - Olho Onisciente

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 1. **Nome de referência:** Omniscient Eye. Tradução editorial: Olho Onisciente.

## O que a poção transforma

O [[Poder - Leitor S1 - Autoridade de Olho Onisciente|pacote completo de Olho Onisciente]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Olho Onisciente.

- [[Poder - Leitor S1 - Autoridade de Olho Onisciente#Olho de revelação|Olho de revelação]]
- [[Poder - Leitor S1 - Autoridade de Olho Onisciente#Previsão de estrutura|Previsão de estrutura]]

Operação: [[Poder - Leitor S1 - Autoridade de Olho Onisciente#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Olho Onisciente** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S1 - Olho Onisciente]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Leitor - Anjo da Sabedoria]]. Próxima: [[Sequência 0 - Leitor - Torre Branca]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
