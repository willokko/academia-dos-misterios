---
titulo: "Índice geral"
tipo: "início"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Índice geral

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

Use [[Início]] durante a sessão. Cada regra tem uma única nota normativa; tabelas e exemplos remetem a ela.

## 00 Início\Abrir e preservar o cofre.md

- [[Abrir e preservar o cofre]]

## 00 Início\Como usar este cofre.md

- [[Como usar este cofre]]

## 00 Início\Contrato de campanha.md

- [[Contrato de campanha]]

## 00 Início\Glossário.md

- [[Glossário]]

## 00 Início\Início.md

- [[Início]]

## 01 Regras fundamentais\Classes e identidade sobrenatural.md

- [[Classes e identidade sobrenatural]]

## 01 Regras fundamentais\Combate e alcance.md

- [[Combate e alcance]]

## 01 Regras fundamentais\Condições.md

- [[Condições]]

## 01 Regras fundamentais\Criação de personagens.md

- [[Criação de personagens]]

## 01 Regras fundamentais\Derrota e sacrifício.md

- [[Derrota e sacrifício]]

## 01 Regras fundamentais\Escala e confrontos sobrenaturais.md

- [[Escala e confrontos sobrenaturais]]

## 01 Regras fundamentais\Progressão e Sequências.md

- [[Progressão e Sequências]]

## 01 Regras fundamentais\Recursos e descanso.md

- [[Recursos e descanso]]

## 01 Regras fundamentais\Testes e cooperação.md

- [[Testes e cooperação]]

## 02 Caminhos\Caminho do Advogado.md

- [[Caminho do Advogado]]

## 02 Caminhos\Caminho do Aprendiz.md

- [[Caminho do Aprendiz]]

## 02 Caminhos\Caminho do Assassino.md

- [[Caminho do Assassino]]

## 02 Caminhos\Caminho do Bardo.md

- [[Caminho do Bardo]]

## 02 Caminhos\Caminho do Boticário.md

- [[Caminho do Boticário]]

## 02 Caminhos\Caminho do Caçador.md

- [[Caminho do Caçador]]

## 02 Caminhos\Caminho do Coletor de Cadáveres.md

- [[Caminho do Coletor de Cadáveres]]

## 02 Caminhos\Caminho do Criminoso.md

- [[Caminho do Criminoso]]

## 02 Caminhos\Caminho do Espectador.md

- [[Caminho do Espectador]]

## 02 Caminhos\Caminho do Espreitador de Mistérios.md

- [[Caminho do Espreitador de Mistérios]]

## 02 Caminhos\Caminho do Guerreiro.md

- [[Caminho do Guerreiro]]

## 02 Caminhos\Caminho do Insone.md

- [[Caminho do Insone]]

## 02 Caminhos\Caminho do Leitor.md

- [[Caminho do Leitor]]

## 02 Caminhos\Caminho do Marinheiro.md

- [[Caminho do Marinheiro]]

## 02 Caminhos\Caminho do Monstro.md

- [[Caminho do Monstro]]

## 02 Caminhos\Caminho do Plantador.md

- [[Caminho do Plantador]]

## 02 Caminhos\Caminho do Prisioneiro.md

- [[Caminho do Prisioneiro]]

## 02 Caminhos\Caminho do Saqueador.md

- [[Caminho do Saqueador]]

## 02 Caminhos\Caminho do Suplicante de Segredos.md

- [[Caminho do Suplicante de Segredos]]

## 02 Caminhos\Caminho do Sábio.md

- [[Caminho do Sábio]]

## 02 Caminhos\Caminho do Vidente.md

- [[Caminho do Vidente]]

## 02 Caminhos\Caminho do Árbitro.md

- [[Caminho do Árbitro]]

## 02 Caminhos\Sequências\Advogado\Sequência 0 - Advogado - Imperador Negro.md

- [[Sequência 0 - Advogado - Imperador Negro]]

## 02 Caminhos\Sequências\Advogado\Sequência 1 - Advogado - Príncipe da Abolição.md

- [[Sequência 1 - Advogado - Príncipe da Abolição]]

## 02 Caminhos\Sequências\Advogado\Sequência 2 - Advogado - Duque da Entropia.md

- [[Sequência 2 - Advogado - Duque da Entropia]]

## 02 Caminhos\Sequências\Advogado\Sequência 3 - Advogado - Mago Frenético.md

- [[Sequência 3 - Advogado - Mago Frenético]]

## 02 Caminhos\Sequências\Advogado\Sequência 4 - Advogado - Conde dos Caídos.md

- [[Sequência 4 - Advogado - Conde dos Caídos]]

## 02 Caminhos\Sequências\Advogado\Sequência 5 - Advogado - Mentor da Desordem.md

- [[Sequência 5 - Advogado - Mentor da Desordem]]

## 02 Caminhos\Sequências\Advogado\Sequência 6 - Advogado - Barão da Corrupção.md

- [[Sequência 6 - Advogado - Barão da Corrupção]]

## 02 Caminhos\Sequências\Advogado\Sequência 7 - Advogado - Subornador.md

- [[Sequência 7 - Advogado - Subornador]]

## 02 Caminhos\Sequências\Advogado\Sequência 8 - Advogado - Bárbaro.md

- [[Sequência 8 - Advogado - Bárbaro]]

## 02 Caminhos\Sequências\Advogado\Sequência 9 - Advogado - Advogado.md

- [[Sequência 9 - Advogado - Advogado]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 0 - Aprendiz - Porta.md

- [[Sequência 0 - Aprendiz - Porta]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 1 - Aprendiz - Chave das Estrelas.md

- [[Sequência 1 - Aprendiz - Chave das Estrelas]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 2 - Aprendiz - Caminhante dos Planos.md

- [[Sequência 2 - Aprendiz - Caminhante dos Planos]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 3 - Aprendiz - Andarilho.md

- [[Sequência 3 - Aprendiz - Andarilho]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 4 - Aprendiz - Feiticeiro dos Segredos.md

- [[Sequência 4 - Aprendiz - Feiticeiro dos Segredos]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 5 - Aprendiz - Viajante.md

- [[Sequência 5 - Aprendiz - Viajante]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 6 - Aprendiz - Escriba.md

- [[Sequência 6 - Aprendiz - Escriba]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 7 - Aprendiz - Astrólogo.md

- [[Sequência 7 - Aprendiz - Astrólogo]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 8 - Aprendiz - Mestre dos Truques.md

- [[Sequência 8 - Aprendiz - Mestre dos Truques]]

## 02 Caminhos\Sequências\Aprendiz\Sequência 9 - Aprendiz - Aprendiz.md

- [[Sequência 9 - Aprendiz - Aprendiz]]

## 02 Caminhos\Sequências\Assassino\Sequência 0 - Assassino - Demoness.md

- [[Sequência 0 - Assassino - Demoness]]

## 02 Caminhos\Sequências\Assassino\Sequência 1 - Assassino - Apocalipse.md

- [[Sequência 1 - Assassino - Apocalipse]]

## 02 Caminhos\Sequências\Assassino\Sequência 2 - Assassino - Catástrofe.md

- [[Sequência 2 - Assassino - Catástrofe]]

## 02 Caminhos\Sequências\Assassino\Sequência 3 - Assassino - Sem Idade.md

- [[Sequência 3 - Assassino - Sem Idade]]

## 02 Caminhos\Sequências\Assassino\Sequência 4 - Assassino - Desespero.md

- [[Sequência 4 - Assassino - Desespero]]

## 02 Caminhos\Sequências\Assassino\Sequência 5 - Assassino - Aflição.md

- [[Sequência 5 - Assassino - Aflição]]

## 02 Caminhos\Sequências\Assassino\Sequência 6 - Assassino - Prazer.md

- [[Sequência 6 - Assassino - Prazer]]

## 02 Caminhos\Sequências\Assassino\Sequência 7 - Assassino - Bruxa.md

- [[Sequência 7 - Assassino - Bruxa]]

## 02 Caminhos\Sequências\Assassino\Sequência 8 - Assassino - Instigador.md

- [[Sequência 8 - Assassino - Instigador]]

## 02 Caminhos\Sequências\Assassino\Sequência 9 - Assassino - Assassino.md

- [[Sequência 9 - Assassino - Assassino]]

## 02 Caminhos\Sequências\Bardo\Sequência 0 - Bardo - Sol.md

- [[Sequência 0 - Bardo - Sol]]

## 02 Caminhos\Sequências\Bardo\Sequência 1 - Bardo - Anjo Branco.md

- [[Sequência 1 - Bardo - Anjo Branco]]

## 02 Caminhos\Sequências\Bardo\Sequência 2 - Bardo - Buscador da Luz.md

- [[Sequência 2 - Bardo - Buscador da Luz]]

## 02 Caminhos\Sequências\Bardo\Sequência 3 - Bardo - Mentor da Justiça.md

- [[Sequência 3 - Bardo - Mentor da Justiça]]

## 02 Caminhos\Sequências\Bardo\Sequência 4 - Bardo - Sem Sombra.md

- [[Sequência 4 - Bardo - Sem Sombra]]

## 02 Caminhos\Sequências\Bardo\Sequência 5 - Bardo - Sacerdote da Luz.md

- [[Sequência 5 - Bardo - Sacerdote da Luz]]

## 02 Caminhos\Sequências\Bardo\Sequência 6 - Bardo - Notário.md

- [[Sequência 6 - Bardo - Notário]]

## 02 Caminhos\Sequências\Bardo\Sequência 7 - Bardo - Sumo Sacerdote Solar.md

- [[Sequência 7 - Bardo - Sumo Sacerdote Solar]]

## 02 Caminhos\Sequências\Bardo\Sequência 8 - Bardo - Suplicante da Luz.md

- [[Sequência 8 - Bardo - Suplicante da Luz]]

## 02 Caminhos\Sequências\Bardo\Sequência 9 - Bardo - Bardo.md

- [[Sequência 9 - Bardo - Bardo]]

## 02 Caminhos\Sequências\Boticário\Sequência 0 - Boticário - Lua.md

- [[Sequência 0 - Boticário - Lua]]

## 02 Caminhos\Sequências\Boticário\Sequência 1 - Boticário - Deusa da Beleza.md

- [[Sequência 1 - Boticário - Deusa da Beleza]]

## 02 Caminhos\Sequências\Boticário\Sequência 2 - Boticário - Doador de Vida.md

- [[Sequência 2 - Boticário - Doador de Vida]]

## 02 Caminhos\Sequências\Boticário\Sequência 3 - Boticário - Alto Invocador.md

- [[Sequência 3 - Boticário - Alto Invocador]]

## 02 Caminhos\Sequências\Boticário\Sequência 4 - Boticário - Rei Xamã.md

- [[Sequência 4 - Boticário - Rei Xamã]]

## 02 Caminhos\Sequências\Boticário\Sequência 5 - Boticário - Erudito Escarlate.md

- [[Sequência 5 - Boticário - Erudito Escarlate]]

## 02 Caminhos\Sequências\Boticário\Sequência 6 - Boticário - Professor de Poções.md

- [[Sequência 6 - Boticário - Professor de Poções]]

## 02 Caminhos\Sequências\Boticário\Sequência 7 - Boticário - Vampiro.md

- [[Sequência 7 - Boticário - Vampiro]]

## 02 Caminhos\Sequências\Boticário\Sequência 8 - Boticário - Domador de Bestas.md

- [[Sequência 8 - Boticário - Domador de Bestas]]

## 02 Caminhos\Sequências\Boticário\Sequência 9 - Boticário - Boticário.md

- [[Sequência 9 - Boticário - Boticário]]

## 02 Caminhos\Sequências\Caçador\Sequência 0 - Caçador - Sacerdote Vermelho.md

- [[Sequência 0 - Caçador - Sacerdote Vermelho]]

## 02 Caminhos\Sequências\Caçador\Sequência 1 - Caçador - Conquistador.md

- [[Sequência 1 - Caçador - Conquistador]]

## 02 Caminhos\Sequências\Caçador\Sequência 2 - Caçador - Feiticeiro do Clima.md

- [[Sequência 2 - Caçador - Feiticeiro do Clima]]

## 02 Caminhos\Sequências\Caçador\Sequência 3 - Caçador - Bispo da Guerra.md

- [[Sequência 3 - Caçador - Bispo da Guerra]]

## 02 Caminhos\Sequências\Caçador\Sequência 4 - Caçador - Cavaleiro de Sangue e Ferro.md

- [[Sequência 4 - Caçador - Cavaleiro de Sangue e Ferro]]

## 02 Caminhos\Sequências\Caçador\Sequência 5 - Caçador - Ceifador.md

- [[Sequência 5 - Caçador - Ceifador]]

## 02 Caminhos\Sequências\Caçador\Sequência 6 - Caçador - Conspirador.md

- [[Sequência 6 - Caçador - Conspirador]]

## 02 Caminhos\Sequências\Caçador\Sequência 7 - Caçador - Piromaníaco.md

- [[Sequência 7 - Caçador - Piromaníaco]]

## 02 Caminhos\Sequências\Caçador\Sequência 8 - Caçador - Provocador.md

- [[Sequência 8 - Caçador - Provocador]]

## 02 Caminhos\Sequências\Caçador\Sequência 9 - Caçador - Caçador.md

- [[Sequência 9 - Caçador - Caçador]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 0 - Coletor de Cadáveres - Morte.md

- [[Sequência 0 - Coletor de Cadáveres - Morte]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 1 - Coletor de Cadáveres - Imperador Pálido.md

- [[Sequência 1 - Coletor de Cadáveres - Imperador Pálido]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 2 - Coletor de Cadáveres - Cônsul da Morte.md

- [[Sequência 2 - Coletor de Cadáveres - Cônsul da Morte]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 3 - Coletor de Cadáveres - Barqueiro.md

- [[Sequência 3 - Coletor de Cadáveres - Barqueiro]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 4 - Coletor de Cadáveres - Imorredouro.md

- [[Sequência 4 - Coletor de Cadáveres - Imorredouro]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 5 - Coletor de Cadáveres - Guardião do Portão.md

- [[Sequência 5 - Coletor de Cadáveres - Guardião do Portão]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 6 - Coletor de Cadáveres - Guia Espiritual.md

- [[Sequência 6 - Coletor de Cadáveres - Guia Espiritual]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 7 - Coletor de Cadáveres - Médium Espiritual.md

- [[Sequência 7 - Coletor de Cadáveres - Médium Espiritual]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 8 - Coletor de Cadáveres - Coveiro.md

- [[Sequência 8 - Coletor de Cadáveres - Coveiro]]

## 02 Caminhos\Sequências\Coletor de Cadáveres\Sequência 9 - Coletor de Cadáveres - Coletor de Cadáveres.md

- [[Sequência 9 - Coletor de Cadáveres - Coletor de Cadáveres]]

## 02 Caminhos\Sequências\Criminoso\Sequência 0 - Criminoso - Abismo.md

- [[Sequência 0 - Criminoso - Abismo]]

## 02 Caminhos\Sequências\Criminoso\Sequência 1 - Criminoso - Monarca da Imundície.md

- [[Sequência 1 - Criminoso - Monarca da Imundície]]

## 02 Caminhos\Sequências\Criminoso\Sequência 2 - Criminoso - Arquiduque Sangrento.md

- [[Sequência 2 - Criminoso - Arquiduque Sangrento]]

## 02 Caminhos\Sequências\Criminoso\Sequência 3 - Criminoso - Tagarela.md

- [[Sequência 3 - Criminoso - Tagarela]]

## 02 Caminhos\Sequências\Criminoso\Sequência 4 - Criminoso - Demônio.md

- [[Sequência 4 - Criminoso - Demônio]]

## 02 Caminhos\Sequências\Criminoso\Sequência 5 - Criminoso - Apóstolo do Desejo.md

- [[Sequência 5 - Criminoso - Apóstolo do Desejo]]

## 02 Caminhos\Sequências\Criminoso\Sequência 6 - Criminoso - Diabo.md

- [[Sequência 6 - Criminoso - Diabo]]

## 02 Caminhos\Sequências\Criminoso\Sequência 7 - Criminoso - Assassino em Série.md

- [[Sequência 7 - Criminoso - Assassino em Série]]

## 02 Caminhos\Sequências\Criminoso\Sequência 8 - Criminoso - Anjo sem Asas.md

- [[Sequência 8 - Criminoso - Anjo sem Asas]]

## 02 Caminhos\Sequências\Criminoso\Sequência 9 - Criminoso - Criminoso.md

- [[Sequência 9 - Criminoso - Criminoso]]

## 02 Caminhos\Sequências\Espectador\Sequência 0 - Espectador - Visionário.md

- [[Sequência 0 - Espectador - Visionário]]

## 02 Caminhos\Sequências\Espectador\Sequência 1 - Espectador - Autor.md

- [[Sequência 1 - Espectador - Autor]]

## 02 Caminhos\Sequências\Espectador\Sequência 2 - Espectador - Discernidor.md

- [[Sequência 2 - Espectador - Discernidor]]

## 02 Caminhos\Sequências\Espectador\Sequência 3 - Espectador - Tecelão de Sonhos.md

- [[Sequência 3 - Espectador - Tecelão de Sonhos]]

## 02 Caminhos\Sequências\Espectador\Sequência 4 - Espectador - Manipulador.md

- [[Sequência 4 - Espectador - Manipulador]]

## 02 Caminhos\Sequências\Espectador\Sequência 5 - Espectador - Caminhante dos Sonhos.md

- [[Sequência 5 - Espectador - Caminhante dos Sonhos]]

## 02 Caminhos\Sequências\Espectador\Sequência 6 - Espectador - Hipnotizador.md

- [[Sequência 6 - Espectador - Hipnotizador]]

## 02 Caminhos\Sequências\Espectador\Sequência 7 - Espectador - Psiquiatra.md

- [[Sequência 7 - Espectador - Psiquiatra]]

## 02 Caminhos\Sequências\Espectador\Sequência 8 - Espectador - Telepata.md

- [[Sequência 8 - Espectador - Telepata]]

## 02 Caminhos\Sequências\Espectador\Sequência 9 - Espectador - Espectador.md

- [[Sequência 9 - Espectador - Espectador]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 0 - Espreitador de Mistérios - Eremita.md

- [[Sequência 0 - Espreitador de Mistérios - Eremita]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 1 - Espreitador de Mistérios - Imperador do Conhecimento.md

- [[Sequência 1 - Espreitador de Mistérios - Imperador do Conhecimento]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 2 - Espreitador de Mistérios - Sábio Místico.md

- [[Sequência 2 - Espreitador de Mistérios - Sábio Místico]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 3 - Espreitador de Mistérios - Clarividente.md

- [[Sequência 3 - Espreitador de Mistérios - Clarividente]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 4 - Espreitador de Mistérios - Misticólogo.md

- [[Sequência 4 - Espreitador de Mistérios - Misticólogo]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 5 - Espreitador de Mistérios - Mestre das Constelações.md

- [[Sequência 5 - Espreitador de Mistérios - Mestre das Constelações]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 6 - Espreitador de Mistérios - Professor de Pergaminhos.md

- [[Sequência 6 - Espreitador de Mistérios - Professor de Pergaminhos]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 7 - Espreitador de Mistérios - Bruxo.md

- [[Sequência 7 - Espreitador de Mistérios - Bruxo]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 8 - Espreitador de Mistérios - Erudito Marcial.md

- [[Sequência 8 - Espreitador de Mistérios - Erudito Marcial]]

## 02 Caminhos\Sequências\Espreitador de Mistérios\Sequência 9 - Espreitador de Mistérios - Espreitador de Mistérios.md

- [[Sequência 9 - Espreitador de Mistérios - Espreitador de Mistérios]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 0 - Guerreiro - Gigante do Crepúsculo.md

- [[Sequência 0 - Guerreiro - Gigante do Crepúsculo]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 1 - Guerreiro - Mão de Deus.md

- [[Sequência 1 - Guerreiro - Mão de Deus]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 2 - Guerreiro - Glória.md

- [[Sequência 2 - Guerreiro - Glória]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 3 - Guerreiro - Cavaleiro de Prata.md

- [[Sequência 3 - Guerreiro - Cavaleiro de Prata]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 4 - Guerreiro - Caçador de Demônios.md

- [[Sequência 4 - Guerreiro - Caçador de Demônios]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 5 - Guerreiro - Guardião.md

- [[Sequência 5 - Guerreiro - Guardião]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 6 - Guerreiro - Paladino da Alvorada.md

- [[Sequência 6 - Guerreiro - Paladino da Alvorada]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 7 - Guerreiro - Mestre das Armas.md

- [[Sequência 7 - Guerreiro - Mestre das Armas]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 8 - Guerreiro - Pugilista.md

- [[Sequência 8 - Guerreiro - Pugilista]]

## 02 Caminhos\Sequências\Guerreiro\Sequência 9 - Guerreiro - Guerreiro.md

- [[Sequência 9 - Guerreiro - Guerreiro]]

## 02 Caminhos\Sequências\Insone\Sequência 0 - Insone - Escuridão.md

- [[Sequência 0 - Insone - Escuridão]]

## 02 Caminhos\Sequências\Insone\Sequência 1 - Insone - Cavaleiro do Infortúnio.md

- [[Sequência 1 - Insone - Cavaleiro do Infortúnio]]

## 02 Caminhos\Sequências\Insone\Sequência 2 - Insone - Servo da Ocultação.md

- [[Sequência 2 - Insone - Servo da Ocultação]]

## 02 Caminhos\Sequências\Insone\Sequência 3 - Insone - Bispo do Horror.md

- [[Sequência 3 - Insone - Bispo do Horror]]

## 02 Caminhos\Sequências\Insone\Sequência 4 - Insone - Vigilante Noturno.md

- [[Sequência 4 - Insone - Vigilante Noturno]]

## 02 Caminhos\Sequências\Insone\Sequência 5 - Insone - Feiticeiro dos Espíritos.md

- [[Sequência 5 - Insone - Feiticeiro dos Espíritos]]

## 02 Caminhos\Sequências\Insone\Sequência 6 - Insone - Pacificador de Almas.md

- [[Sequência 6 - Insone - Pacificador de Almas]]

## 02 Caminhos\Sequências\Insone\Sequência 7 - Insone - Pesadelo.md

- [[Sequência 7 - Insone - Pesadelo]]

## 02 Caminhos\Sequências\Insone\Sequência 8 - Insone - Poeta da Meia-Noite.md

- [[Sequência 8 - Insone - Poeta da Meia-Noite]]

## 02 Caminhos\Sequências\Insone\Sequência 9 - Insone - Insone.md

- [[Sequência 9 - Insone - Insone]]

## 02 Caminhos\Sequências\Leitor\Sequência 0 - Leitor - Torre Branca.md

- [[Sequência 0 - Leitor - Torre Branca]]

## 02 Caminhos\Sequências\Leitor\Sequência 1 - Leitor - Olho Onisciente.md

- [[Sequência 1 - Leitor - Olho Onisciente]]

## 02 Caminhos\Sequências\Leitor\Sequência 2 - Leitor - Anjo da Sabedoria.md

- [[Sequência 2 - Leitor - Anjo da Sabedoria]]

## 02 Caminhos\Sequências\Leitor\Sequência 3 - Leitor - Conhecedor.md

- [[Sequência 3 - Leitor - Conhecedor]]

## 02 Caminhos\Sequências\Leitor\Sequência 4 - Leitor - Profeta.md

- [[Sequência 4 - Leitor - Profeta]]

## 02 Caminhos\Sequências\Leitor\Sequência 5 - Leitor - Magíster do Misticismo.md

- [[Sequência 5 - Leitor - Magíster do Misticismo]]

## 02 Caminhos\Sequências\Leitor\Sequência 6 - Leitor - Polímata.md

- [[Sequência 6 - Leitor - Polímata]]

## 02 Caminhos\Sequências\Leitor\Sequência 7 - Leitor - Detetive.md

- [[Sequência 7 - Leitor - Detetive]]

## 02 Caminhos\Sequências\Leitor\Sequência 8 - Leitor - Estudante do Raciocínio.md

- [[Sequência 8 - Leitor - Estudante do Raciocínio]]

## 02 Caminhos\Sequências\Leitor\Sequência 9 - Leitor - Leitor.md

- [[Sequência 9 - Leitor - Leitor]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 0 - Marinheiro - Tirano.md

- [[Sequência 0 - Marinheiro - Tirano]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 1 - Marinheiro - Deus do Trovão.md

- [[Sequência 1 - Marinheiro - Deus do Trovão]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 2 - Marinheiro - Calamidade.md

- [[Sequência 2 - Marinheiro - Calamidade]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 3 - Marinheiro - Rei do Mar.md

- [[Sequência 3 - Marinheiro - Rei do Mar]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 4 - Marinheiro - Sepultador de Cataclismos.md

- [[Sequência 4 - Marinheiro - Sepultador de Cataclismos]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 5 - Marinheiro - Cantor do Oceano.md

- [[Sequência 5 - Marinheiro - Cantor do Oceano]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 6 - Marinheiro - Abençoado pelo Vento.md

- [[Sequência 6 - Marinheiro - Abençoado pelo Vento]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 7 - Marinheiro - Navegante.md

- [[Sequência 7 - Marinheiro - Navegante]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 8 - Marinheiro - Povo da Fúria.md

- [[Sequência 8 - Marinheiro - Povo da Fúria]]

## 02 Caminhos\Sequências\Marinheiro\Sequência 9 - Marinheiro - Marinheiro.md

- [[Sequência 9 - Marinheiro - Marinheiro]]

## 02 Caminhos\Sequências\Monstro\Sequência 0 - Monstro - Roda da Fortuna.md

- [[Sequência 0 - Monstro - Roda da Fortuna]]

## 02 Caminhos\Sequências\Monstro\Sequência 1 - Monstro - Serpente de Mercúrio.md

- [[Sequência 1 - Monstro - Serpente de Mercúrio]]

## 02 Caminhos\Sequências\Monstro\Sequência 2 - Monstro - Adivinho.md

- [[Sequência 2 - Monstro - Adivinho]]

## 02 Caminhos\Sequências\Monstro\Sequência 3 - Monstro - Caminhante do Caos.md

- [[Sequência 3 - Monstro - Caminhante do Caos]]

## 02 Caminhos\Sequências\Monstro\Sequência 4 - Monstro - Mago do Infortúnio.md

- [[Sequência 4 - Monstro - Mago do Infortúnio]]

## 02 Caminhos\Sequências\Monstro\Sequência 5 - Monstro - Vencedor.md

- [[Sequência 5 - Monstro - Vencedor]]

## 02 Caminhos\Sequências\Monstro\Sequência 6 - Monstro - Sacerdote da Calamidade.md

- [[Sequência 6 - Monstro - Sacerdote da Calamidade]]

## 02 Caminhos\Sequências\Monstro\Sequência 7 - Monstro - Sortudo.md

- [[Sequência 7 - Monstro - Sortudo]]

## 02 Caminhos\Sequências\Monstro\Sequência 8 - Monstro - Robô.md

- [[Sequência 8 - Monstro - Robô]]

## 02 Caminhos\Sequências\Monstro\Sequência 9 - Monstro - Monstro.md

- [[Sequência 9 - Monstro - Monstro]]

## 02 Caminhos\Sequências\Plantador\Sequência 0 - Plantador - Mãe.md

- [[Sequência 0 - Plantador - Mãe]]

## 02 Caminhos\Sequências\Plantador\Sequência 1 - Plantador - Caminhante da Natureza.md

- [[Sequência 1 - Plantador - Caminhante da Natureza]]

## 02 Caminhos\Sequências\Plantador\Sequência 2 - Plantador - Matriarca da Desolação.md

- [[Sequência 2 - Plantador - Matriarca da Desolação]]

## 02 Caminhos\Sequências\Plantador\Sequência 3 - Plantador - Portador do Caixão.md

- [[Sequência 3 - Plantador - Portador do Caixão]]

## 02 Caminhos\Sequências\Plantador\Sequência 4 - Plantador - Alquimista Antigo.md

- [[Sequência 4 - Plantador - Alquimista Antigo]]

## 02 Caminhos\Sequências\Plantador\Sequência 5 - Plantador - Druida.md

- [[Sequência 5 - Plantador - Druida]]

## 02 Caminhos\Sequências\Plantador\Sequência 6 - Plantador - Biólogo.md

- [[Sequência 6 - Plantador - Biólogo]]

## 02 Caminhos\Sequências\Plantador\Sequência 7 - Plantador - Sacerdote da Colheita.md

- [[Sequência 7 - Plantador - Sacerdote da Colheita]]

## 02 Caminhos\Sequências\Plantador\Sequência 8 - Plantador - Médico.md

- [[Sequência 8 - Plantador - Médico]]

## 02 Caminhos\Sequências\Plantador\Sequência 9 - Plantador - Plantador.md

- [[Sequência 9 - Plantador - Plantador]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 0 - Prisioneiro - Acorrentado.md

- [[Sequência 0 - Prisioneiro - Acorrentado]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 1 - Prisioneiro - Abominação.md

- [[Sequência 1 - Prisioneiro - Abominação]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 2 - Prisioneiro - Flagelo Antigo.md

- [[Sequência 2 - Prisioneiro - Flagelo Antigo]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 3 - Prisioneiro - Discípulo do Silêncio.md

- [[Sequência 3 - Prisioneiro - Discípulo do Silêncio]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 4 - Prisioneiro - Marionete.md

- [[Sequência 4 - Prisioneiro - Marionete]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 5 - Prisioneiro - Espectro.md

- [[Sequência 5 - Prisioneiro - Espectro]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 6 - Prisioneiro - Zumbi.md

- [[Sequência 6 - Prisioneiro - Zumbi]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 7 - Prisioneiro - Lobisomem.md

- [[Sequência 7 - Prisioneiro - Lobisomem]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 8 - Prisioneiro - Lunático.md

- [[Sequência 8 - Prisioneiro - Lunático]]

## 02 Caminhos\Sequências\Prisioneiro\Sequência 9 - Prisioneiro - Prisioneiro.md

- [[Sequência 9 - Prisioneiro - Prisioneiro]]

## 02 Caminhos\Sequências\Saqueador\Sequência 0 - Saqueador - Erro.md

- [[Sequência 0 - Saqueador - Erro]]

## 02 Caminhos\Sequências\Saqueador\Sequência 1 - Saqueador - Verme do Tempo.md

- [[Sequência 1 - Saqueador - Verme do Tempo]]

## 02 Caminhos\Sequências\Saqueador\Sequência 2 - Saqueador - Cavalo de Troia do Destino.md

- [[Sequência 2 - Saqueador - Cavalo de Troia do Destino]]

## 02 Caminhos\Sequências\Saqueador\Sequência 3 - Saqueador - Mentor do Engano.md

- [[Sequência 3 - Saqueador - Mentor do Engano]]

## 02 Caminhos\Sequências\Saqueador\Sequência 4 - Saqueador - Parasita.md

- [[Sequência 4 - Saqueador - Parasita]]

## 02 Caminhos\Sequências\Saqueador\Sequência 5 - Saqueador - Ladrão de Sonhos.md

- [[Sequência 5 - Saqueador - Ladrão de Sonhos]]

## 02 Caminhos\Sequências\Saqueador\Sequência 6 - Saqueador - Prometeu.md

- [[Sequência 6 - Saqueador - Prometeu]]

## 02 Caminhos\Sequências\Saqueador\Sequência 7 - Saqueador - Criptologista.md

- [[Sequência 7 - Saqueador - Criptologista]]

## 02 Caminhos\Sequências\Saqueador\Sequência 8 - Saqueador - Vigarista.md

- [[Sequência 8 - Saqueador - Vigarista]]

## 02 Caminhos\Sequências\Saqueador\Sequência 9 - Saqueador - Saqueador.md

- [[Sequência 9 - Saqueador - Saqueador]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 0 - Suplicante de Segredos - Enforcado.md

- [[Sequência 0 - Suplicante de Segredos - Enforcado]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 1 - Suplicante de Segredos - Anjo Sombrio.md

- [[Sequência 1 - Suplicante de Segredos - Anjo Sombrio]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 2 - Suplicante de Segredos - Presbítero Profano.md

- [[Sequência 2 - Suplicante de Segredos - Presbítero Profano]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 3 - Suplicante de Segredos - Templário da Trindade.md

- [[Sequência 3 - Suplicante de Segredos - Templário da Trindade]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 4 - Suplicante de Segredos - Cavaleiro Negro.md

- [[Sequência 4 - Suplicante de Segredos - Cavaleiro Negro]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 5 - Suplicante de Segredos - Pastor.md

- [[Sequência 5 - Suplicante de Segredos - Pastor]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 6 - Suplicante de Segredos - Bispo da Rosa.md

- [[Sequência 6 - Suplicante de Segredos - Bispo da Rosa]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 7 - Suplicante de Segredos - Asceta das Sombras.md

- [[Sequência 7 - Suplicante de Segredos - Asceta das Sombras]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 8 - Suplicante de Segredos - Ouvinte.md

- [[Sequência 8 - Suplicante de Segredos - Ouvinte]]

## 02 Caminhos\Sequências\Suplicante de Segredos\Sequência 9 - Suplicante de Segredos - Suplicante de Segredos.md

- [[Sequência 9 - Suplicante de Segredos - Suplicante de Segredos]]

## 02 Caminhos\Sequências\Sábio\Sequência 0 - Sábio - Paragon.md

- [[Sequência 0 - Sábio - Paragon]]

## 02 Caminhos\Sequências\Sábio\Sequência 1 - Sábio - Iluminador.md

- [[Sequência 1 - Sábio - Iluminador]]

## 02 Caminhos\Sequências\Sábio\Sequência 2 - Sábio - Magíster do Conhecimento.md

- [[Sequência 2 - Sábio - Magíster do Conhecimento]]

## 02 Caminhos\Sequências\Sábio\Sequência 3 - Sábio - Erudito Arcano.md

- [[Sequência 3 - Sábio - Erudito Arcano]]

## 02 Caminhos\Sequências\Sábio\Sequência 4 - Sábio - Alquimista.md

- [[Sequência 4 - Sábio - Alquimista]]

## 02 Caminhos\Sequências\Sábio\Sequência 5 - Sábio - Astrônomo.md

- [[Sequência 5 - Sábio - Astrônomo]]

## 02 Caminhos\Sequências\Sábio\Sequência 6 - Sábio - Artesão.md

- [[Sequência 6 - Sábio - Artesão]]

## 02 Caminhos\Sequências\Sábio\Sequência 7 - Sábio - Avaliador.md

- [[Sequência 7 - Sábio - Avaliador]]

## 02 Caminhos\Sequências\Sábio\Sequência 8 - Sábio - Arqueólogo.md

- [[Sequência 8 - Sábio - Arqueólogo]]

## 02 Caminhos\Sequências\Sábio\Sequência 9 - Sábio - Sábio.md

- [[Sequência 9 - Sábio - Sábio]]

## 02 Caminhos\Sequências\Vidente\Sequência 0 - Vidente - Louco.md

- [[Sequência 0 - Vidente - Louco]]

## 02 Caminhos\Sequências\Vidente\Sequência 1 - Vidente - Servidor dos Mistérios.md

- [[Sequência 1 - Vidente - Servidor dos Mistérios]]

## 02 Caminhos\Sequências\Vidente\Sequência 2 - Vidente - Invocador de Milagres.md

- [[Sequência 2 - Vidente - Invocador de Milagres]]

## 02 Caminhos\Sequências\Vidente\Sequência 3 - Vidente - Erudito do Passado.md

- [[Sequência 3 - Vidente - Erudito do Passado]]

## 02 Caminhos\Sequências\Vidente\Sequência 4 - Vidente - Feiticeiro Bizarro.md

- [[Sequência 4 - Vidente - Feiticeiro Bizarro]]

## 02 Caminhos\Sequências\Vidente\Sequência 5 - Vidente - Marionetista.md

- [[Sequência 5 - Vidente - Marionetista]]

## 02 Caminhos\Sequências\Vidente\Sequência 6 - Vidente - Sem Rosto.md

- [[Sequência 6 - Vidente - Sem Rosto]]

## 02 Caminhos\Sequências\Vidente\Sequência 7 - Vidente - Mágico.md

- [[Sequência 7 - Vidente - Mágico]]

## 02 Caminhos\Sequências\Vidente\Sequência 8 - Vidente - Palhaço.md

- [[Sequência 8 - Vidente - Palhaço]]

## 02 Caminhos\Sequências\Vidente\Sequência 9 - Vidente - Vidente.md

- [[Sequência 9 - Vidente - Vidente]]

## 02 Caminhos\Sequências\Árbitro\Sequência 0 - Árbitro - Justiceiro.md

- [[Sequência 0 - Árbitro - Justiceiro]]

## 02 Caminhos\Sequências\Árbitro\Sequência 1 - Árbitro - Mão da Ordem.md

- [[Sequência 1 - Árbitro - Mão da Ordem]]

## 02 Caminhos\Sequências\Árbitro\Sequência 2 - Árbitro - Equilibrador.md

- [[Sequência 2 - Árbitro - Equilibrador]]

## 02 Caminhos\Sequências\Árbitro\Sequência 3 - Árbitro - Caçador do Caos.md

- [[Sequência 3 - Árbitro - Caçador do Caos]]

## 02 Caminhos\Sequências\Árbitro\Sequência 4 - Árbitro - Mago Imperativo.md

- [[Sequência 4 - Árbitro - Mago Imperativo]]

## 02 Caminhos\Sequências\Árbitro\Sequência 5 - Árbitro - Paladino Disciplinar.md

- [[Sequência 5 - Árbitro - Paladino Disciplinar]]

## 02 Caminhos\Sequências\Árbitro\Sequência 6 - Árbitro - Juiz.md

- [[Sequência 6 - Árbitro - Juiz]]

## 02 Caminhos\Sequências\Árbitro\Sequência 7 - Árbitro - Interrogador.md

- [[Sequência 7 - Árbitro - Interrogador]]

## 02 Caminhos\Sequências\Árbitro\Sequência 8 - Árbitro - Xerife.md

- [[Sequência 8 - Árbitro - Xerife]]

## 02 Caminhos\Sequências\Árbitro\Sequência 9 - Árbitro - Árbitro.md

- [[Sequência 9 - Árbitro - Árbitro]]

## 02 Caminhos\Índice dos 22 Caminhos.md

- [[Índice dos 22 Caminhos]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S0 - Autoridade de Imperador Negro.md

- [[Poder - Advogado S0 - Autoridade de Imperador Negro]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S1 - Autoridade de Príncipe da Abolição.md

- [[Poder - Advogado S1 - Autoridade de Príncipe da Abolição]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S2 - Autoridade de Duque da Entropia.md

- [[Poder - Advogado S2 - Autoridade de Duque da Entropia]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S3 - Autoridade de Mago Frenético.md

- [[Poder - Advogado S3 - Autoridade de Mago Frenético]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S4 - Autoridade de Conde dos Caídos.md

- [[Poder - Advogado S4 - Autoridade de Conde dos Caídos]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S5 - Desordem focal.md

- [[Poder - Advogado S5 - Desordem focal]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S6 - Distorção de percurso.md

- [[Poder - Advogado S6 - Distorção de percurso]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S7 - Presente comprometedor.md

- [[Poder - Advogado S7 - Presente comprometedor]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S8 - Autoridade da força.md

- [[Poder - Advogado S8 - Autoridade da força]]

## 03 Poderes e habilidades\Advogado\Poder - Advogado S9 - Brecha contratual.md

- [[Poder - Advogado S9 - Brecha contratual]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S0 - Autoridade de Porta.md

- [[Poder - Aprendiz S0 - Autoridade de Porta]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S1 - Autoridade de Chave das Estrelas.md

- [[Poder - Aprendiz S1 - Autoridade de Chave das Estrelas]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S2 - Autoridade de Caminhante dos Planos.md

- [[Poder - Aprendiz S2 - Autoridade de Caminhante dos Planos]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S3 - Autoridade de Andarilho.md

- [[Poder - Aprendiz S3 - Autoridade de Andarilho]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S4 - Autoridade de Feiticeiro dos Segredos.md

- [[Poder - Aprendiz S4 - Autoridade de Feiticeiro dos Segredos]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S5 - Travessia conhecida.md

- [[Poder - Aprendiz S5 - Travessia conhecida]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S6 - Registro único.md

- [[Poder - Aprendiz S6 - Registro único]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S7 - Carta celeste.md

- [[Poder - Aprendiz S7 - Carta celeste]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S8 - Truque oportuno.md

- [[Poder - Aprendiz S8 - Truque oportuno]]

## 03 Poderes e habilidades\Aprendiz\Poder - Aprendiz S9 - Porta simbólica.md

- [[Poder - Aprendiz S9 - Porta simbólica]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S0 - Autoridade de Demoness.md

- [[Poder - Assassino S0 - Autoridade de Demoness]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S1 - Autoridade de Apocalipse.md

- [[Poder - Assassino S1 - Autoridade de Apocalipse]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S2 - Autoridade de Catástrofe.md

- [[Poder - Assassino S2 - Autoridade de Catástrofe]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S3 - Autoridade de Sem Idade.md

- [[Poder - Assassino S3 - Autoridade de Sem Idade]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S4 - Autoridade de Desespero.md

- [[Poder - Assassino S4 - Autoridade de Desespero]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S5 - Aflição marcada.md

- [[Poder - Assassino S5 - Aflição marcada]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S6 - Fio de fascínio.md

- [[Poder - Assassino S6 - Fio de fascínio]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S7 - Reflexo substituto.md

- [[Poder - Assassino S7 - Reflexo substituto]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S8 - Centelha de discórdia.md

- [[Poder - Assassino S8 - Centelha de discórdia]]

## 03 Poderes e habilidades\Assassino\Poder - Assassino S9 - Passo de emboscada.md

- [[Poder - Assassino S9 - Passo de emboscada]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S0 - Autoridade de Sol.md

- [[Poder - Bardo S0 - Autoridade de Sol]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S1 - Autoridade de Anjo Branco.md

- [[Poder - Bardo S1 - Autoridade de Anjo Branco]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S2 - Autoridade de Buscador da Luz.md

- [[Poder - Bardo S2 - Autoridade de Buscador da Luz]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S3 - Autoridade de Mentor da Justiça.md

- [[Poder - Bardo S3 - Autoridade de Mentor da Justiça]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S4 - Autoridade de Sem Sombra.md

- [[Poder - Bardo S4 - Autoridade de Sem Sombra]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S5 - Purificação focal.md

- [[Poder - Bardo S5 - Purificação focal]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S6 - Pacto testemunhado.md

- [[Poder - Bardo S6 - Pacto testemunhado]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S7 - Bênção de vigília.md

- [[Poder - Bardo S7 - Bênção de vigília]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S8 - Luz que denuncia.md

- [[Poder - Bardo S8 - Luz que denuncia]]

## 03 Poderes e habilidades\Bardo\Poder - Bardo S9 - Verso de coragem.md

- [[Poder - Bardo S9 - Verso de coragem]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S0 - Autoridade de Lua.md

- [[Poder - Boticário S0 - Autoridade de Lua]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S1 - Autoridade de Deusa da Beleza.md

- [[Poder - Boticário S1 - Autoridade de Deusa da Beleza]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S2 - Autoridade de Doador de Vida.md

- [[Poder - Boticário S2 - Autoridade de Doador de Vida]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S3 - Autoridade de Alto Invocador.md

- [[Poder - Boticário S3 - Autoridade de Alto Invocador]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S4 - Autoridade de Rei Xamã.md

- [[Poder - Boticário S4 - Autoridade de Rei Xamã]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S5 - Chamado escarlate.md

- [[Poder - Boticário S5 - Chamado escarlate]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S6 - Preparado de estabilidade.md

- [[Poder - Boticário S6 - Preparado de estabilidade]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S7 - Vigor sanguíneo.md

- [[Poder - Boticário S7 - Vigor sanguíneo]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S8 - Entendimento da besta.md

- [[Poder - Boticário S8 - Entendimento da besta]]

## 03 Poderes e habilidades\Boticário\Poder - Boticário S9 - Dose de socorro.md

- [[Poder - Boticário S9 - Dose de socorro]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S0 - Autoridade de Sacerdote Vermelho.md

- [[Poder - Caçador S0 - Autoridade de Sacerdote Vermelho]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S1 - Autoridade de Conquistador.md

- [[Poder - Caçador S1 - Autoridade de Conquistador]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S2 - Autoridade de Feiticeiro do Clima.md

- [[Poder - Caçador S2 - Autoridade de Feiticeiro do Clima]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S3 - Autoridade de Bispo da Guerra.md

- [[Poder - Caçador S3 - Autoridade de Bispo da Guerra]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S4 - Autoridade de Cavaleiro de Sangue e Ferro.md

- [[Poder - Caçador S4 - Autoridade de Cavaleiro de Sangue e Ferro]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S5 - Golpe na abertura.md

- [[Poder - Caçador S5 - Golpe na abertura]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S6 - Plano em camadas.md

- [[Poder - Caçador S6 - Plano em camadas]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S7 - Lança de brasa.md

- [[Poder - Caçador S7 - Lança de brasa]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S8 - Provocação calculada.md

- [[Poder - Caçador S8 - Provocação calculada]]

## 03 Poderes e habilidades\Caçador\Poder - Caçador S9 - Rastro escolhido.md

- [[Poder - Caçador S9 - Rastro escolhido]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S0 - Autoridade de Morte.md

- [[Poder - Coletor de Cadáveres S0 - Autoridade de Morte]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido.md

- [[Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte.md

- [[Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro.md

- [[Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro.md

- [[Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S5 - Portão contido.md

- [[Poder - Coletor de Cadáveres S5 - Portão contido]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S6 - Guia do limiar.md

- [[Poder - Coletor de Cadáveres S6 - Guia do limiar]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S7 - Audiência dos mortos.md

- [[Poder - Coletor de Cadáveres S7 - Audiência dos mortos]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S8 - Voz junto à sepultura.md

- [[Poder - Coletor de Cadáveres S8 - Voz junto à sepultura]]

## 03 Poderes e habilidades\Coletor de Cadáveres\Poder - Coletor de Cadáveres S9 - Exame do último vestígio.md

- [[Poder - Coletor de Cadáveres S9 - Exame do último vestígio]]

## 03 Poderes e habilidades\Controle mental e agência.md

- [[Controle mental e agência]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S0 - Autoridade de Abismo.md

- [[Poder - Criminoso S0 - Autoridade de Abismo]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S1 - Autoridade de Monarca da Imundície.md

- [[Poder - Criminoso S1 - Autoridade de Monarca da Imundície]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S2 - Autoridade de Arquiduque Sangrento.md

- [[Poder - Criminoso S2 - Autoridade de Arquiduque Sangrento]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S3 - Autoridade de Tagarela.md

- [[Poder - Criminoso S3 - Autoridade de Tagarela]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S4 - Autoridade de Demônio.md

- [[Poder - Criminoso S4 - Autoridade de Demônio]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S5 - Desejo exposto.md

- [[Poder - Criminoso S5 - Desejo exposto]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S6 - Chama do diabo.md

- [[Poder - Criminoso S6 - Chama do diabo]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S7 - Padrão predatório.md

- [[Poder - Criminoso S7 - Padrão predatório]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S8 - Frieza calculada.md

- [[Poder - Criminoso S8 - Frieza calculada]]

## 03 Poderes e habilidades\Criminoso\Poder - Criminoso S9 - Sentido de ameaça.md

- [[Poder - Criminoso S9 - Sentido de ameaça]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S0 - Autoridade de Visionário.md

- [[Poder - Espectador S0 - Autoridade de Visionário]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S1 - Autoridade de Autor.md

- [[Poder - Espectador S1 - Autoridade de Autor]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S2 - Autoridade de Discernidor.md

- [[Poder - Espectador S2 - Autoridade de Discernidor]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S3 - Autoridade de Tecelão de Sonhos.md

- [[Poder - Espectador S3 - Autoridade de Tecelão de Sonhos]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S4 - Autoridade de Manipulador.md

- [[Poder - Espectador S4 - Autoridade de Manipulador]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S5 - Passo no sonho.md

- [[Poder - Espectador S5 - Passo no sonho]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S6 - Sugestão de um gesto.md

- [[Poder - Espectador S6 - Sugestão de um gesto]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S7 - Recompor a identidade.md

- [[Poder - Espectador S7 - Recompor a identidade]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S8 - Eco de pensamento.md

- [[Poder - Espectador S8 - Eco de pensamento]]

## 03 Poderes e habilidades\Espectador\Poder - Espectador S9 - Leitura da plateia.md

- [[Poder - Espectador S9 - Leitura da plateia]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S0 - Autoridade de Eremita.md

- [[Poder - Espreitador de Mistérios S0 - Autoridade de Eremita]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S1 - Autoridade de Imperador do Conhecimento.md

- [[Poder - Espreitador de Mistérios S1 - Autoridade de Imperador do Conhecimento]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S2 - Autoridade de Sábio Místico.md

- [[Poder - Espreitador de Mistérios S2 - Autoridade de Sábio Místico]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente.md

- [[Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S4 - Autoridade de Misticólogo.md

- [[Poder - Espreitador de Mistérios S4 - Autoridade de Misticólogo]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S5 - Mapa das constelações.md

- [[Poder - Espreitador de Mistérios S5 - Mapa das constelações]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S6 - Pergaminho preparado.md

- [[Poder - Espreitador de Mistérios S6 - Pergaminho preparado]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S7 - Fórmula breve.md

- [[Poder - Espreitador de Mistérios S7 - Fórmula breve]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S8 - Geometria marcial.md

- [[Poder - Espreitador de Mistérios S8 - Geometria marcial]]

## 03 Poderes e habilidades\Espreitador de Mistérios\Poder - Espreitador de Mistérios S9 - Anotação do oculto.md

- [[Poder - Espreitador de Mistérios S9 - Anotação do oculto]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S0 - Autoridade de Gigante do Crepúsculo.md

- [[Poder - Guerreiro S0 - Autoridade de Gigante do Crepúsculo]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S1 - Autoridade de Mão de Deus.md

- [[Poder - Guerreiro S1 - Autoridade de Mão de Deus]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S2 - Autoridade de Glória.md

- [[Poder - Guerreiro S2 - Autoridade de Glória]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S3 - Autoridade de Cavaleiro de Prata.md

- [[Poder - Guerreiro S3 - Autoridade de Cavaleiro de Prata]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S4 - Autoridade de Caçador de Demônios.md

- [[Poder - Guerreiro S4 - Autoridade de Caçador de Demônios]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S5 - Bastião de um nome.md

- [[Poder - Guerreiro S5 - Bastião de um nome]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S6 - Arma da alvorada.md

- [[Poder - Guerreiro S6 - Arma da alvorada]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S7 - Leitura do adversário.md

- [[Poder - Guerreiro S7 - Leitura do adversário]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S8 - Golpe de pugilista.md

- [[Poder - Guerreiro S8 - Golpe de pugilista]]

## 03 Poderes e habilidades\Guerreiro\Poder - Guerreiro S9 - Força aplicada.md

- [[Poder - Guerreiro S9 - Força aplicada]]

## 03 Poderes e habilidades\Insone\Poder - Insone S0 - Autoridade de Escuridão.md

- [[Poder - Insone S0 - Autoridade de Escuridão]]

## 03 Poderes e habilidades\Insone\Poder - Insone S1 - Autoridade de Cavaleiro do Infortúnio.md

- [[Poder - Insone S1 - Autoridade de Cavaleiro do Infortúnio]]

## 03 Poderes e habilidades\Insone\Poder - Insone S2 - Autoridade de Servo da Ocultação.md

- [[Poder - Insone S2 - Autoridade de Servo da Ocultação]]

## 03 Poderes e habilidades\Insone\Poder - Insone S3 - Autoridade de Bispo do Horror.md

- [[Poder - Insone S3 - Autoridade de Bispo do Horror]]

## 03 Poderes e habilidades\Insone\Poder - Insone S4 - Autoridade de Vigilante Noturno.md

- [[Poder - Insone S4 - Autoridade de Vigilante Noturno]]

## 03 Poderes e habilidades\Insone\Poder - Insone S5 - Pacto de vigília.md

- [[Poder - Insone S5 - Pacto de vigília]]

## 03 Poderes e habilidades\Insone\Poder - Insone S6 - Quietude da alma.md

- [[Poder - Insone S6 - Quietude da alma]]

## 03 Poderes e habilidades\Insone\Poder - Insone S7 - Limiar de pesadelo.md

- [[Poder - Insone S7 - Limiar de pesadelo]]

## 03 Poderes e habilidades\Insone\Poder - Insone S8 - Poema do repouso.md

- [[Poder - Insone S8 - Poema do repouso]]

## 03 Poderes e habilidades\Insone\Poder - Insone S9 - Vigília sensível.md

- [[Poder - Insone S9 - Vigília sensível]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S0 - Autoridade de Torre Branca.md

- [[Poder - Leitor S0 - Autoridade de Torre Branca]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S1 - Autoridade de Olho Onisciente.md

- [[Poder - Leitor S1 - Autoridade de Olho Onisciente]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S2 - Autoridade de Anjo da Sabedoria.md

- [[Poder - Leitor S2 - Autoridade de Anjo da Sabedoria]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S3 - Autoridade de Conhecedor.md

- [[Poder - Leitor S3 - Autoridade de Conhecedor]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S4 - Autoridade de Profeta.md

- [[Poder - Leitor S4 - Autoridade de Profeta]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S5 - Contrapadrão.md

- [[Poder - Leitor S5 - Contrapadrão]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S6 - Imitação estudada.md

- [[Poder - Leitor S6 - Imitação estudada]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S7 - Dedução de campo.md

- [[Poder - Leitor S7 - Dedução de campo]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S8 - Hipótese contrastada.md

- [[Poder - Leitor S8 - Hipótese contrastada]]

## 03 Poderes e habilidades\Leitor\Poder - Leitor S9 - Índice mental.md

- [[Poder - Leitor S9 - Índice mental]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S0 - Autoridade de Tirano.md

- [[Poder - Marinheiro S0 - Autoridade de Tirano]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S1 - Autoridade de Deus do Trovão.md

- [[Poder - Marinheiro S1 - Autoridade de Deus do Trovão]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S2 - Autoridade de Calamidade.md

- [[Poder - Marinheiro S2 - Autoridade de Calamidade]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S3 - Autoridade de Rei do Mar.md

- [[Poder - Marinheiro S3 - Autoridade de Rei do Mar]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S4 - Autoridade de Sepultador de Cataclismos.md

- [[Poder - Marinheiro S4 - Autoridade de Sepultador de Cataclismos]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S5 - Voz do oceano.md

- [[Poder - Marinheiro S5 - Voz do oceano]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S6 - Passagem do vento.md

- [[Poder - Marinheiro S6 - Passagem do vento]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S7 - Rumo contra a tempestade.md

- [[Poder - Marinheiro S7 - Rumo contra a tempestade]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S8 - Investida da fúria.md

- [[Poder - Marinheiro S8 - Investida da fúria]]

## 03 Poderes e habilidades\Marinheiro\Poder - Marinheiro S9 - Corpo das marés.md

- [[Poder - Marinheiro S9 - Corpo das marés]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S0 - Autoridade de Roda da Fortuna.md

- [[Poder - Monstro S0 - Autoridade de Roda da Fortuna]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S1 - Autoridade de Serpente de Mercúrio.md

- [[Poder - Monstro S1 - Autoridade de Serpente de Mercúrio]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S2 - Autoridade de Adivinho.md

- [[Poder - Monstro S2 - Autoridade de Adivinho]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S3 - Autoridade de Caminhante do Caos.md

- [[Poder - Monstro S3 - Autoridade de Caminhante do Caos]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S4 - Autoridade de Mago do Infortúnio.md

- [[Poder - Monstro S4 - Autoridade de Mago do Infortúnio]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S5 - Janela do vencedor.md

- [[Poder - Monstro S5 - Janela do vencedor]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S6 - Aviso de calamidade.md

- [[Poder - Monstro S6 - Aviso de calamidade]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S7 - Desvio de sorte.md

- [[Poder - Monstro S7 - Desvio de sorte]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S8 - Rotina calculada.md

- [[Poder - Monstro S8 - Rotina calculada]]

## 03 Poderes e habilidades\Monstro\Poder - Monstro S9 - Pressentir a ruptura.md

- [[Poder - Monstro S9 - Pressentir a ruptura]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S0 - Autoridade de Mãe.md

- [[Poder - Plantador S0 - Autoridade de Mãe]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S1 - Autoridade de Caminhante da Natureza.md

- [[Poder - Plantador S1 - Autoridade de Caminhante da Natureza]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S2 - Autoridade de Matriarca da Desolação.md

- [[Poder - Plantador S2 - Autoridade de Matriarca da Desolação]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S3 - Autoridade de Portador do Caixão.md

- [[Poder - Plantador S3 - Autoridade de Portador do Caixão]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S4 - Autoridade de Alquimista Antigo.md

- [[Poder - Plantador S4 - Autoridade de Alquimista Antigo]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S5 - Forma de travessia.md

- [[Poder - Plantador S5 - Forma de travessia]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S6 - Análise orgânica.md

- [[Poder - Plantador S6 - Análise orgânica]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S7 - Crescimento oportuno.md

- [[Poder - Plantador S7 - Crescimento oportuno]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S8 - Cuidados de campo.md

- [[Poder - Plantador S8 - Cuidados de campo]]

## 03 Poderes e habilidades\Plantador\Poder - Plantador S9 - Leitura do solo.md

- [[Poder - Plantador S9 - Leitura do solo]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S0 - Autoridade de Acorrentado.md

- [[Poder - Prisioneiro S0 - Autoridade de Acorrentado]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S1 - Autoridade de Abominação.md

- [[Poder - Prisioneiro S1 - Autoridade de Abominação]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S2 - Autoridade de Flagelo Antigo.md

- [[Poder - Prisioneiro S2 - Autoridade de Flagelo Antigo]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S3 - Autoridade de Discípulo do Silêncio.md

- [[Poder - Prisioneiro S3 - Autoridade de Discípulo do Silêncio]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S4 - Autoridade de Marionete.md

- [[Poder - Prisioneiro S4 - Autoridade de Marionete]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S5 - Visita espectral.md

- [[Poder - Prisioneiro S5 - Visita espectral]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S6 - Corpo do frio.md

- [[Poder - Prisioneiro S6 - Corpo do frio]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S7 - Garras do limiar.md

- [[Poder - Prisioneiro S7 - Garras do limiar]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S8 - Instinto contido.md

- [[Poder - Prisioneiro S8 - Instinto contido]]

## 03 Poderes e habilidades\Prisioneiro\Poder - Prisioneiro S9 - Limites da cela.md

- [[Poder - Prisioneiro S9 - Limites da cela]]

## 03 Poderes e habilidades\Regras dos poderes.md

- [[Regras dos poderes]]

## 03 Poderes e habilidades\Roubo cópia destino e invocações.md

- [[Roubo cópia destino e invocações]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S0 - Autoridade de Erro.md

- [[Poder - Saqueador S0 - Autoridade de Erro]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S1 - Autoridade de Verme do Tempo.md

- [[Poder - Saqueador S1 - Autoridade de Verme do Tempo]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino.md

- [[Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S3 - Autoridade de Mentor do Engano.md

- [[Poder - Saqueador S3 - Autoridade de Mentor do Engano]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S4 - Autoridade de Parasita.md

- [[Poder - Saqueador S4 - Autoridade de Parasita]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S5 - Subtrair a intenção.md

- [[Poder - Saqueador S5 - Subtrair a intenção]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S6 - Furto de chama.md

- [[Poder - Saqueador S6 - Furto de chama]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S7 - Chave de leitura.md

- [[Poder - Saqueador S7 - Chave de leitura]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S8 - Proposta enviesada.md

- [[Poder - Saqueador S8 - Proposta enviesada]]

## 03 Poderes e habilidades\Saqueador\Poder - Saqueador S9 - Mãos do intervalo.md

- [[Poder - Saqueador S9 - Mãos do intervalo]]

## 03 Poderes e habilidades\Servos e repertórios.md

- [[Servos e repertórios]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S0 - Autoridade de Enforcado.md

- [[Poder - Suplicante de Segredos S0 - Autoridade de Enforcado]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S1 - Autoridade de Anjo Sombrio.md

- [[Poder - Suplicante de Segredos S1 - Autoridade de Anjo Sombrio]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S2 - Autoridade de Presbítero Profano.md

- [[Poder - Suplicante de Segredos S2 - Autoridade de Presbítero Profano]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade.md

- [[Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S4 - Autoridade de Cavaleiro Negro.md

- [[Poder - Suplicante de Segredos S4 - Autoridade de Cavaleiro Negro]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S5 - Pastoreio de eco.md

- [[Poder - Suplicante de Segredos S5 - Pastoreio de eco]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S6 - Carne maleável.md

- [[Poder - Suplicante de Segredos S6 - Carne maleável]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S7 - Abrigo de sombra.md

- [[Poder - Suplicante de Segredos S7 - Abrigo de sombra]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S8 - Escuta vedada.md

- [[Poder - Suplicante de Segredos S8 - Escuta vedada]]

## 03 Poderes e habilidades\Suplicante de Segredos\Poder - Suplicante de Segredos S9 - Súplica delimitada.md

- [[Poder - Suplicante de Segredos S9 - Súplica delimitada]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S0 - Autoridade de Paragon.md

- [[Poder - Sábio S0 - Autoridade de Paragon]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S1 - Autoridade de Iluminador.md

- [[Poder - Sábio S1 - Autoridade de Iluminador]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S2 - Autoridade de Magíster do Conhecimento.md

- [[Poder - Sábio S2 - Autoridade de Magíster do Conhecimento]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S3 - Autoridade de Erudito Arcano.md

- [[Poder - Sábio S3 - Autoridade de Erudito Arcano]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S4 - Autoridade de Alquimista.md

- [[Poder - Sábio S4 - Autoridade de Alquimista]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S5 - Instrumento estelar.md

- [[Poder - Sábio S5 - Instrumento estelar]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S6 - Oficina de urgência.md

- [[Poder - Sábio S6 - Oficina de urgência]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S7 - Avaliar o perigo.md

- [[Poder - Sábio S7 - Avaliar o perigo]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S8 - Camadas do tempo.md

- [[Poder - Sábio S8 - Camadas do tempo]]

## 03 Poderes e habilidades\Sábio\Poder - Sábio S9 - Memória de oficina.md

- [[Poder - Sábio S9 - Memória de oficina]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S0 - Autoridade de Louco.md

- [[Poder - Vidente S0 - Autoridade de Louco]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S1 - Autoridade de Servidor dos Mistérios.md

- [[Poder - Vidente S1 - Autoridade de Servidor dos Mistérios]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S2 - Autoridade de Invocador de Milagres.md

- [[Poder - Vidente S2 - Autoridade de Invocador de Milagres]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S3 - Autoridade de Erudito do Passado.md

- [[Poder - Vidente S3 - Autoridade de Erudito do Passado]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro.md

- [[Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S5 - Fios da marionete.md

- [[Poder - Vidente S5 - Fios da marionete]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S6 - Máscara sem rosto.md

- [[Poder - Vidente S6 - Máscara sem rosto]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S7 - Truques do palco velado.md

- [[Poder - Vidente S7 - Truques do palco velado]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S8 - Equilíbrio do palhaço.md

- [[Poder - Vidente S8 - Equilíbrio do palhaço]]

## 03 Poderes e habilidades\Vidente\Poder - Vidente S9 - Olhar para o presságio.md

- [[Poder - Vidente S9 - Olhar para o presságio]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S0 - Autoridade de Justiceiro.md

- [[Poder - Árbitro S0 - Autoridade de Justiceiro]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S1 - Autoridade de Mão da Ordem.md

- [[Poder - Árbitro S1 - Autoridade de Mão da Ordem]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S2 - Autoridade de Equilibrador.md

- [[Poder - Árbitro S2 - Autoridade de Equilibrador]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S3 - Autoridade de Caçador do Caos.md

- [[Poder - Árbitro S3 - Autoridade de Caçador do Caos]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S4 - Autoridade de Mago Imperativo.md

- [[Poder - Árbitro S4 - Autoridade de Mago Imperativo]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S5 - Sanção disciplinar.md

- [[Poder - Árbitro S5 - Sanção disciplinar]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S6 - Proibição enunciada.md

- [[Poder - Árbitro S6 - Proibição enunciada]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S7 - Pergunta que pesa.md

- [[Poder - Árbitro S7 - Pergunta que pesa]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S8 - Olhar do xerife.md

- [[Poder - Árbitro S8 - Olhar do xerife]]

## 03 Poderes e habilidades\Árbitro\Poder - Árbitro S9 - Voz de mediação.md

- [[Poder - Árbitro S9 - Voz de mediação]]

## 03 Poderes e habilidades\Índice de poderes.md

- [[Índice de poderes]]

## 04 Poções e avanço\Avanço e consumo.md

- [[Avanço e consumo]]

## 04 Poções e avanço\Avanços\Avanços do Advogado.md

- [[Avanços do Advogado]]

## 04 Poções e avanço\Avanços\Avanços do Aprendiz.md

- [[Avanços do Aprendiz]]

## 04 Poções e avanço\Avanços\Avanços do Assassino.md

- [[Avanços do Assassino]]

## 04 Poções e avanço\Avanços\Avanços do Bardo.md

- [[Avanços do Bardo]]

## 04 Poções e avanço\Avanços\Avanços do Boticário.md

- [[Avanços do Boticário]]

## 04 Poções e avanço\Avanços\Avanços do Caçador.md

- [[Avanços do Caçador]]

## 04 Poções e avanço\Avanços\Avanços do Coletor de Cadáveres.md

- [[Avanços do Coletor de Cadáveres]]

## 04 Poções e avanço\Avanços\Avanços do Criminoso.md

- [[Avanços do Criminoso]]

## 04 Poções e avanço\Avanços\Avanços do Espectador.md

- [[Avanços do Espectador]]

## 04 Poções e avanço\Avanços\Avanços do Espreitador de Mistérios.md

- [[Avanços do Espreitador de Mistérios]]

## 04 Poções e avanço\Avanços\Avanços do Guerreiro.md

- [[Avanços do Guerreiro]]

## 04 Poções e avanço\Avanços\Avanços do Insone.md

- [[Avanços do Insone]]

## 04 Poções e avanço\Avanços\Avanços do Leitor.md

- [[Avanços do Leitor]]

## 04 Poções e avanço\Avanços\Avanços do Marinheiro.md

- [[Avanços do Marinheiro]]

## 04 Poções e avanço\Avanços\Avanços do Monstro.md

- [[Avanços do Monstro]]

## 04 Poções e avanço\Avanços\Avanços do Plantador.md

- [[Avanços do Plantador]]

## 04 Poções e avanço\Avanços\Avanços do Prisioneiro.md

- [[Avanços do Prisioneiro]]

## 04 Poções e avanço\Avanços\Avanços do Saqueador.md

- [[Avanços do Saqueador]]

## 04 Poções e avanço\Avanços\Avanços do Suplicante de Segredos.md

- [[Avanços do Suplicante de Segredos]]

## 04 Poções e avanço\Avanços\Avanços do Sábio.md

- [[Avanços do Sábio]]

## 04 Poções e avanço\Avanços\Avanços do Vidente.md

- [[Avanços do Vidente]]

## 04 Poções e avanço\Avanços\Avanços do Árbitro.md

- [[Avanços do Árbitro]]

## 04 Poções e avanço\Digestão e atuação.md

- [[Digestão e atuação]]

## 04 Poções e avanço\Fórmulas e ingredientes.md

- [[Fórmulas e ingredientes]]

## 04 Poções e avanço\Poções e fórmulas.md

- [[Poções e fórmulas]]

## 05 Rituais\Catálogo de rituais.md

- [[Catálogo de rituais]]

## 05 Rituais\Catálogo\Ritual - Círculo de proteção.md

- [[Ritual - Círculo de proteção]]

## 05 Rituais\Catálogo\Ritual - Mensagem no limiar.md

- [[Ritual - Mensagem no limiar]]

## 05 Rituais\Catálogo\Ritual - Oferta à Vigia.md

- [[Ritual - Oferta à Vigia]]

## 05 Rituais\Catálogo\Ritual - Pergunta ao vestígio.md

- [[Ritual - Pergunta ao vestígio]]

## 05 Rituais\Catálogo\Ritual - Purificar um vestígio.md

- [[Ritual - Purificar um vestígio]]

## 05 Rituais\Catálogo\Ritual - Selar um objeto.md

- [[Ritual - Selar um objeto]]

## 05 Rituais\Criar um ritual.md

- [[Criar um ritual]]

## 05 Rituais\Exemplo completo de ritual.md

- [[Exemplo completo de ritual]]

## 05 Rituais\Nomes honoríficos e mundo espiritual.md

- [[Nomes honoríficos e mundo espiritual]]

## 05 Rituais\Procedimento de rituais.md

- [[Procedimento de rituais]]

## 06 Corrupção e perda de controle\Corrupção.md

- [[Corrupção]]

## 06 Corrupção e perda de controle\Maldições e humanidade.md

- [[Maldições e humanidade]]

## 06 Corrupção e perda de controle\Perda de controle.md

- [[Perda de controle]]

## 06 Corrupção e perda de controle\Tratamento e recuperação.md

- [[Tratamento e recuperação]]

## 07 Itens e características\Características Beyonder.md

- [[Características Beyonder]]

## 07 Itens e características\Catálogo\Objeto - Lente do observador tardio.md

- [[Objeto - Lente do observador tardio]]

## 07 Itens e características\Catálogo\Objeto - Luvas do afogado.md

- [[Objeto - Luvas do afogado]]

## 07 Itens e características\Catálogo\Objeto - Sineta sem badalo.md

- [[Objeto - Sineta sem badalo]]

## 07 Itens e características\Objetos selados.md

- [[Objetos selados]]

## 07 Itens e características\Projetos e fabricação.md

- [[Projetos e fabricação]]

## 08 Guia do mestre\Condução da campanha.md

- [[Condução da campanha]]

## 08 Guia do mestre\Investigação e divinação.md

- [[Investigação e divinação]]

## 08 Guia do mestre\Módulo angelical e divino.md

- [[Módulo angelical e divino]]

## 08 Guia do mestre\Módulo dos santos.md

- [[Módulo dos santos]]

## 08 Guia do mestre\Orçamento de equilíbrio.md

- [[Orçamento de equilíbrio]]

## 09 Campanha\A sineta sob a chuva - Apresentação.md

- [[A sineta sob a chuva - Apresentação]]

## 09 Campanha\Diário de campanha.md

- [[Diário de campanha]]

## 09 Campanha\Locais\Local - Armazém 17.md

- [[Local - Armazém 17]]

## 09 Campanha\Locais\Local - Casa do Último Lampião.md

- [[Local - Casa do Último Lampião]]

## 09 Campanha\Locais\Local - Escada da Maré.md

- [[Local - Escada da Maré]]

## 09 Campanha\Mestre\A sineta sob a chuva - Guia do mestre.md

- [[A sineta sob a chuva - Guia do mestre]]

## 09 Campanha\Mestre\Ameaças\Ameaça - Carregador coagido.md

- [[Ameaça - Carregador coagido]]

## 09 Campanha\Mestre\Ameaças\Ameaça - Eco da sineta.md

- [[Ameaça - Eco da sineta]]

## 09 Campanha\Mestre\NPCs\NPC - Beatriz Arlen.md

- [[NPC - Beatriz Arlen]]

## 09 Campanha\Mestre\NPCs\NPC - Elias Moura.md

- [[NPC - Elias Moura]]

## 09 Campanha\Mestre\NPCs\NPC - Nestor Faleiro.md

- [[NPC - Nestor Faleiro]]

## 09 Campanha\Personagens prontos.md

- [[Personagens prontos]]

## 09 Campanha\Personagens\Hugo Neri - Espectador.md

- [[Hugo Neri - Espectador]]

## 09 Campanha\Personagens\Irene Vale - Vidente.md

- [[Irene Vale - Vidente]]

## 09 Campanha\Personagens\Marina Sal - Marinheira.md

- [[Marina Sal - Marinheira]]

## 10 Modelos\Modelo de Caminho.md

- [[Modelo de Caminho]]

## 10 Modelos\Modelo de NPC.md

- [[Modelo de NPC]]

## 10 Modelos\Modelo de Sequência.md

- [[Modelo de Sequência]]

## 10 Modelos\Modelo de objeto selado.md

- [[Modelo de objeto selado]]

## 10 Modelos\Modelo de personagem.md

- [[Modelo de personagem]]

## 10 Modelos\Modelo de ritual.md

- [[Modelo de ritual]]

## 10 Modelos\Modelo de sessão.md

- [[Modelo de sessão]]

## 11 Fontes e desenvolvimento\Arquitetura da adaptação.md

- [[Arquitetura da adaptação]]

## 11 Fontes e desenvolvimento\Diagnóstico das fontes.md

- [[Diagnóstico das fontes]]

## 11 Fontes e desenvolvimento\Diário de testes de mesa.md

- [[Diário de testes de mesa]]

## 11 Fontes e desenvolvimento\Estado de desenvolvimento.md

- [[Estado de desenvolvimento]]

## 11 Fontes e desenvolvimento\Exemplos da revisão 0.2.md

- [[Exemplos da revisão 0.2]]

## 11 Fontes e desenvolvimento\Fontes de Fabula Ultima.md

- [[Fontes de Fabula Ultima]]

## 11 Fontes e desenvolvimento\Fontes de Lord of Mysteries.md

- [[Fontes de Lord of Mysteries]]

## 11 Fontes e desenvolvimento\Histórico de revisões.md

- [[Histórico de revisões]]

## 11 Fontes e desenvolvimento\Limitações e pendências.md

- [[Limitações e pendências]]

## 11 Fontes e desenvolvimento\Migração para a versão 0.2.md

- [[Migração para a versão 0.2]]

## 11 Fontes e desenvolvimento\Pesquisa da revisão 0.2.md

- [[Pesquisa da revisão 0.2]]

## 11 Fontes e desenvolvimento\Registro de decisões.md

- [[Registro de decisões]]

## 11 Fontes e desenvolvimento\Relatório de verificação.md

- [[Relatório de verificação]]

## 11 Fontes e desenvolvimento\Resultados da enumeração.md

- [[Resultados da enumeração]]

## 11 Fontes e desenvolvimento\Roteiro de teste de mesa.md

- [[Roteiro de teste de mesa]]

## 11 Fontes e desenvolvimento\Validação e exemplos.md

- [[Validação e exemplos]]

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
