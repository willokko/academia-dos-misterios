---
titulo: "Sequência 8 - Assassino - Instigador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 8
nome_ingles: "Instigator"
---

# Sequência 8 - Assassino - Instigador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 8. **Nome de referência:** Instigator. Tradução editorial: Instigador.

## O que a poção transforma

O [[Poder - Assassino S8 - Centelha de discórdia|pacote completo de Instigador]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Língua instigadora.

- [[Poder - Assassino S8 - Centelha de discórdia#Incitar emoção|Incitar emoção]]
- [[Poder - Assassino S8 - Centelha de discórdia#Instigar multidão|Instigar multidão]]
- [[Poder - Assassino S8 - Centelha de discórdia#Rachar a aliança|Rachar a aliança]]



## Atuação e digestão

Interpretação original do papel **Instigador** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S8 - Instigador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Assassino - Assassino]]. Próxima: [[Sequência 7 - Assassino - Bruxa]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
