---
titulo: "Poder - Vidente S9 - Olhar para o presságio"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Vidente"
sequencia: 9
nome_pacote: "Pacote de Vidente — Vidente S9"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Vidente S9 - Olhar para o presságio

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Vidente, Vidente S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Vidente - Vidente]] ou melhor no [[Caminho do Vidente]]. **Referência nominal:** Seer. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Visão espiritual:** Ao abrir a percepção, enxerga espíritos expostos e auras vitais. Alternar foco não custa PM; examinar algo ocupa a ação. Não lê pensamentos nem identifica doenças com precisão médica.
- **Artes divinatórias:** Sabe utilizar pêndulo, cartas e sonhos com um vínculo real. Não precisa comprar uma classe de magia para isso.

## Técnicas adquiridas

### Consulta ao pêndulo

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Formule uma pergunta delimitada sobre um vínculo, objeto ou rota conhecidos. Receba uma direção ou tendência verdadeira nas condições atuais; não uma certeza sobre futuro mutável. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Sonho divinatório

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Com um vestígio pertinente e corpo protegido, obtenha uma imagem de um acontecimento ligado a ele. A imagem mostra um detalhe verificável, sem entregar toda a identidade do responsável. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Alerta espiritual

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Um ataque |
| Teste | Automático |

Declare um perigo já percebido antes da rolagem: você ou um aliado recebe +2 DEF contra esse único ataque. Não informa ameaças totalmente ocultas.

**Limites:** Uma reação de Caminho por rodada; não altera um crítico já rolado.

## Evolução e acúmulo

S8: o alerta também protege de armadilhas físicas percebidas. S7: consultas podem localizar uma chama conhecida na cena. S6: reconhece uma pessoa já estudada por dois sinais, sem anular outro disfarce automaticamente.

## Preparação e oposição

Ocultação de vínculos, identidades verificadas por relações e interrupção de preparação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Vidente]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
