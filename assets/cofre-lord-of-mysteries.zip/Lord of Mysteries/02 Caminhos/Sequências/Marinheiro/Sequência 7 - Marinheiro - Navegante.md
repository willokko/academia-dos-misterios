---
titulo: "Sequência 7 - Marinheiro - Navegante"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 7
nome_ingles: "Seafarer"
---

# Sequência 7 - Marinheiro - Navegante

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 7. **Nome de referência:** Seafarer. Tradução editorial: Navegante.

## O que a poção transforma

O [[Poder - Marinheiro S7 - Rumo contra a tempestade|pacote completo de Navegante]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Navegação sobrenatural; Ar nos pulmões.

- [[Poder - Marinheiro S7 - Rumo contra a tempestade#Rumo seguro|Rumo seguro]]
- [[Poder - Marinheiro S7 - Rumo contra a tempestade#Película de água|Película de água]]
- [[Poder - Marinheiro S7 - Rumo contra a tempestade#Água restauradora|Água restauradora]]



## Atuação e digestão

Interpretação original do papel **Navegante** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S7 - Navegante]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Marinheiro - Povo da Fúria]]. Próxima: [[Sequência 6 - Marinheiro - Abençoado pelo Vento]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
