---
titulo: "Sequência 6 - Leitor - Polímata"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 6
nome_ingles: "Polymath"
---

# Sequência 6 - Leitor - Polímata

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 6. **Nome de referência:** Polymath. Tradução editorial: Polímata.

## O que a poção transforma

O [[Poder - Leitor S6 - Imitação estudada|pacote completo de Polímata]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Arquivo de análise.

- [[Poder - Leitor S6 - Imitação estudada#Analisar modelo|Analisar modelo]]
- [[Poder - Leitor S6 - Imitação estudada#Imitar modelo|Imitar modelo]]
- [[Poder - Leitor S6 - Imitação estudada#Encontrar fundamento|Encontrar fundamento]]



## Atuação e digestão

Interpretação original do papel **Polímata** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S6 - Polímata]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Leitor - Detetive]]. Próxima: [[Sequência 5 - Leitor - Magíster do Misticismo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
