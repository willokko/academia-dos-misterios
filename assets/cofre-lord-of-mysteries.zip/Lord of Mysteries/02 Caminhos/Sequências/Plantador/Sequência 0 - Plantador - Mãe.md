---
titulo: "Sequência 0 - Plantador - Mãe"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
sequencia: 0
nome_ingles: "Mother"
---

# Sequência 0 - Plantador - Mãe

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Plantador]]. **Sequência:** 0. **Nome de referência:** Mother. Tradução editorial: Mãe.

## O que a poção transforma

O [[Poder - Plantador S0 - Autoridade de Mãe|pacote completo de Mãe]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Mãe.

- [[Poder - Plantador S0 - Autoridade de Mãe#Matriz do domínio|Matriz do domínio]]
- [[Poder - Plantador S0 - Autoridade de Mãe#Terra de abrigo|Terra de abrigo]]

Operação: [[Poder - Plantador S0 - Autoridade de Mãe#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Mãe** no tema de cultivo, medicina, vida e transformações orgânicas. Princípio de partida: cultivar condições para que outros vivam sem possuir seu futuro. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Plantador#S0 - Mãe]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Plantador - Caminhante da Natureza]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
