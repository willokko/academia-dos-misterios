---
titulo: "Sequência 5 - Monstro - Vencedor"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 5
nome_ingles: "Winner"
---

# Sequência 5 - Monstro - Vencedor

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 5. **Nome de referência:** Winner. Tradução editorial: Vencedor.

## O que a poção transforma

O [[Poder - Monstro S5 - Janela do vencedor|pacote completo de Vencedor]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Reserva de sorte.

- [[Poder - Monstro S5 - Janela do vencedor#Acumular boa fortuna|Acumular boa fortuna]]
- [[Poder - Monstro S5 - Janela do vencedor#Virada do vencedor|Virada do vencedor]]
- [[Poder - Monstro S5 - Janela do vencedor#Maldição de infortúnio|Maldição de infortúnio]]



## Atuação e digestão

Interpretação original do papel **Vencedor** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S5 - Vencedor]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Monstro - Sacerdote da Calamidade]]. Próxima: [[Sequência 4 - Monstro - Mago do Infortúnio]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
