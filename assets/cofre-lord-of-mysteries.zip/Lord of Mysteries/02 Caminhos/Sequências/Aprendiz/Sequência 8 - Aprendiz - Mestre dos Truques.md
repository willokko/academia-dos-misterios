---
titulo: "Sequência 8 - Aprendiz - Mestre dos Truques"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 8
nome_ingles: "Trickmaster"
---

# Sequência 8 - Aprendiz - Mestre dos Truques

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 8. **Nome de referência:** Trickmaster. Tradução editorial: Mestre dos Truques.

## O que a poção transforma

O [[Poder - Aprendiz S8 - Truque oportuno|pacote completo de Mestre dos Truques]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Truques menores.

- [[Poder - Aprendiz S8 - Truque oportuno#Choque de truque|Choque de truque]]
- [[Poder - Aprendiz S8 - Truque oportuno#Clarão e neblina|Clarão e neblina]]
- [[Poder - Aprendiz S8 - Truque oportuno#Gelo e vento|Gelo e vento]]



## Atuação e digestão

Interpretação original do papel **Mestre dos Truques** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S8 - Mestre dos Truques]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Aprendiz - Aprendiz]]. Próxima: [[Sequência 7 - Aprendiz - Astrólogo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
