---
titulo: "Sequência 0 - Árbitro - Justiceiro"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 0
nome_ingles: "Justiciar"
---

# Sequência 0 - Árbitro - Justiceiro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 0. **Nome de referência:** Justiciar. Tradução editorial: Justiceiro.

## O que a poção transforma

O [[Poder - Árbitro S0 - Autoridade de Justiceiro|pacote completo de Justiceiro]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Justiceiro.

- [[Poder - Árbitro S0 - Autoridade de Justiceiro#Lei do domínio|Lei do domínio]]
- [[Poder - Árbitro S0 - Autoridade de Justiceiro#Suspender exceção|Suspender exceção]]

Operação: [[Poder - Árbitro S0 - Autoridade de Justiceiro#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Justiceiro** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S0 - Justiceiro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Árbitro - Mão da Ordem]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
