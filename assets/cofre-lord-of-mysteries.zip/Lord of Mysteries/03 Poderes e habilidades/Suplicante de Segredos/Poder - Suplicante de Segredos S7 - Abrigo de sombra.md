---
titulo: "Poder - Suplicante de Segredos S7 - Abrigo de sombra"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Suplicante de Segredos"
sequencia: 7
nome_pacote: "Pacote de Asceta das Sombras — Suplicante de Segredos S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Suplicante de Segredos S7 - Abrigo de sombra

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Asceta das Sombras, Suplicante de Segredos S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Suplicante de Segredos - Asceta das Sombras]] ou melhor no [[Caminho do Suplicante de Segredos]]. **Referência nominal:** Shadow Ascetic. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Afinidade sombria:** Enxerga na escuridão ordinária e reconhece sombras utilizáveis; luz direta pode expor o esconderijo.

## Técnicas adquiridas

### Manto de sombra

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

+2 a furtividade em sombra existente. Não atravessa paredes nem apaga fios espirituais.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Gume de sombra

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+20 de dano trevas em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Sombra que prende

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica lento e a sombra retém o passo; iluminá-la ou vencê-la em Objetivo permite romper a contenção.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

## Evolução e acúmulo

S6 mistura sombra e carne; S5 solidifica sombra sem criar uma iniciativa adicional.

## Preparação e oposição

Purificação, recusa de pactos e exposição da fonte dos sussurros. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Suplicante de Segredos]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
