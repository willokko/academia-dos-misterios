---
titulo: "Poder - Boticário S7 - Vigor sanguíneo"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Boticário"
sequencia: 7
nome_pacote: "Pacote de Vampiro — Boticário S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Boticário S7 - Vigor sanguíneo

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Vampiro, Boticário S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Boticário - Vampiro]] ou melhor no [[Caminho do Boticário]]. **Referência nominal:** Vampire. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Fisiologia sanguínea:** Vê na escuridão comum e tem sentidos apurados. Sua necessidade de sangue é recurso ficcional com suprimento lícito preparado; não exige atacar pessoas para digerir.

## Técnicas adquiridas

### Asas sanguíneas

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Três rodadas ou uma travessia |
| Teste | Automático |

Voe pela cena por três rodadas ou uma travessia curta, sem gastar nova ação só para sustentar voo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Garras do sanguíneo

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Corpo a corpo |
| Duração | Instantânea |
| Teste | DES+VIG contra DEF |

Um alvo sofre RA+20 de dano físico em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Regeneração sanguínea

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Instantânea |
| Teste | Automático |

Recupere 20 PV. Uma dose de suprimento é consumida quando tratar ferida grave; não drena automaticamente PV ou PM de outra pessoa.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5 manipula luar e aprofundamento espiritual. A dieta não substitui custos de PM nem cuidados com fontes corrompidas.

## Preparação e oposição

Limitações de amostra, necessidade de consentimento e selos de invocação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Boticário]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
