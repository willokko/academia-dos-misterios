---
titulo: "Sequência 0 - Aprendiz - Porta"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 0
nome_ingles: "Door"
---

# Sequência 0 - Aprendiz - Porta

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 0. **Nome de referência:** Door. Tradução editorial: Porta.

## O que a poção transforma

O [[Poder - Aprendiz S0 - Autoridade de Porta|pacote completo de Porta]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Porta.

- [[Poder - Aprendiz S0 - Autoridade de Porta#Abrir fronteira|Abrir fronteira]]
- [[Poder - Aprendiz S0 - Autoridade de Porta#Fechar fronteira|Fechar fronteira]]

Operação: [[Poder - Aprendiz S0 - Autoridade de Porta#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Porta** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S0 - Porta]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Aprendiz - Chave das Estrelas]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
