---
titulo: "Caminho do Assassino"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
nome_divino: "Demoness"
referencia: "https://lordofthemysteries.fandom.com/wiki/Demoness_Pathway"
---

# Caminho do Assassino

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Demoness. **Tema:** Sombras, desejo, espelhos e aflição. **Função:** Infiltração, interferência e controle.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Assassino - Assassino|Assassino]] | [[Poder - Assassino S9 - Passo de emboscada|3 técnicas]] |
| 8 | [[Sequência 8 - Assassino - Instigador|Instigador]] | [[Poder - Assassino S8 - Centelha de discórdia|3 técnicas]] |
| 7 | [[Sequência 7 - Assassino - Bruxa|Bruxa]] | [[Poder - Assassino S7 - Reflexo substituto|4 técnicas]] |
| 6 | [[Sequência 6 - Assassino - Prazer|Prazer]] | [[Poder - Assassino S6 - Fio de fascínio|3 técnicas]] |
| 5 | [[Sequência 5 - Assassino - Aflição|Aflição]] | [[Poder - Assassino S5 - Aflição marcada|3 técnicas]] |
| 4 | [[Sequência 4 - Assassino - Desespero|Desespero]] | [[Poder - Assassino S4 - Autoridade de Desespero|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Assassino - Sem Idade|Sem Idade]] | [[Poder - Assassino S3 - Autoridade de Sem Idade|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Assassino - Catástrofe|Catástrofe]] | [[Poder - Assassino S2 - Autoridade de Catástrofe|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Assassino - Apocalipse|Apocalipse]] | [[Poder - Assassino S1 - Autoridade de Apocalipse|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Assassino - Demoness|Demoness]] | [[Poder - Assassino S0 - Autoridade de Demoness|2 técnicas + operação]] |

## Como jogar

Compreender o poder de uma presença sem tornar outra pessoa um objeto. As ferramentas da S9 são passo do assassino. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: consentimento e aflições. **Oposição:** Luz, espelhos preparados, distanciamento e purificação. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Assassino]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Demoness_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
