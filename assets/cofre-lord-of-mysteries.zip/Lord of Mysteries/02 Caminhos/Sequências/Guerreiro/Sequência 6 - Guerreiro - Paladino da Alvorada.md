---
titulo: "Sequência 6 - Guerreiro - Paladino da Alvorada"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
sequencia: 6
nome_ingles: "Dawn Paladin"
---

# Sequência 6 - Guerreiro - Paladino da Alvorada

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Guerreiro]]. **Sequência:** 6. **Nome de referência:** Dawn Paladin. Tradução editorial: Paladino da Alvorada.

## O que a poção transforma

O [[Poder - Guerreiro S6 - Arma da alvorada|pacote completo de Paladino da Alvorada]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Luz da alvorada.

- [[Poder - Guerreiro S6 - Arma da alvorada#Armar a alvorada|Armar a alvorada]]
- [[Poder - Guerreiro S6 - Arma da alvorada#Lâmina de luz|Lâmina de luz]]
- [[Poder - Guerreiro S6 - Arma da alvorada#Tempestade de luz|Tempestade de luz]]



## Atuação e digestão

Interpretação original do papel **Paladino da Alvorada** no tema de força, armas, proteção e declínio. Princípio de partida: escolher o que proteger e conhecer o limite da força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Guerreiro#S6 - Paladino da Alvorada]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Guerreiro - Mestre das Armas]]. Próxima: [[Sequência 5 - Guerreiro - Guardião]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
