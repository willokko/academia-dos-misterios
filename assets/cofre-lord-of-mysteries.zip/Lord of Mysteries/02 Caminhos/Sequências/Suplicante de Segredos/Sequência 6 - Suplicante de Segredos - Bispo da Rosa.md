---
titulo: "Sequência 6 - Suplicante de Segredos - Bispo da Rosa"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
sequencia: 6
nome_ingles: "Rose Bishop"
---

# Sequência 6 - Suplicante de Segredos - Bispo da Rosa

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Suplicante de Segredos]]. **Sequência:** 6. **Nome de referência:** Rose Bishop. Tradução editorial: Bispo da Rosa.

## O que a poção transforma

O [[Poder - Suplicante de Segredos S6 - Carne maleável|pacote completo de Bispo da Rosa]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Carne moldável.

- [[Poder - Suplicante de Segredos S6 - Carne maleável#Reconstruir carne|Reconstruir carne]]
- [[Poder - Suplicante de Segredos S6 - Carne maleável#Esconderijo de carne|Esconderijo de carne]]
- [[Poder - Suplicante de Segredos S6 - Carne maleável#Arma de sangue|Arma de sangue]]



## Atuação e digestão

Interpretação original do papel **Bispo da Rosa** no tema de escuta perigosa, sombras, carne e almas. Princípio de partida: buscar conhecimento sem entregar a própria responsabilidade à voz que responde. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Suplicante de Segredos#S6 - Bispo da Rosa]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Suplicante de Segredos - Asceta das Sombras]]. Próxima: [[Sequência 5 - Suplicante de Segredos - Pastor]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
