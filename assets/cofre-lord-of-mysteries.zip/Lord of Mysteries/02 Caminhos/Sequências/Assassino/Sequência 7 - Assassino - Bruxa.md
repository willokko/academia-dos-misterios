---
titulo: "Sequência 7 - Assassino - Bruxa"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 7
nome_ingles: "Witch"
---

# Sequência 7 - Assassino - Bruxa

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 7. **Nome de referência:** Witch. Tradução editorial: Bruxa.

## O que a poção transforma

O [[Poder - Assassino S7 - Reflexo substituto|pacote completo de Bruxa]] concede **2 capacidade(s) permanente(s) e 4 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação da bruxa; Repertório da bruxa.

- [[Poder - Assassino S7 - Reflexo substituto#Gelo e chama negra|Gelo e chama negra]]
- [[Poder - Assassino S7 - Reflexo substituto#Invisibilidade da bruxa|Invisibilidade da bruxa]]
- [[Poder - Assassino S7 - Reflexo substituto#Substituição no espelho|Substituição no espelho]]
- [[Poder - Assassino S7 - Reflexo substituto#Maldição por vestígio|Maldição por vestígio]]



## Atuação e digestão

Interpretação original do papel **Bruxa** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S7 - Bruxa]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Assassino - Instigador]]. Próxima: [[Sequência 6 - Assassino - Prazer]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
