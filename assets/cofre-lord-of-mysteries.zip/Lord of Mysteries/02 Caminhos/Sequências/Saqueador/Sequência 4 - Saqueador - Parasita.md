---
titulo: "Sequência 4 - Saqueador - Parasita"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 4
nome_ingles: "Parasite"
---

# Sequência 4 - Saqueador - Parasita

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 4. **Nome de referência:** Parasite. Tradução editorial: Parasita.

## O que a poção transforma

O [[Poder - Saqueador S4 - Autoridade de Parasita|pacote completo de Parasita]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Parasita.

- [[Poder - Saqueador S4 - Autoridade de Parasita#Parasitismo inicial|Parasitismo inicial]]
- [[Poder - Saqueador S4 - Autoridade de Parasita#Parasitismo profundo|Parasitismo profundo]]

Operação: [[Poder - Saqueador S4 - Autoridade de Parasita#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Parasita** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S4 - Parasita]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Saqueador - Ladrão de Sonhos]]. Próxima: [[Sequência 3 - Saqueador - Mentor do Engano]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
