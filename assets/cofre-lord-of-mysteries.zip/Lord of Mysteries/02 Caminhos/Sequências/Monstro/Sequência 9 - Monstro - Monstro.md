---
titulo: "Sequência 9 - Monstro - Monstro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 9
nome_ingles: "Monster"
---

# Sequência 9 - Monstro - Monstro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 9. **Nome de referência:** Monster. Tradução editorial: Monstro.

## O que a poção transforma

O [[Poder - Monstro S9 - Pressentir a ruptura|pacote completo de Monstro]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Espiritualidade anormal.

- [[Poder - Monstro S9 - Pressentir a ruptura#Escutar o presságio|Escutar o presságio]]
- [[Poder - Monstro S9 - Pressentir a ruptura#Desviar o olhar|Desviar o olhar]]
- [[Poder - Monstro S9 - Pressentir a ruptura#Ler a tendência|Ler a tendência]]



## Atuação e digestão

Interpretação original do papel **Monstro** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S9 - Monstro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Monstro - Robô]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
