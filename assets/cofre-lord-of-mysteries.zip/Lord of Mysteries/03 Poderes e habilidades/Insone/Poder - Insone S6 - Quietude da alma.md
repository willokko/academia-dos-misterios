---
titulo: "Poder - Insone S6 - Quietude da alma"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Insone"
sequencia: 6
nome_pacote: "Pacote de Pacificador de Almas — Insone S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Insone S6 - Quietude da alma

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Pacificador de Almas, Insone S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Insone - Pacificador de Almas]] ou melhor no [[Caminho do Insone]]. **Referência nominal:** Soul Assurer. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Sensibilidade da alma:** Pode distinguir um vínculo espiritual ferido de uma simples emoção, com um exame; a causa ainda exige investigação.

## Técnicas adquiridas

### Réquiem

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | Automático se voluntário |

Remova abalado ou atordoado de um voluntário ou acalme uma alma não hostil para conversar.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Pacificar uma possessão

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M do invasor |

Avance Separar vínculo 0/4 contra uma possessão percebida do mesmo patamar ou menor; cada contribuição exige ação e este custo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Trégua do espírito

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Você e um aliado |
| Duração | Até o próximo turno |
| Teste | Automático |

Até o próximo turno, você e um aliado têm +2 DEF.M contra influência espiritual; não é imunidade.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5 permite hospedar espíritos; réquiem não apaga impressões persistentes de uma característica.

## Preparação e oposição

Claridade preparada, alarmes independentes e recusa de isolamento. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Insone]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
