---
titulo: "Poder - Criminoso S5 - Desejo exposto"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Criminoso"
sequencia: 5
nome_pacote: "Pacote de Apóstolo do Desejo — Criminoso S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Criminoso S5 - Desejo exposto

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Apóstolo do Desejo, Criminoso S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Criminoso - Apóstolo do Desejo]] ou melhor no [[Caminho do Criminoso]]. **Referência nominal:** Desire Apostle. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Sinal do desejo:** Reconhece um desejo manifestado por gesto ou ação; não conhece todos os desejos privados de uma pessoa.

## Técnicas adquiridas

### Semente do desejo

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON contra DEF.M |

Após observar uma emoção manifesta, estabeleça vínculo e aplique abalado em sucesso. Uma semente por alvo; a causa fica investigável e dissipável.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Catalisar o desejo

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+25 de dano trevas em sucesso. Exige sua semente ativa; consumi-la acrescenta +5 ao dano, uma vez, sem outra condição.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Sombra de fuga

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND13 sob oposição |

Com desejo marcado ainda ligado a você, oculte-se em sombra presente e desloque-se para outro apoio da cena. Não concede imortalidade ou deixa outro corpo agindo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 amplia influência sobre uma comunidade; desejos são alavancas de oposição, não uma decisão secreta sobre a personalidade de PJs.

## Preparação e oposição

Intenções protegidas, ausência de hostilidade e investigação paciente. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Criminoso]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
