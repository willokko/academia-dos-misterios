---
titulo: "Sequência 2 - Monstro - Adivinho"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 2
nome_ingles: "Soothsayer"
---

# Sequência 2 - Monstro - Adivinho

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 2. **Nome de referência:** Soothsayer. Tradução editorial: Adivinho.

## O que a poção transforma

O [[Poder - Monstro S2 - Autoridade de Adivinho|pacote completo de Adivinho]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Adivinho.

- [[Poder - Monstro S2 - Autoridade de Adivinho#Presságio preciso|Presságio preciso]]
- [[Poder - Monstro S2 - Autoridade de Adivinho#Acaso extremo|Acaso extremo]]

Operação: [[Poder - Monstro S2 - Autoridade de Adivinho#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Adivinho** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S2 - Adivinho]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Monstro - Caminhante do Caos]]. Próxima: [[Sequência 1 - Monstro - Serpente de Mercúrio]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
