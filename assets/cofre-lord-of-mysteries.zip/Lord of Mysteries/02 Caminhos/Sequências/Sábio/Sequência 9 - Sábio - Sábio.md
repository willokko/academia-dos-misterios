---
titulo: "Sequência 9 - Sábio - Sábio"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 9
nome_ingles: "Savant"
---

# Sequência 9 - Sábio - Sábio

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 9. **Nome de referência:** Savant. Tradução editorial: Sábio.

## O que a poção transforma

O [[Poder - Sábio S9 - Memória de oficina|pacote completo de Sábio]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Conhecimento do sábio.

- [[Poder - Sábio S9 - Memória de oficina#Diagnóstico de mecanismo|Diagnóstico de mecanismo]]
- [[Poder - Sábio S9 - Memória de oficina#Cálculo aplicado|Cálculo aplicado]]
- [[Poder - Sábio S9 - Memória de oficina#Reparo de campo|Reparo de campo]]



## Atuação e digestão

Interpretação original do papel **Sábio** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S9 - Sábio]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Sábio - Arqueólogo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
