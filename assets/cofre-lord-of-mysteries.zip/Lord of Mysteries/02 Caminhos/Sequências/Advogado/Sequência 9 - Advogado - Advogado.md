---
titulo: "Sequência 9 - Advogado - Advogado"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
sequencia: 9
nome_ingles: "Lawyer"
---

# Sequência 9 - Advogado - Advogado

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Advogado]]. **Sequência:** 9. **Nome de referência:** Lawyer. Tradução editorial: Advogado.

## O que a poção transforma

O [[Poder - Advogado S9 - Brecha contratual|pacote completo de Advogado]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Brecha nas regras.

- [[Poder - Advogado S9 - Brecha contratual#Encontrar brecha|Encontrar brecha]]
- [[Poder - Advogado S9 - Brecha contratual#Argumento preparado|Argumento preparado]]
- [[Poder - Advogado S9 - Brecha contratual#Relação de poder|Relação de poder]]



## Atuação e digestão

Interpretação original do papel **Advogado** no tema de brechas, suborno e distorção de regras. Princípio de partida: conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Advogado#S9 - Advogado]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Advogado - Bárbaro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
