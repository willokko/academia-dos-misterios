---
titulo: "Sequência 2 - Insone - Servo da Ocultação"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 2
nome_ingles: "Servant of Concealment"
---

# Sequência 2 - Insone - Servo da Ocultação

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 2. **Nome de referência:** Servant of Concealment. Tradução editorial: Servo da Ocultação.

## O que a poção transforma

O [[Poder - Insone S2 - Autoridade de Servo da Ocultação|pacote completo de Servo da Ocultação]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Servo da Ocultação.

- [[Poder - Insone S2 - Autoridade de Servo da Ocultação#Ocultar local|Ocultar local]]
- [[Poder - Insone S2 - Autoridade de Servo da Ocultação#Passo secreto|Passo secreto]]

Operação: [[Poder - Insone S2 - Autoridade de Servo da Ocultação#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Servo da Ocultação** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S2 - Servo da Ocultação]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Insone - Bispo do Horror]]. Próxima: [[Sequência 1 - Insone - Cavaleiro do Infortúnio]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
