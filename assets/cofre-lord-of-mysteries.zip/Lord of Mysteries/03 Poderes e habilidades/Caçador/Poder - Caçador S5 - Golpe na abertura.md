---
titulo: "Poder - Caçador S5 - Golpe na abertura"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Caçador"
sequencia: 5
nome_pacote: "Pacote de Ceifador — Caçador S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Caçador S5 - Golpe na abertura

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Ceifador, Caçador S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Caçador - Ceifador]] ou melhor no [[Caminho do Caçador]]. **Referência nominal:** Reaper. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Investigação de fraqueza:** Pode examinar corpo, manifestação ou estrutura em busca de vulnerabilidade concreta; não depende apenas de órgão físico.

## Técnicas adquiridas

### Marcar a fraqueza

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Use Estudo para descobrir uma abertura ou resistência de um alvo e marcá-la até o fim da cena. Não declara fraqueza inexistente. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Colheita

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | DES+VIG contra DEF |

Um alvo sofre RA+25 de dano físico em sucesso. Se marcou uma fraqueza, ignora até 10 de redução fixa de dano. Não ignora Resistência, imunidade ou autoridade por padrão.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Precisão flamejante

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Escolha até dois alvos: faça testes separados, cada acerto causa RA+15 fogo. Pode excluir aliados da área.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 estabelece vínculo militar e partilha; não exige que todos os companheiros escolham classe marcial.

## Preparação e oposição

Terreno estudado pelo oponente, objetivos múltiplos e proteção contra fogo. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Caçador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
