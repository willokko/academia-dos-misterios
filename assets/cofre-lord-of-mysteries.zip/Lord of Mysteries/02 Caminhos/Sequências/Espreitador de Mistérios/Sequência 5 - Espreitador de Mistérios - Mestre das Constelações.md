---
titulo: "Sequência 5 - Espreitador de Mistérios - Mestre das Constelações"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
sequencia: 5
nome_ingles: "Constellations Master"
---

# Sequência 5 - Espreitador de Mistérios - Mestre das Constelações

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espreitador de Mistérios]]. **Sequência:** 5. **Nome de referência:** Constellations Master. Tradução editorial: Mestre das Constelações.

## O que a poção transforma

O [[Poder - Espreitador de Mistérios S5 - Mapa das constelações|pacote completo de Mestre das Constelações]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Leitura estelar.

- [[Poder - Espreitador de Mistérios S5 - Mapa das constelações#Ponte constelada|Ponte constelada]]
- [[Poder - Espreitador de Mistérios S5 - Mapa das constelações#Lança das constelações|Lança das constelações]]
- [[Poder - Espreitador de Mistérios S5 - Mapa das constelações#Mapa das correspondências|Mapa das correspondências]]



## Atuação e digestão

Interpretação original do papel **Mestre das Constelações** no tema de conhecimento oculto, símbolos e histórias com poder. Princípio de partida: investigar sem confundir curiosidade com direito a toda resposta. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espreitador de Mistérios#S5 - Mestre das Constelações]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Espreitador de Mistérios - Professor de Pergaminhos]]. Próxima: [[Sequência 4 - Espreitador de Mistérios - Misticólogo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
