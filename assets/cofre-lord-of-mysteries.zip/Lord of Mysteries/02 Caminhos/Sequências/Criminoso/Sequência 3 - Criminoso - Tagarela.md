---
titulo: "Sequência 3 - Criminoso - Tagarela"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 3
nome_ingles: "Blatherer"
---

# Sequência 3 - Criminoso - Tagarela

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 3. **Nome de referência:** Blatherer. Tradução editorial: Tagarela.

## O que a poção transforma

O [[Poder - Criminoso S3 - Autoridade de Tagarela|pacote completo de Tagarela]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Tagarela.

- [[Poder - Criminoso S3 - Autoridade de Tagarela#Palavra corrosiva|Palavra corrosiva]]
- [[Poder - Criminoso S3 - Autoridade de Tagarela#Vínculo da palavra|Vínculo da palavra]]

Operação: [[Poder - Criminoso S3 - Autoridade de Tagarela#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Tagarela** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S3 - Tagarela]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Criminoso - Demônio]]. Próxima: [[Sequência 2 - Criminoso - Arquiduque Sangrento]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
