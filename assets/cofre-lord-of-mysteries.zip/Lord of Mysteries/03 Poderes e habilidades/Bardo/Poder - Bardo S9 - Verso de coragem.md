---
titulo: "Poder - Bardo S9 - Verso de coragem"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Bardo"
sequencia: 9
nome_pacote: "Pacote de Bardo — Bardo S9"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Bardo S9 - Verso de coragem

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Bardo, Bardo S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Bardo - Bardo]] ou melhor no [[Caminho do Bardo]]. **Referência nominal:** Bard. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Inspiração:** Canta para transmitir coragem e coordenação. Apresentar-se é gratuito; benefícios usam as técnicas e não exigem concordância religiosa.

## Técnicas adquiridas

### Canto de coragem

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Um aliado |
| Duração | Um teste |
| Teste | Automático |

Um ouvinte recebe +2 no próximo teste de resistir a medo ou sustentar um Objetivo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Canto de vigor

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Um aliado |
| Duração | Um teste |
| Teste | Automático |

Um ouvinte recebe +2 ao próximo teste de VIG ou DES que não seja ataque.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Conhecer a assembleia

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Após cantar ou ouvir um grupo, obtenha um sinal de disposição pública e uma necessidade declarada. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S7 permite escolher dois ouvintes pelo mesmo custo; cada um conserva sua ação.

## Preparação e oposição

Obscurecimento, pactos incompatíveis e fontes superiores. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Bardo]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
