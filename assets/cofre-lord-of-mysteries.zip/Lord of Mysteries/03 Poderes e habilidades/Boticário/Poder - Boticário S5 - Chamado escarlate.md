---
titulo: "Poder - Boticário S5 - Chamado escarlate"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Boticário"
sequencia: 5
nome_pacote: "Pacote de Erudito Escarlate — Boticário S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Boticário S5 - Chamado escarlate

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Erudito Escarlate, Boticário S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Boticário - Erudito Escarlate]] ou melhor no [[Caminho do Boticário]]. **Referência nominal:** Scarlet Scholar. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Luar escarlate:** Pode produzir luar tênue e reconhecer correspondências lunares; isso não convoca a entidade associada à lua.

## Técnicas adquiridas

### Arco lunar

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+25 de dano trevas em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Abrigo escarlate

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o próximo turno |
| Teste | Automático |

Você e dois voluntários recebem +2 DEF.M contra influência espiritual até o próximo turno.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Invocação lunar

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON ND13 |

Com correspondência e nome previamente pesquisados, manifeste um espírito aliado com uma técnica S9–5 contratada. Sem contato anterior, primeiro execute um ritual. Você gasta a ação e PM para usar a técnica.

**Limites:** Um aliado mecânico ativo; ele não cria outras invocações ou características.

## Evolução e acúmulo

S4 amplia xamanismo; S2 lida com criação e transformação de vida como operação coletiva.

## Preparação e oposição

Limitações de amostra, necessidade de consentimento e selos de invocação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Boticário]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
