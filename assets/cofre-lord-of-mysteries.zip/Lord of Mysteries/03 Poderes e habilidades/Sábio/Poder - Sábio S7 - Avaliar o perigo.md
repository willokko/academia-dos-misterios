---
titulo: "Poder - Sábio S7 - Avaliar o perigo"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Sábio"
sequencia: 7
nome_pacote: "Pacote de Avaliador — Sábio S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Sábio S7 - Avaliar o perigo

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Avaliador, Sábio S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Sábio - Avaliador]] ou melhor no [[Caminho do Sábio]]. **Referência nominal:** Appraiser. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Avaliação espiritual:** Sente se um objeto exposto possui atividade espiritual; não o identifica inteiro sem exame.

## Técnicas adquiridas

### Avaliar efeito

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Examine um artefato e descubra uma função, gatilho ou defeito, à escolha. Outra pergunta exige outra pista. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Conter a ativação

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma rodada |
| Teste | AST+VON contra DEF.M do portador ou ND13 sem portador |

Com ferramenta e mecanismo exposto, suspenda um efeito de objeto S9–5 até o próximo turno. Não destrói sua característica.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Preparar o manuseio

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

Um defeito identificado concede +2 ao próximo Objetivo de selar ou transportar o objeto com contenção.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 pode fabricar e reduzir defeitos com projeto; avaliar deixou de ser apenas estudar dano.

## Preparação e oposição

Materiais escassos, falta de oficina e defeitos conhecidos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Sábio]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
