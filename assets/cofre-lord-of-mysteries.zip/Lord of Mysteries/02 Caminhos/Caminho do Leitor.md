---
titulo: "Caminho do Leitor"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
nome_divino: "Torre Branca"
referencia: "https://lordofthemysteries.fandom.com/wiki/White_Tower_Pathway"
---

# Caminho do Leitor

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Torre Branca. **Tema:** Conhecimento, dedução e reprodução por compreensão. **Função:** Investigação e preparação de contramedidas.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Leitor - Leitor|Leitor]] | [[Poder - Leitor S9 - Índice mental|3 técnicas]] |
| 8 | [[Sequência 8 - Leitor - Estudante do Raciocínio|Estudante do Raciocínio]] | [[Poder - Leitor S8 - Hipótese contrastada|3 técnicas]] |
| 7 | [[Sequência 7 - Leitor - Detetive|Detetive]] | [[Poder - Leitor S7 - Dedução de campo|3 técnicas]] |
| 6 | [[Sequência 6 - Leitor - Polímata|Polímata]] | [[Poder - Leitor S6 - Imitação estudada|3 técnicas]] |
| 5 | [[Sequência 5 - Leitor - Magíster do Misticismo|Magíster do Misticismo]] | [[Poder - Leitor S5 - Contrapadrão|3 técnicas]] |
| 4 | [[Sequência 4 - Leitor - Profeta|Profeta]] | [[Poder - Leitor S4 - Autoridade de Profeta|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Leitor - Conhecedor|Conhecedor]] | [[Poder - Leitor S3 - Autoridade de Conhecedor|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Leitor - Anjo da Sabedoria|Anjo da Sabedoria]] | [[Poder - Leitor S2 - Autoridade de Anjo da Sabedoria|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Leitor - Olho Onisciente|Olho Onisciente]] | [[Poder - Leitor S1 - Autoridade de Olho Onisciente|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Leitor - Torre Branca|Torre Branca]] | [[Poder - Leitor S0 - Autoridade de Torre Branca|2 técnicas + operação]] |

## Como jogar

Testar uma hipótese e admitir o que os dados ainda não sustentam. As ferramentas da S9 são memória ampliada. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: cópia e onisciência limitada. **Oposição:** Informação falsa, fenômenos novos e acesso negado a evidências. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Leitor]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/White_Tower_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
