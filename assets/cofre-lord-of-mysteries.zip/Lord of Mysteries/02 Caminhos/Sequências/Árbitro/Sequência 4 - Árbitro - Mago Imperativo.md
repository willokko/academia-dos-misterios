---
titulo: "Sequência 4 - Árbitro - Mago Imperativo"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 4
nome_ingles: "Imperative Mage"
---

# Sequência 4 - Árbitro - Mago Imperativo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 4. **Nome de referência:** Imperative Mage. Tradução editorial: Mago Imperativo.

## O que a poção transforma

O [[Poder - Árbitro S4 - Autoridade de Mago Imperativo|pacote completo de Mago Imperativo]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Mago Imperativo.

- [[Poder - Árbitro S4 - Autoridade de Mago Imperativo#Decreto imperativo|Decreto imperativo]]
- [[Poder - Árbitro S4 - Autoridade de Mago Imperativo#Privar técnica|Privar técnica]]

Operação: [[Poder - Árbitro S4 - Autoridade de Mago Imperativo#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Mago Imperativo** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S4 - Mago Imperativo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Árbitro - Paladino Disciplinar]]. Próxima: [[Sequência 3 - Árbitro - Caçador do Caos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
