---
titulo: "Sequência 9 - Espectador - Espectador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 9
nome_ingles: "Spectator"
---

# Sequência 9 - Espectador - Espectador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 9. **Nome de referência:** Spectator. Tradução editorial: Espectador.

## O que a poção transforma

O [[Poder - Espectador S9 - Leitura da plateia|pacote completo de Espectador]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Atenção da plateia; Memória de detalhes.

- [[Poder - Espectador S9 - Leitura da plateia#Ler emoção|Ler emoção]]
- [[Poder - Espectador S9 - Leitura da plateia#Mapear a plateia|Mapear a plateia]]
- [[Poder - Espectador S9 - Leitura da plateia#Preparar a abordagem|Preparar a abordagem]]



## Atuação e digestão

Interpretação original do papel **Espectador** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S9 - Espectador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Espectador - Telepata]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
