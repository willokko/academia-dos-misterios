---
titulo: "Sequência 2 - Saqueador - Cavalo de Troia do Destino"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 2
nome_ingles: "Trojan Horse of Destiny"
---

# Sequência 2 - Saqueador - Cavalo de Troia do Destino

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 2. **Nome de referência:** Trojan Horse of Destiny. Tradução editorial: Cavalo de Troia do Destino.

## O que a poção transforma

O [[Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino|pacote completo de Cavalo de Troia do Destino]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Cavalo de Troia do Destino.

- [[Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino#Identidade usurpada|Identidade usurpada]]
- [[Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino#Roubar conexão|Roubar conexão]]

Operação: [[Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Cavalo de Troia do Destino** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S2 - Cavalo de Troia do Destino]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Saqueador - Mentor do Engano]]. Próxima: [[Sequência 1 - Saqueador - Verme do Tempo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
