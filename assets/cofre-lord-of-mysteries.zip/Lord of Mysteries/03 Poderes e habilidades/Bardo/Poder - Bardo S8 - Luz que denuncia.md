---
titulo: "Poder - Bardo S8 - Luz que denuncia"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Bardo"
sequencia: 8
nome_pacote: "Pacote de Suplicante da Luz — Bardo S8"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Bardo S8 - Luz que denuncia

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Suplicante da Luz, Bardo S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Bardo - Suplicante da Luz]] ou melhor no [[Caminho do Bardo]]. **Referência nominal:** Light Suppliant. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Luz portátil:** Pode emitir luz ordinária; ela não revela culpa ou dissipa automaticamente ocultação.

## Técnicas adquiridas

### Raio solar

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+15 de dano luz em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Água solar

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até o próximo descanso |
| Teste | AST+VON ND10 ao preparar; contra DEF.M ao liberar |

Consagre uma dose: na mesma jornada, uma ação a libera contra espírito ou morto-vivo, causando RA+15 de luz se atingir DEF.M. PM são pagos só ao preparar.

**Limites:** Uma dose preparada por vez; usa seus atributos na liberação.

### Foco luminoso

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | Automático |

Ilumine um recinto: +2 ao próximo Objetivo para examinar um vestígio sombrio exposto.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S7 reforça consagração; não purifica qualquer corrupção pelo nome.

## Preparação e oposição

Obscurecimento, pactos incompatíveis e fontes superiores. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Bardo]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
