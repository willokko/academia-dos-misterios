---
titulo: "Sequência 4 - Aprendiz - Feiticeiro dos Segredos"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 4
nome_ingles: "Secrets Sorcerer"
---

# Sequência 4 - Aprendiz - Feiticeiro dos Segredos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 4. **Nome de referência:** Secrets Sorcerer. Tradução editorial: Feiticeiro dos Segredos.

## O que a poção transforma

O [[Poder - Aprendiz S4 - Autoridade de Feiticeiro dos Segredos|pacote completo de Feiticeiro dos Segredos]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Feiticeiro dos Segredos.

- [[Poder - Aprendiz S4 - Autoridade de Feiticeiro dos Segredos#Recinto oculto|Recinto oculto]]
- [[Poder - Aprendiz S4 - Autoridade de Feiticeiro dos Segredos#Exílio breve|Exílio breve]]

Operação: [[Poder - Aprendiz S4 - Autoridade de Feiticeiro dos Segredos#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Feiticeiro dos Segredos** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S4 - Feiticeiro dos Segredos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Aprendiz - Viajante]]. Próxima: [[Sequência 3 - Aprendiz - Andarilho]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
