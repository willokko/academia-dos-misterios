---
titulo: "Poder - Suplicante de Segredos S6 - Carne maleável"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Suplicante de Segredos"
sequencia: 6
nome_pacote: "Pacote de Bispo da Rosa — Suplicante de Segredos S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Suplicante de Segredos S6 - Carne maleável

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Bispo da Rosa, Suplicante de Segredos S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Suplicante de Segredos - Bispo da Rosa]] ou melhor no [[Caminho do Suplicante de Segredos]]. **Referência nominal:** Rose Bishop. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Carne moldável:** Controla tecido próprio e esconde objetos pequenos; não é imunidade a dano ou recurso de ressurreição.

## Técnicas adquiridas

### Reconstruir carne

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Instantânea |
| Teste | Automático |

Recupere 20 PV próprios; não recupera característica destruída nem revive morto.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Esconderijo de carne

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON ND13 sob escrutínio |

Prepare cavidade num corpo inerte grande para esconder-se ou esconder um objeto. Sair não causa dano automático.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Arma de sangue

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | VIG+VON contra DEF |

Um alvo sofre RA+20 de dano físico em sucesso. A arma é seu próprio tecido, não um item vendável.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5 amplia o repertório por almas reais; moldar carne não concede documentos ou memórias.

## Preparação e oposição

Purificação, recusa de pactos e exposição da fonte dos sussurros. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Suplicante de Segredos]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
