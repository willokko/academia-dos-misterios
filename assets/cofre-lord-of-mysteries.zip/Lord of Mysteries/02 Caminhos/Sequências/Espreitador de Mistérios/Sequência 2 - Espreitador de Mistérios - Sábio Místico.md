---
titulo: "Sequência 2 - Espreitador de Mistérios - Sábio Místico"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
sequencia: 2
nome_ingles: "Sage"
---

# Sequência 2 - Espreitador de Mistérios - Sábio Místico

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espreitador de Mistérios]]. **Sequência:** 2. **Nome de referência:** Sage. Tradução editorial: Sábio Místico.

## O que a poção transforma

O [[Poder - Espreitador de Mistérios S2 - Autoridade de Sábio Místico|pacote completo de Sábio Místico]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Sábio Místico.

- [[Poder - Espreitador de Mistérios S2 - Autoridade de Sábio Místico#Fluxo de saber|Fluxo de saber]]
- [[Poder - Espreitador de Mistérios S2 - Autoridade de Sábio Místico#Revelação protegida|Revelação protegida]]

Operação: [[Poder - Espreitador de Mistérios S2 - Autoridade de Sábio Místico#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Sábio Místico** no tema de conhecimento oculto, símbolos e histórias com poder. Princípio de partida: investigar sem confundir curiosidade com direito a toda resposta. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espreitador de Mistérios#S2 - Sábio Místico]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Espreitador de Mistérios - Clarividente]]. Próxima: [[Sequência 1 - Espreitador de Mistérios - Imperador do Conhecimento]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
