---
titulo: "Sequência 7 - Aprendiz - Astrólogo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 7
nome_ingles: "Astrologer"
---

# Sequência 7 - Aprendiz - Astrólogo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 7. **Nome de referência:** Astrologer. Tradução editorial: Astrólogo.

## O que a poção transforma

O [[Poder - Aprendiz S7 - Carta celeste|pacote completo de Astrólogo]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Astrologia.

- [[Poder - Aprendiz S7 - Carta celeste#Carta de caminho|Carta de caminho]]
- [[Poder - Aprendiz S7 - Carta celeste#Localização simbólica|Localização simbólica]]
- [[Poder - Aprendiz S7 - Carta celeste#Interferência astral|Interferência astral]]



## Atuação e digestão

Interpretação original do papel **Astrólogo** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S7 - Astrólogo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Aprendiz - Mestre dos Truques]]. Próxima: [[Sequência 6 - Aprendiz - Escriba]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
