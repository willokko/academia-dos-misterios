---
titulo: "Sequência 9 - Vidente - Vidente"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 9
nome_ingles: "Seer"
---

# Sequência 9 - Vidente - Vidente

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 9. **Nome de referência:** Seer. Tradução editorial: Vidente.

## O que a poção transforma

O [[Poder - Vidente S9 - Olhar para o presságio|pacote completo de Vidente]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Visão espiritual; Artes divinatórias.

- [[Poder - Vidente S9 - Olhar para o presságio#Consulta ao pêndulo|Consulta ao pêndulo]]
- [[Poder - Vidente S9 - Olhar para o presságio#Sonho divinatório|Sonho divinatório]]
- [[Poder - Vidente S9 - Olhar para o presságio#Alerta espiritual|Alerta espiritual]]



## Atuação e digestão

Interpretação original do papel **Vidente** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S9 - Vidente]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Vidente - Palhaço]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
