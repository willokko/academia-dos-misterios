---
titulo: "Sequência 8 - Plantador - Médico"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
sequencia: 8
nome_ingles: "Doctor"
---

# Sequência 8 - Plantador - Médico

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Plantador]]. **Sequência:** 8. **Nome de referência:** Doctor. Tradução editorial: Médico.

## O que a poção transforma

O [[Poder - Plantador S8 - Cuidados de campo|pacote completo de Médico]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Visão de saúde.

- [[Poder - Plantador S8 - Cuidados de campo#Tratamento|Tratamento]]
- [[Poder - Plantador S8 - Cuidados de campo#Remover debilidade|Remover debilidade]]
- [[Poder - Plantador S8 - Cuidados de campo#Cirurgia guiada|Cirurgia guiada]]



## Atuação e digestão

Interpretação original do papel **Médico** no tema de cultivo, medicina, vida e transformações orgânicas. Princípio de partida: cultivar condições para que outros vivam sem possuir seu futuro. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Plantador#S8 - Médico]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Plantador - Plantador]]. Próxima: [[Sequência 7 - Plantador - Sacerdote da Colheita]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
