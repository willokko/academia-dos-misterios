---
titulo: "Sequência 2 - Assassino - Catástrofe"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 2
nome_ingles: "Catastrophe"
---

# Sequência 2 - Assassino - Catástrofe

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 2. **Nome de referência:** Catastrophe. Tradução editorial: Catástrofe.

## O que a poção transforma

O [[Poder - Assassino S2 - Autoridade de Catástrofe|pacote completo de Catástrofe]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Catástrofe.

- [[Poder - Assassino S2 - Autoridade de Catástrofe#Catástrofe escolhida|Catástrofe escolhida]]
- [[Poder - Assassino S2 - Autoridade de Catástrofe#Espelhos de calamidade|Espelhos de calamidade]]

Operação: [[Poder - Assassino S2 - Autoridade de Catástrofe#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Catástrofe** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S2 - Catástrofe]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Assassino - Sem Idade]]. Próxima: [[Sequência 1 - Assassino - Apocalipse]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
