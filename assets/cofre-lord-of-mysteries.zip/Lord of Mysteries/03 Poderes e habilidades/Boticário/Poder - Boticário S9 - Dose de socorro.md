---
titulo: "Poder - Boticário S9 - Dose de socorro"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Boticário"
sequencia: 9
nome_pacote: "Pacote de Boticário — Boticário S9"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Boticário S9 - Dose de socorro

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Boticário, Boticário S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Boticário - Boticário]] ou melhor no [[Caminho do Boticário]]. **Referência nominal:** Apothecary. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Farmacopeia:** Reconhece ervas e sintomas ordinários com acesso à amostra; não aprende fórmulas de avanço por provar substâncias.

## Técnicas adquiridas

### Diagnóstico da amostra

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Determine se uma amostra é curativa, tóxica ou espiritualmente ativa, e um cuidado de manuseio. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Preparar remédio

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até o próximo descanso |
| Teste | AST+AST ND10 |

Com ingredientes comuns de 25 zênites, prepare duas doses por descanso: cada uma restaura 20 PV quando alguém usa uma ação para tomá-la. PM pagos ao preparar; não produz poção de avanço.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Neutralizar toxina

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Toque |
| Duração | Instantânea |
| Teste | Automático se a fonte foi identificada |

Toque um voluntário e remova envenenado se a fonte for veneno ordinário identificado; não trata corrupção ou doença desconhecida.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 amplia a oficina para misturas sobrenaturais. Remédios não são características nem moedas de cura ilimitada.

## Preparação e oposição

Limitações de amostra, necessidade de consentimento e selos de invocação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Boticário]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
