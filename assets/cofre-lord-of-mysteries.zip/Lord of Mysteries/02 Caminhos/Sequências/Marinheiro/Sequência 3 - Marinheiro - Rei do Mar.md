---
titulo: "Sequência 3 - Marinheiro - Rei do Mar"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 3
nome_ingles: "Sea King"
---

# Sequência 3 - Marinheiro - Rei do Mar

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 3. **Nome de referência:** Sea King. Tradução editorial: Rei do Mar.

## O que a poção transforma

O [[Poder - Marinheiro S3 - Autoridade de Rei do Mar|pacote completo de Rei do Mar]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Rei do Mar.

- [[Poder - Marinheiro S3 - Autoridade de Rei do Mar#Comando da maré|Comando da maré]]
- [[Poder - Marinheiro S3 - Autoridade de Rei do Mar#Corpo de tempestade|Corpo de tempestade]]

Operação: [[Poder - Marinheiro S3 - Autoridade de Rei do Mar#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Rei do Mar** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S3 - Rei do Mar]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Marinheiro - Sepultador de Cataclismos]]. Próxima: [[Sequência 2 - Marinheiro - Calamidade]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
