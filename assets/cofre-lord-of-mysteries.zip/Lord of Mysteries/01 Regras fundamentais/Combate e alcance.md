---
titulo: "Combate e alcance"
tipo: "regras-fundamentais"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Combate e alcance

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

## Núcleo oficial resumido

Use iniciativa e alternância entre os lados conforme o básico, pp. 60–65. Cada turno tem uma ação principal; ações menores não permitem embutir outro teste. Ataque testa a Precisão da arma contra DEF; feitiço ofensivo testa Magia contra DEF.M. Dano usa a RA quando a ficha disser. Vulnerabilidade dobra dano; Resistência reduz à metade; Imunidade zera; Absorção recupera PV. Aplique arredondamento do livro.

Guarda fornece Resistência a dano e +2 nos testes opostos até o próximo turno, podendo cobrir um aliado contra ataques corpo a corpo. Impedimento usa ND 10 e aplica uma entre abalado, atordoado, fraco ou lento. Estudo obtém informação; Objetivo avança a resolução do conflito. Consulte o básico pp. 66–73 e [[Condições]]. Não esqueça essas ações quando um poder não for apropriado.

## Convenções adicionadas

As fichas de Caminho usam a ação **Poder**, mesmo quando a ficção parece feitiço. Seus efeitos não recebem benefícios exclusivos de feitiços de classe, nem ataques livres, salvo autorização expressa. Ainda são mágicos e podem ser dissipados quando a ficha permitir.

| Alcance | Definição de mesa |
|---|---|
| Pessoal | Somente o usuário |
| Toque | Alvo fisicamente acessível; hostil exige o teste indicado |
| Cena | Alvo percebido no conflito ou situação atual; exige linha de efeito |
| Vínculo | Amostra, objeto pessoal ou local conhecido; só onde a ficha o permitir |

Não há distância universal em metros. Portas fechadas, ocultação e separação ficcional importam. Voar pode permitir alcançar lugares, mas não concede imunidade geral a ataques; crie uma rota para oposição e cooperação. Cobertura, escuridão ou posição especialmente favorável podem gerar ±2 situacional pelo básico, sem pilhas arbitrárias de bônus.

Efeitos de poder com duração `até o próximo turno` terminam no início do próximo turno do usuário. `Até o fim do próximo turno do alvo` usa o turno do alvo. Efeitos de cena terminam também ao perder consciência, a menos que a ficha declare o contrário.

Se alguém chega a 0 PV, siga [[Derrota e sacrifício]], sem substituir a escolha oficial por morte automática de horror.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
