---
titulo: "Sequência 5 - Aprendiz - Viajante"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 5
nome_ingles: "Traveler"
---

# Sequência 5 - Aprendiz - Viajante

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 5. **Nome de referência:** Traveler. Tradução editorial: Viajante.

## O que a poção transforma

O [[Poder - Aprendiz S5 - Travessia conhecida|pacote completo de Viajante]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Sentido do viajante.

- [[Poder - Aprendiz S5 - Travessia conhecida#Viagem espiritual|Viagem espiritual]]
- [[Poder - Aprendiz S5 - Travessia conhecida#Porta em conflito|Porta em conflito]]
- [[Poder - Aprendiz S5 - Travessia conhecida#Saída elevada|Saída elevada]]



## Atuação e digestão

Interpretação original do papel **Viajante** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S5 - Viajante]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Aprendiz - Escriba]]. Próxima: [[Sequência 4 - Aprendiz - Feiticeiro dos Segredos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
