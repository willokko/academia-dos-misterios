---
titulo: "Poder - Bardo S7 - Bênção de vigília"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Bardo"
sequencia: 7
nome_pacote: "Pacote de Sumo Sacerdote Solar — Bardo S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Bardo S7 - Bênção de vigília

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Sumo Sacerdote Solar, Bardo S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Bardo - Sumo Sacerdote Solar]] ou melhor no [[Caminho do Bardo]]. **Referência nominal:** Solar High Priest. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Ofício solar:** Conhece correspondências para cerimônias e insígnias de luz; liturgia não torna contato divino seguro.

## Técnicas adquiridas

### Bênção de luz

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Um aliado |
| Duração | Até o próximo turno |
| Teste | Automático |

Um aliado recebe +2 DEF.M até seu próximo turno.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Chama purificadora

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M do criador |

Encerre um efeito de sombra ou possessão S9–7 percebido. Graus maiores exigem rito e brecha.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Círculo consagrado

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Um recinto |
| Duração | Uma cena |
| Teste | Automático |

Espíritos hostis de patamar igual ou menor precisam vencer AST+VON contra sua DEF.M para entrar num recinto marcado; uma tentativa por turno.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5 permite purificar efeitos S6–5. Corrupção persistente continua exigindo tratamento e remoção da fonte.

## Preparação e oposição

Obscurecimento, pactos incompatíveis e fontes superiores. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Bardo]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
