---
titulo: "Sequência 2 - Leitor - Anjo da Sabedoria"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 2
nome_ingles: "Wisdom Angel"
---

# Sequência 2 - Leitor - Anjo da Sabedoria

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 2. **Nome de referência:** Wisdom Angel. Tradução editorial: Anjo da Sabedoria.

## O que a poção transforma

O [[Poder - Leitor S2 - Autoridade de Anjo da Sabedoria|pacote completo de Anjo da Sabedoria]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Anjo da Sabedoria.

- [[Poder - Leitor S2 - Autoridade de Anjo da Sabedoria#Fórmula angelical|Fórmula angelical]]
- [[Poder - Leitor S2 - Autoridade de Anjo da Sabedoria#Análise de autoridade|Análise de autoridade]]

Operação: [[Poder - Leitor S2 - Autoridade de Anjo da Sabedoria#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Anjo da Sabedoria** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S2 - Anjo da Sabedoria]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Leitor - Conhecedor]]. Próxima: [[Sequência 1 - Leitor - Olho Onisciente]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
