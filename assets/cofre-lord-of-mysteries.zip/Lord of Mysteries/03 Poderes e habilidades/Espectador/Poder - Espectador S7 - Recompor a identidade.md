---
titulo: "Poder - Espectador S7 - Recompor a identidade"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espectador"
sequencia: 7
nome_pacote: "Pacote de Psiquiatra — Espectador S7"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Espectador S7 - Recompor a identidade

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Psiquiatra, Espectador S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Espectador - Psiquiatra]] ou melhor no [[Caminho do Espectador]]. **Referência nominal:** Psychiatrist. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Conhecer o limite:** Distingue influência mental sobrenatural evidente de sofrimento cuja origem ainda precisa investigar; não produz diagnóstico clínico real.
- **Pessoa antes do papel:** Uma conversa aceita pode abrir uma pista sobre o motivo de um comportamento, sem determinar o que o interlocutor deve sentir.

## Técnicas adquiridas

### Pacificar

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | Automático |

Remova abalado ou atordoado de um voluntário na cena.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Apoio à identidade

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 |

Numa crise de perda de controle, avance Recuperar identidade pelas margens normais e uma seção adicional em sucesso. Não baixa Corrupção persistente.

**Limites:** Uma vez por crise por usuário.

### Choque de assombro

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica abalado e o medo revela uma imagem ligada ao que o alvo teme; o mestre fornece um sinal, sem entregar segredo inteiro.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

## Evolução e acúmulo

S6 permite armar escamas defensivas e hipnose. Pacificar continua sendo ação e não transforma Corrupção permanente em condição curável.

## Preparação e oposição

Máscaras sociais treinadas, registros materiais e sujeitos sem mente acessível. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espectador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
