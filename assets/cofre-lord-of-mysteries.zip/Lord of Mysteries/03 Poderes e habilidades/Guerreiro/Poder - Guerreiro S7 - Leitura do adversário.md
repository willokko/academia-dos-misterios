---
titulo: "Poder - Guerreiro S7 - Leitura do adversário"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Guerreiro"
sequencia: 7
nome_pacote: "Pacote de Mestre das Armas — Guerreiro S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Guerreiro S7 - Leitura do adversário

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Mestre das Armas, Guerreiro S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Guerreiro - Mestre das Armas]] ou melhor no [[Caminho do Guerreiro]]. **Referência nominal:** Weapon Master. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Domínio das armas:** Pode equipar armas marciais mesmo sem benefício de classe; não ganha habilidades de classe ou ataques extras.

## Técnicas adquiridas

### Leitura do armamento

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Próximo ataque |
| Teste | AST+VIG ND10 |

Após Estudo, descubra um modo de guarda e sua abertura; +2 ao próximo ataque contra esse alvo, não ao dano.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Arremesso preciso

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | DES+VIG contra DEF |

Um alvo sofre RA+15 de dano físico em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Desarmar por técnica

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | DES+VIG oposto à DES+VIG |

Abra Desarmar 0/4; ao completar, um item empunhado cai ao alcance do alvo. Não destrói artefato nem extrai característica.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 torna armas luminosas capazes de ferir espíritos sem equipamento externo.

## Preparação e oposição

Riscos que exigem informação, ataques indiretos e múltiplos objetivos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Guerreiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
