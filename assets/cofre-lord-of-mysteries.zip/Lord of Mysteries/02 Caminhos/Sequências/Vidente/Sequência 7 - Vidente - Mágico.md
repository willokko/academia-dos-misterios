---
titulo: "Sequência 7 - Vidente - Mágico"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 7
nome_ingles: "Magician"
---

# Sequência 7 - Vidente - Mágico

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 7. **Nome de referência:** Magician. Tradução editorial: Mágico.

## O que a poção transforma

O [[Poder - Vidente S7 - Truques do palco velado|pacote completo de Mágico]] concede **2 capacidade(s) permanente(s) e 6 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Repertório do mágico; Respiração por tubo.

- [[Poder - Vidente S7 - Truques do palco velado#Bala de ar|Bala de ar]]
- [[Poder - Vidente S7 - Truques do palco velado#Salto flamejante|Salto flamejante]]
- [[Poder - Vidente S7 - Truques do palco velado#Substituto de papel|Substituto de papel]]
- [[Poder - Vidente S7 - Truques do palco velado#Ilusão sensorial|Ilusão sensorial]]
- [[Poder - Vidente S7 - Truques do palco velado#Transferir ferimento|Transferir ferimento]]
- [[Poder - Vidente S7 - Truques do palco velado#Domínio das chamas|Domínio das chamas]]



## Atuação e digestão

Interpretação original do papel **Mágico** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S7 - Mágico]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Vidente - Palhaço]]. Próxima: [[Sequência 6 - Vidente - Sem Rosto]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
