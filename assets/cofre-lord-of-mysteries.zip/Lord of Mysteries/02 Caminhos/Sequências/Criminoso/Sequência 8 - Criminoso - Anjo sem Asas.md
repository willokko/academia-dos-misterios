---
titulo: "Sequência 8 - Criminoso - Anjo sem Asas"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 8
nome_ingles: "Unwinged Angel"
---

# Sequência 8 - Criminoso - Anjo sem Asas

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 8. **Nome de referência:** Unwinged Angel. Tradução editorial: Anjo sem Asas.

## O que a poção transforma

O [[Poder - Criminoso S8 - Frieza calculada|pacote completo de Anjo sem Asas]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Corpo sem asas.

- [[Poder - Criminoso S8 - Frieza calculada#Preparar o corpo|Preparar o corpo]]
- [[Poder - Criminoso S8 - Frieza calculada#Força impiedosa|Força impiedosa]]
- [[Poder - Criminoso S8 - Frieza calculada#Ler hesitação|Ler hesitação]]



## Atuação e digestão

Interpretação original do papel **Anjo sem Asas** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S8 - Anjo sem Asas]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Criminoso - Criminoso]]. Próxima: [[Sequência 7 - Criminoso - Assassino em Série]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
