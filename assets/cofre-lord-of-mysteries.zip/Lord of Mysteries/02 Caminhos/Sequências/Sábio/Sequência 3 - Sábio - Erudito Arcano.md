---
titulo: "Sequência 3 - Sábio - Erudito Arcano"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 3
nome_ingles: "Arcane Scholar"
---

# Sequência 3 - Sábio - Erudito Arcano

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 3. **Nome de referência:** Arcane Scholar. Tradução editorial: Erudito Arcano.

## O que a poção transforma

O [[Poder - Sábio S3 - Autoridade de Erudito Arcano|pacote completo de Erudito Arcano]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Erudito Arcano.

- [[Poder - Sábio S3 - Autoridade de Erudito Arcano#Engenho arcano|Engenho arcano]]
- [[Poder - Sábio S3 - Autoridade de Erudito Arcano#Reparo arcano|Reparo arcano]]

Operação: [[Poder - Sábio S3 - Autoridade de Erudito Arcano#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Erudito Arcano** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S3 - Erudito Arcano]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Sábio - Alquimista]]. Próxima: [[Sequência 2 - Sábio - Magíster do Conhecimento]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
