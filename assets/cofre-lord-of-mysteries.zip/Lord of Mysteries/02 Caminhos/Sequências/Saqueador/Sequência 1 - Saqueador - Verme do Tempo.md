---
titulo: "Sequência 1 - Saqueador - Verme do Tempo"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 1
nome_ingles: "Worm of Time"
---

# Sequência 1 - Saqueador - Verme do Tempo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 1. **Nome de referência:** Worm of Time. Tradução editorial: Verme do Tempo.

## O que a poção transforma

O [[Poder - Saqueador S1 - Autoridade de Verme do Tempo|pacote completo de Verme do Tempo]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Verme do Tempo.

- [[Poder - Saqueador S1 - Autoridade de Verme do Tempo#Subtrair duração|Subtrair duração]]
- [[Poder - Saqueador S1 - Autoridade de Verme do Tempo#Tempo emprestado|Tempo emprestado]]

Operação: [[Poder - Saqueador S1 - Autoridade de Verme do Tempo#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Verme do Tempo** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S1 - Verme do Tempo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Saqueador - Cavalo de Troia do Destino]]. Próxima: [[Sequência 0 - Saqueador - Erro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
