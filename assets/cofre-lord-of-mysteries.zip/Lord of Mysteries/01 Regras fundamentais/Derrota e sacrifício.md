---
titulo: "Derrota e sacrifício"
tipo: "regras-fundamentais"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Derrota e sacrifício

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

> [!info] Regra oficial resumida
> Ao chegar a 0 PV, PJs escolhem rendição ou sacrifício conforme o básico, pp. 85–89. Derrota de NPC não precisa significar morte. Os detalhes e consequências devem seguir essas regras, sem impor execução automática.

> [!example] Uso na adaptação
> Rendição pode significar captura por uma igreja, perda da maleta ou isolamento em um selo. Sacrifício pode deixar uma [[Características Beyonder|característica]], mas sua existência nunca deve incentivar outros PJs a matar o personagem para obter poder.

Se um NPC morrer de fato, o mestre decide como sua característica precipita e qual impressão persiste. Mantenha uma unidade rastreável; fragmentos não criam cópias consumíveis. Derrotar sem matar pode preservar pistas, resgatar um hospedeiro e ganhar apoio político.

Perda de controle total de um PJ ocorre somente pelo procedimento de [[Perda de controle]], com oportunidade de intervenção. Corrupção não elimina a escolha de rendição ou sacrifício ao atingir 0 PV.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
