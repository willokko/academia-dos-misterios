---
titulo: "Poder - Guerreiro S5 - Bastião de um nome"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Guerreiro"
sequencia: 5
nome_pacote: "Pacote de Guardião — Guerreiro S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Guerreiro S5 - Bastião de um nome

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Guardião, Guerreiro S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Guerreiro - Guardião]] ou melhor no [[Caminho do Guerreiro]]. **Referência nominal:** Guardian. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Robustez do guardião:** A redução física da armadura de alvorada passa a 10 enquanto ela estiver manifesta; substitui 5, não soma.

## Técnicas adquiridas

### Muralha de proteção

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o próximo turno |
| Teste | Automático |

Você e até dois aliados recebem Resistência a dano até o início do próximo turno. Não pode atacar durante a manutenção; manter exige nova ação e 10 PM.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Interpor-se

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Um ataque |
| Teste | Automático |

Antes do dano em aliado próximo, torne-se alvo daquele dano, usando suas próprias afinidades. Não copia a Guarda de outra pessoa nem reduz o dano novamente por esta reação.

**Limites:** Uma reação de Caminho por rodada.

### Força dos gigantes

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Corpo a corpo |
| Duração | Instantânea |
| Teste | VIG+VIG contra DEF |

Um alvo sofre RA+25 de dano físico em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 adiciona caça a entidades e preparos; S3 transforma a proteção em corpo e luz de escala superior.

## Preparação e oposição

Riscos que exigem informação, ataques indiretos e múltiplos objetivos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Guerreiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
