---
titulo: "Sequência 4 - Marinheiro - Sepultador de Cataclismos"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 4
nome_ingles: "Cataclysmic Interrer"
---

# Sequência 4 - Marinheiro - Sepultador de Cataclismos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 4. **Nome de referência:** Cataclysmic Interrer. Tradução editorial: Sepultador de Cataclismos.

## O que a poção transforma

O [[Poder - Marinheiro S4 - Autoridade de Sepultador de Cataclismos|pacote completo de Sepultador de Cataclismos]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Sepultador de Cataclismos.

- [[Poder - Marinheiro S4 - Autoridade de Sepultador de Cataclismos#Recolher a calamidade|Recolher a calamidade]]
- [[Poder - Marinheiro S4 - Autoridade de Sepultador de Cataclismos#Tormenta dirigida|Tormenta dirigida]]

Operação: [[Poder - Marinheiro S4 - Autoridade de Sepultador de Cataclismos#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Sepultador de Cataclismos** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S4 - Sepultador de Cataclismos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Marinheiro - Cantor do Oceano]]. Próxima: [[Sequência 3 - Marinheiro - Rei do Mar]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
