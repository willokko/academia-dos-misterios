---
titulo: "Sequência 6 - Insone - Pacificador de Almas"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 6
nome_ingles: "Soul Assurer"
---

# Sequência 6 - Insone - Pacificador de Almas

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 6. **Nome de referência:** Soul Assurer. Tradução editorial: Pacificador de Almas.

## O que a poção transforma

O [[Poder - Insone S6 - Quietude da alma|pacote completo de Pacificador de Almas]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Sensibilidade da alma.

- [[Poder - Insone S6 - Quietude da alma#Réquiem|Réquiem]]
- [[Poder - Insone S6 - Quietude da alma#Pacificar uma possessão|Pacificar uma possessão]]
- [[Poder - Insone S6 - Quietude da alma#Trégua do espírito|Trégua do espírito]]



## Atuação e digestão

Interpretação original do papel **Pacificador de Almas** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S6 - Pacificador de Almas]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Insone - Pesadelo]]. Próxima: [[Sequência 5 - Insone - Feiticeiro dos Espíritos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
