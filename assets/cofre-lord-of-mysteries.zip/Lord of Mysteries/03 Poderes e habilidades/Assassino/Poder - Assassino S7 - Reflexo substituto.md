---
titulo: "Poder - Assassino S7 - Reflexo substituto"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Assassino"
sequencia: 7
nome_pacote: "Pacote de Bruxa — Assassino S7"
quantidade_tecnicas: 4
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Assassino S7 - Reflexo substituto

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Bruxa, Assassino S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Assassino - Bruxa]] ou melhor no [[Caminho do Assassino]]. **Referência nominal:** Witch. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Transformação da bruxa:** O pacote envolve transformação corporal feminina na referência do cenário. Identidade e apresentação do PJ são discutidas com seu jogador; a variante de mesa pode ajustar a transformação sem bônus ou punição.
- **Repertório da bruxa:** Pequenos efeitos de gelo, chama negra e espelho são possíveis; vantagem mecânica usa uma técnica.

## Técnicas adquiridas

### Gelo e chama negra

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+20 de dano gelo em sucesso. Escolha gelo ou trevas ao ativar; nunca os dois danos juntos.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Invisibilidade da bruxa

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

Oculte o corpo da visão comum até atacar ou produzir interferência direta. Pegadas, odor, toque e percepção adequada continuam possíveis; observador alertado testa AST+VON oposto.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Substituição no espelho

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Um golpe |
| Teste | Automático |

Com um espelho preparado ao alcance, reduza em 15 um dano que ia sofrer e reapareça junto dele. O espelho se quebra.

**Limites:** Uma reação por rodada; dois espelhos preparados por descanso. Não apaga ferida já resolvida.

### Maldição por vestígio

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON contra DEF.M |

Com cabelo, sangue ou reflexo completo válido, ataque espiritual aplica abalado ou fraco. Se só conhece o nome, precisa primeiro obter um vínculo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 amplia fios e proteção; S5 usa reflexos como cenário e traz doenças sobrenaturais.

## Preparação e oposição

Luz, espelhos preparados, distanciamento e purificação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Assassino]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
