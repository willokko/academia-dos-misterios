---
titulo: "Sequência 2 - Sábio - Magíster do Conhecimento"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 2
nome_ingles: "Knowledge Magister"
---

# Sequência 2 - Sábio - Magíster do Conhecimento

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 2. **Nome de referência:** Knowledge Magister. Tradução editorial: Magíster do Conhecimento.

## O que a poção transforma

O [[Poder - Sábio S2 - Autoridade de Magíster do Conhecimento|pacote completo de Magíster do Conhecimento]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Magíster do Conhecimento.

- [[Poder - Sábio S2 - Autoridade de Magíster do Conhecimento#Rede de conhecimento|Rede de conhecimento]]
- [[Poder - Sábio S2 - Autoridade de Magíster do Conhecimento#Matéria e informação|Matéria e informação]]

Operação: [[Poder - Sábio S2 - Autoridade de Magíster do Conhecimento#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Magíster do Conhecimento** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S2 - Magíster do Conhecimento]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Sábio - Erudito Arcano]]. Próxima: [[Sequência 1 - Sábio - Iluminador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
