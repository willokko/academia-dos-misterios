---
titulo: "Poder - Sábio S9 - Memória de oficina"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Sábio"
sequencia: 9
nome_pacote: "Pacote de Sábio — Sábio S9"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Sábio S9 - Memória de oficina

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Sábio, Sábio S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Sábio - Sábio]] ou melhor no [[Caminho do Sábio]]. **Referência nominal:** Savant. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Conhecimento do sábio:** Memória técnica de ciências estudadas e +2 a pesquisa científica com fonte ou aparelho pertinente. Não conhece toda tecnologia futura.

## Técnicas adquiridas

### Diagnóstico de mecanismo

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Identifique uma peça avariada e uma forma de testá-la, sem consertar gratuitamente. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Cálculo aplicado

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

+2 ao próximo Objetivo de construir, medir ou desmontar objeto ordinário com ferramentas.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Reparo de campo

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+AST ND10 |

Recupere uma função pequena de equipamento ordinário quebrado por uma cena. Exige peças disponíveis, sem restaurar artefato ou gerar dinheiro.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 é a virada para fabricação sobrenatural; não se presume que Inventor substitui uma característica Beyonder.

## Preparação e oposição

Materiais escassos, falta de oficina e defeitos conhecidos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Sábio]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
