---
titulo: "Poder - Espectador S6 - Sugestão de um gesto"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espectador"
sequencia: 6
nome_pacote: "Pacote de Hipnotizador — Espectador S6"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Espectador S6 - Sugestão de um gesto

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Hipnotizador, Espectador S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Espectador - Hipnotizador]] ou melhor no [[Caminho do Espectador]]. **Referência nominal:** Hypnotist. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Escamas dracônicas:** Pode manifestar escamas perceptíveis: reduzem em 5 o dano físico final, sem acumular outra redução passiva de Caminho. Ocultá-las suspende a proteção.
- **Foco de hipnose:** Reconhece um gatilho mental que implantou; não adquire acesso permanente a pensamentos.

## Técnicas adquiridas

### Hipnose preparada

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Até o próximo descanso |
| Teste | AST+VON contra DEF.M |

Após conversar por um minuto sem hostilidade aberta, implante um gesto ou palavra como gatilho. NPC pode cumprir uma ordem simples que não contrarie sua identidade. Com oposição ou ordem grave, exige Dominação 0/6 com ações e novos testes; veja Controle mental e agência.

**Limites:** Um gatilho por alvo; dano ou contradição forte permite resistir novamente. Não determina sentimentos de jogadores.

### Invisibilidade psicológica

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON contra DEF.M |

Um alvo passa a ignorar sua presença na consciência, mesmo com visão espiritual comum. Ataque, contato direto ou aviso de aliado encerra. Contra um grupo, pague 5 PM adicionais por alvo, até três.

**Limites:** Não apaga registros, pegadas ou observação de alvos não afetados.

### Sugestão em conflito

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica atordoado e o alvo escolhe abandonar o gesto anunciado ou sofrer -2 naquele teste; ainda conserva uma ação válida.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

## Evolução e acúmulo

A hipnose agora possui procedimento persistente fora de conflito. Na S5 pode ser trabalhada dentro do sonho, sem dispensar evidências, custo ou resistência.

## Preparação e oposição

Máscaras sociais treinadas, registros materiais e sujeitos sem mente acessível. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espectador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
