---
titulo: "Sequência 7 - Sábio - Avaliador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 7
nome_ingles: "Appraiser"
---

# Sequência 7 - Sábio - Avaliador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 7. **Nome de referência:** Appraiser. Tradução editorial: Avaliador.

## O que a poção transforma

O [[Poder - Sábio S7 - Avaliar o perigo|pacote completo de Avaliador]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Avaliação espiritual.

- [[Poder - Sábio S7 - Avaliar o perigo#Avaliar efeito|Avaliar efeito]]
- [[Poder - Sábio S7 - Avaliar o perigo#Conter a ativação|Conter a ativação]]
- [[Poder - Sábio S7 - Avaliar o perigo#Preparar o manuseio|Preparar o manuseio]]



## Atuação e digestão

Interpretação original do papel **Avaliador** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S7 - Avaliador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Sábio - Arqueólogo]]. Próxima: [[Sequência 6 - Sábio - Artesão]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
