---
titulo: "Poder - Árbitro S5 - Sanção disciplinar"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Árbitro"
sequencia: 5
nome_pacote: "Pacote de Paladino Disciplinar — Árbitro S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Árbitro S5 - Sanção disciplinar

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Paladino Disciplinar, Árbitro S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Árbitro - Paladino Disciplinar]] ou melhor no [[Caminho do Árbitro]]. **Referência nominal:** Disciplinary Paladin. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Majestade disciplinar:** A presença pode ser tornada evidente a todos na cena. Não equivale a controle mental sem teste.

## Técnicas adquiridas

### Execução de veredito

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Atingido por uma infração concreta que observou nesta cena, um alvo sofre RA+25 luz em sucesso. Não mata por pronunciar a palavra morte.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Decreto de trégua

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o próximo turno |
| Teste | AST+VON contra DEF.M |

Uma categoria hostil concreta fica proibida até seu próximo turno, como tiros através de uma passagem. Até dois alvos resistem separadamente. Não impede todas as formas de ação.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Proteção disciplinar

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Um aliado |
| Duração | Um golpe |
| Teste | Automático |

Um aliado sofre -10 no próximo dano vindo de ação que viola sua regra ativa. Não acumula outra redução de Caminho sobre o mesmo golpe.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 cria decretos de alcance maior; S2 trata equilíbrio entre forças por operações, sem tornar todos os PJs iguais em toda estatística.

## Preparação e oposição

Jurisdição ausente, regra simétrica e quebra de evidências. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Árbitro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
