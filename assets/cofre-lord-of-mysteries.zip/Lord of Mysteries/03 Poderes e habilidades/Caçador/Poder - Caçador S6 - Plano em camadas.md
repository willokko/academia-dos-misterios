---
titulo: "Poder - Caçador S6 - Plano em camadas"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Caçador"
sequencia: 6
nome_pacote: "Pacote de Conspirador — Caçador S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Caçador S6 - Plano em camadas

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Conspirador, Caçador S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Caçador - Conspirador]] ou melhor no [[Caminho do Caçador]]. **Referência nominal:** Conspirer. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Mente do conspirador:** +2 para planejar usando duas informações verificadas e um recurso real. Não estabelece preparos desconhecidos de graça.

## Técnicas adquiridas

### Conspiração preparada

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+AST ND13 |

Declare uma isca e resposta plausíveis. Após ação de preparo e teste, quando a condição ocorrer, dê +2 ao próximo Objetivo de um aliado relacionado ao plano.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Corpo na chama

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10; ND13 sob oposição |

Una-se a uma arma ou projétil de fogo seu e termine onde ele chegar, até dez metros na cena. A ação desloca ou causa dano, escolha um; não duplica os dois efeitos.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Desorientar o plano

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica atordoado e o alvo perde a clareza de uma ordem ou isca que você apresentou.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

## Evolução e acúmulo

S5 amplia percurso flamejante para pontos desimpedidos na cena; conhecer a fraqueza torna-se requisito de colheita plena.

## Preparação e oposição

Terreno estudado pelo oponente, objetivos múltiplos e proteção contra fogo. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Caçador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
