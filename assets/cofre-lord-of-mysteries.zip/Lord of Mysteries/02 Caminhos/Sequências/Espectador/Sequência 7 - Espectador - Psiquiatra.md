---
titulo: "Sequência 7 - Espectador - Psiquiatra"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 7
nome_ingles: "Psychiatrist"
---

# Sequência 7 - Espectador - Psiquiatra

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 7. **Nome de referência:** Psychiatrist. Tradução editorial: Psiquiatra.

## O que a poção transforma

O [[Poder - Espectador S7 - Recompor a identidade|pacote completo de Psiquiatra]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Conhecer o limite; Pessoa antes do papel.

- [[Poder - Espectador S7 - Recompor a identidade#Pacificar|Pacificar]]
- [[Poder - Espectador S7 - Recompor a identidade#Apoio à identidade|Apoio à identidade]]
- [[Poder - Espectador S7 - Recompor a identidade#Choque de assombro|Choque de assombro]]



## Atuação e digestão

Interpretação original do papel **Psiquiatra** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S7 - Psiquiatra]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Espectador - Telepata]]. Próxima: [[Sequência 6 - Espectador - Hipnotizador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
