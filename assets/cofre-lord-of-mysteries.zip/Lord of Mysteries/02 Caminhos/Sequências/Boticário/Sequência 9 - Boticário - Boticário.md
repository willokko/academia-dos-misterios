---
titulo: "Sequência 9 - Boticário - Boticário"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 9
nome_ingles: "Apothecary"
---

# Sequência 9 - Boticário - Boticário

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 9. **Nome de referência:** Apothecary. Tradução editorial: Boticário.

## O que a poção transforma

O [[Poder - Boticário S9 - Dose de socorro|pacote completo de Boticário]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Farmacopeia.

- [[Poder - Boticário S9 - Dose de socorro#Diagnóstico da amostra|Diagnóstico da amostra]]
- [[Poder - Boticário S9 - Dose de socorro#Preparar remédio|Preparar remédio]]
- [[Poder - Boticário S9 - Dose de socorro#Neutralizar toxina|Neutralizar toxina]]



## Atuação e digestão

Interpretação original do papel **Boticário** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S9 - Boticário]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Boticário - Domador de Bestas]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
