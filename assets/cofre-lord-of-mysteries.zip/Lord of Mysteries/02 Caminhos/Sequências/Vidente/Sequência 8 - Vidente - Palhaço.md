---
titulo: "Sequência 8 - Vidente - Palhaço"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 8
nome_ingles: "Clown"
---

# Sequência 8 - Vidente - Palhaço

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 8. **Nome de referência:** Clown. Tradução editorial: Palhaço.

## O que a poção transforma

O [[Poder - Vidente S8 - Equilíbrio do palhaço|pacote completo de Palhaço]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Corpo do palhaço; Expressão escolhida.

- [[Poder - Vidente S8 - Equilíbrio do palhaço#Esquiva intuitiva|Esquiva intuitiva]]
- [[Poder - Vidente S8 - Equilíbrio do palhaço#Lâmina de papel|Lâmina de papel]]
- [[Poder - Vidente S8 - Equilíbrio do palhaço#Contorção e saída|Contorção e saída]]



## Atuação e digestão

Interpretação original do papel **Palhaço** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S8 - Palhaço]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Vidente - Vidente]]. Próxima: [[Sequência 7 - Vidente - Mágico]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
