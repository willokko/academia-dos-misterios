---
titulo: "Caminho do Espectador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
nome_divino: "Visionário"
referencia: "https://lordofthemysteries.fandom.com/wiki/Visionary_Pathway"
---

# Caminho do Espectador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Visionário. **Tema:** Observação, emoções, sonhos e construção mental. **Função:** Interação, investigação e sustentação do grupo.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Espectador - Espectador|Espectador]] | [[Poder - Espectador S9 - Leitura da plateia|3 técnicas]] |
| 8 | [[Sequência 8 - Espectador - Telepata|Telepata]] | [[Poder - Espectador S8 - Eco de pensamento|3 técnicas]] |
| 7 | [[Sequência 7 - Espectador - Psiquiatra|Psiquiatra]] | [[Poder - Espectador S7 - Recompor a identidade|3 técnicas]] |
| 6 | [[Sequência 6 - Espectador - Hipnotizador|Hipnotizador]] | [[Poder - Espectador S6 - Sugestão de um gesto|3 técnicas]] |
| 5 | [[Sequência 5 - Espectador - Caminhante dos Sonhos|Caminhante dos Sonhos]] | [[Poder - Espectador S5 - Passo no sonho|3 técnicas]] |
| 4 | [[Sequência 4 - Espectador - Manipulador|Manipulador]] | [[Poder - Espectador S4 - Autoridade de Manipulador|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Espectador - Tecelão de Sonhos|Tecelão de Sonhos]] | [[Poder - Espectador S3 - Autoridade de Tecelão de Sonhos|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Espectador - Discernidor|Discernidor]] | [[Poder - Espectador S2 - Autoridade de Discernidor|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Espectador - Autor|Autor]] | [[Poder - Espectador S1 - Autoridade de Autor|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Espectador - Visionário|Visionário]] | [[Poder - Espectador S0 - Autoridade de Visionário|2 técnicas + operação]] |

## Como jogar

Observar padrões, ajudar sem reduzir uma pessoa a um papel. As ferramentas da S9 são atenção da plateia, memória de detalhes. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: agência e informação privada. **Oposição:** Máscaras sociais treinadas, registros materiais e sujeitos sem mente acessível. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Espectador]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Visionary_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
