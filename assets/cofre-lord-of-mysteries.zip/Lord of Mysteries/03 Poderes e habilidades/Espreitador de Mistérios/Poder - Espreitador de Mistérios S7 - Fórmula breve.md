---
titulo: "Poder - Espreitador de Mistérios S7 - Fórmula breve"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espreitador de Mistérios"
sequencia: 7
nome_pacote: "Pacote de Bruxo — Espreitador de Mistérios S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Espreitador de Mistérios S7 - Fórmula breve

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Bruxo, Espreitador de Mistérios S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Espreitador de Mistérios - Bruxo]] ou melhor no [[Caminho do Espreitador de Mistérios]]. **Referência nominal:** Warlock. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Feitiçaria:** Conhece três fórmulas editoriais abaixo. As correspondências podem mudar a aparência, sem gerar novos efeitos fora da ficha.

## Técnicas adquiridas

### Raio do bruxo

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+20 de dano raio em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Selo de perturbação

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica atordoado e um símbolo luminoso interfere na concentração do alvo.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

### Barreira escrita

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Você ou um voluntário |
| Duração | Um golpe |
| Teste | Automático |

Reduza em 10 o próximo dano espiritual que você ou um voluntário sofra nesta cena.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 permite preparar e entregar esses efeitos como pergaminhos, sem apagar custos materiais.

## Preparação e oposição

Informação falsa, falta de correspondência e revelação vedada. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espreitador de Mistérios]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
