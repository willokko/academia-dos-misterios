---
titulo: "Poder - Assassino S5 - Aflição marcada"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Assassino"
sequencia: 5
nome_pacote: "Pacote de Aflição — Assassino S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Assassino S5 - Aflição marcada

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Aflição, Assassino S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Assassino - Aflição]] ou melhor no [[Caminho do Assassino]]. **Referência nominal:** Affliction. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Afinidade com aflição:** Pode distinguir sintomas de sua própria doença sobrenatural e interromper sua emissão; não conhece todas as doenças reais.

## Técnicas adquiridas

### Aflição

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON contra DEF.M |

Marque um alvo que respire o ar da cena: em sucesso fica envenenado. Uma ação posterior e 10 PM agrava para RA+15 de veneno, com novo teste. Não causa morte passiva ou pandemia fora da ficha.

**Limites:** Mortos sem fisiologia não são alvo desta versão; calor, purificação ou cura pertinente podem romper a fonte.

### Cena de espelhos

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON ND13 ou oposição |

Com dois reflexos preparados, distorça um percurso pequeno. Abra Fuga 0/4 para quem quiser romper a cena; não atravessa um mundo inteiro nem prende uma cidade.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Maldição refletida

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+25 de dano trevas em sucesso. Exige reflexo percebido ou vestígio; aplica dano uma vez, sem duplicar por vários espelhos.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 estende aflição a fenômenos espirituais; a escalada de horror depende do módulo, sem multiplicação automática de dano.

## Preparação e oposição

Luz, espelhos preparados, distanciamento e purificação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Assassino]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
