---
titulo: "Sequência 3 - Prisioneiro - Discípulo do Silêncio"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 3
nome_ingles: "Disciple of Silence"
---

# Sequência 3 - Prisioneiro - Discípulo do Silêncio

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 3. **Nome de referência:** Disciple of Silence. Tradução editorial: Discípulo do Silêncio.

## O que a poção transforma

O [[Poder - Prisioneiro S3 - Autoridade de Discípulo do Silêncio|pacote completo de Discípulo do Silêncio]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Discípulo do Silêncio.

- [[Poder - Prisioneiro S3 - Autoridade de Discípulo do Silêncio#Silêncio imposto|Silêncio imposto]]
- [[Poder - Prisioneiro S3 - Autoridade de Discípulo do Silêncio#Recolher desejo|Recolher desejo]]

Operação: [[Poder - Prisioneiro S3 - Autoridade de Discípulo do Silêncio#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Discípulo do Silêncio** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S3 - Discípulo do Silêncio]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Prisioneiro - Marionete]]. Próxima: [[Sequência 2 - Prisioneiro - Flagelo Antigo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
