---
titulo: "Poder - Suplicante de Segredos S8 - Escuta vedada"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Suplicante de Segredos"
sequencia: 8
nome_pacote: "Pacote de Ouvinte — Suplicante de Segredos S8"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Suplicante de Segredos S8 - Escuta vedada

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Ouvinte, Suplicante de Segredos S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Suplicante de Segredos - Ouvinte]] ou melhor no [[Caminho do Suplicante de Segredos]]. **Referência nominal:** Listener. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Audição do oculto:** Pode abrir percepção aos murmúrios de presenças vinculadas. Contato vedado exige aviso, escolha e proteção.

## Técnicas adquiridas

### Escutar vínculo

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Receba uma frase ou impressão da fonte de um vestígio e um sinal de resposta inteligente, sem compromisso de veracidade do interlocutor. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Fechar a escuta

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

+2 para resistir a influência transmitida por murmúrio durante a cena; suspende sua escuta enquanto protegido.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Voz intrusa

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica atordoado e um ruído espiritual distrai a mente; não invoca uma entidade verdadeira.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

## Evolução e acúmulo

S7 permite ouvir enquanto se esconde em sombras; a fonte nunca é um catálogo sem risco.

## Preparação e oposição

Purificação, recusa de pactos e exposição da fonte dos sussurros. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Suplicante de Segredos]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
