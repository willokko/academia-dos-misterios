---
titulo: "Sequência 4 - Leitor - Profeta"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 4
nome_ingles: "Prophet"
---

# Sequência 4 - Leitor - Profeta

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 4. **Nome de referência:** Prophet. Tradução editorial: Profeta.

## O que a poção transforma

O [[Poder - Leitor S4 - Autoridade de Profeta|pacote completo de Profeta]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Profeta.

- [[Poder - Leitor S4 - Autoridade de Profeta#Profecia contextual|Profecia contextual]]
- [[Poder - Leitor S4 - Autoridade de Profeta#Arte de interdição|Arte de interdição]]

Operação: [[Poder - Leitor S4 - Autoridade de Profeta#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Profeta** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S4 - Profeta]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Leitor - Magíster do Misticismo]]. Próxima: [[Sequência 3 - Leitor - Conhecedor]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
