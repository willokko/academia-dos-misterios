---
titulo: "Poder - Leitor S6 - Imitação estudada"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Leitor"
sequencia: 6
nome_pacote: "Pacote de Polímata — Leitor S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Leitor S6 - Imitação estudada

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Polímata, Leitor S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Leitor - Polímata]] ou melhor no [[Caminho do Leitor]]. **Referência nominal:** Polymath. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Arquivo de análise:** Aprende até três modelos de técnicas S9–5 analisadas. Guarda modelos, não cargas consumíveis. Preparar novos modelos exige observação, dez minutos e 10 PM por modelo.

## Técnicas adquiridas

### Analisar modelo

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até substituir |
| Teste | AST+AST conforme grau |

Após observar e compreender uma técnica elegível, aprenda o modelo, substituindo um espaço se necessário. ND10 para S7–9, ND13 para S5–6.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Imitar modelo

| Parâmetro | Regra |
|---|---|
| Custo | Custo original +5 PM |
| Ação | Conforme técnica |
| Alcance | Cena |
| Duração | Conforme técnica |
| Teste | Conforme técnica |

Use um modelo preparado: pague PM originais +5, com sua ação e atributos. Dano ou cura usa fórmula original menos 5; outros efeitos conservam duração e limites.

**Limites:** Sem passivos, cópia, roubo, autoridades ou técnicas que criem poderes. Não apaga o poder da fonte.

### Encontrar fundamento

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Uma técnica analisada revela uma correspondência material para pesquisar um novo modelo; não o aprende gratuitamente. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S5: seis modelos conhecidos, quatro preparados; preparar no intervalo custa dez minutos por troca. Diferencia imitação repetível de registros consumíveis do Escriba.

## Preparação e oposição

Informação falsa, fenômenos novos e acesso negado a evidências. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Leitor]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
