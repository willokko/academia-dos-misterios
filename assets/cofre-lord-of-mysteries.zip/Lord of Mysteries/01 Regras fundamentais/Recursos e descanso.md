---
titulo: "Recursos e descanso"
tipo: "regras-fundamentais"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Recursos e descanso

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

> [!info] Livro básico, pp. 84–91, 163–165
> Antes dos benefícios de classe: PV máximos = nível + 5 × tamanho do dado básico de VIG; PM máximos = nível + 5 × tamanho do dado básico de VON; PI máximos = 6. Crise = metade dos PV máximos, arredondada para baixo. DEF = tamanho atual de DES; DEF.M = tamanho atual de AST, modificadas por equipamento. Iniciativa começa em 0 antes de ajustes.

Espiritualidade usa **PM**. Não existe uma segunda reserva de mana. PI representam consumíveis comuns, jamais características, fórmulas ou poções de avanço. Zênites são a unidade contábil: nomes de moedas de Loen são apenas cor local; não foi estabelecida conversão com libras do romance.

Descanso segue o básico: em geral quatro a seis horas de inatividade com abrigo seguro, hospitalidade ou hospedagem. Recupera todos os PV/PM e remove condições; não recupera PI gratuitamente. Ao fim da cena, cada PJ pode criar um Laço, acrescentar uma emoção a um Laço existente ou trocar uma de suas emoções, conforme pp. 90–91. Corrupção e Digestão usam [[Tratamento e recuperação]] e [[Digestão e atuação]]; não são preenchidas ou apagadas por recuperar PM. Uma refeição rápida não renova limites de poder definidos por cena.

Limites `uma vez por cena` contam entre todas as cópias, objetos e invocações sob controle do usuário. O mestre encerra uma cena quando mudam seus riscos e objetivos, não quando o grupo pede uma nova tentativa.

[[Características Beyonder]] trata propriedade de materiais persistentes. [[Fórmulas e ingredientes]] impede converter PI em avanço gratuito.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
