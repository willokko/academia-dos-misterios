---
titulo: "Sequência 8 - Advogado - Bárbaro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
sequencia: 8
nome_ingles: "Barbarian"
---

# Sequência 8 - Advogado - Bárbaro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Advogado]]. **Sequência:** 8. **Nome de referência:** Barbarian. Tradução editorial: Bárbaro.

## O que a poção transforma

O [[Poder - Advogado S8 - Autoridade da força|pacote completo de Bárbaro]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Corpo do bárbaro.

- [[Poder - Advogado S8 - Autoridade da força#Força bárbara|Força bárbara]]
- [[Poder - Advogado S8 - Autoridade da força#Intimidação por demonstração|Intimidação por demonstração]]
- [[Poder - Advogado S8 - Autoridade da força#Avanço obstinado|Avanço obstinado]]



## Atuação e digestão

Interpretação original do papel **Bárbaro** no tema de brechas, suborno e distorção de regras. Princípio de partida: conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Advogado#S8 - Bárbaro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Advogado - Advogado]]. Próxima: [[Sequência 7 - Advogado - Subornador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
