---
titulo: "Criação de personagens"
tipo: "regras-fundamentais"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Criação de personagens

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

## Criar uma pessoa e sua poção

1. Combine época, cidade, relações do grupo, spoilers e tom de horror em [[Contrato de campanha]]. A campanha pronta usa uma doca fictícia de Loen.
2. Crie Identidade, Tema e Origem. Escolha perfil oficial de atributos: d10/d10/d6/d6, d10/d8/d8/d6 ou quatro d8. Atributos vão de d6 a d12.
3. Escolha um dos [[Índice dos 22 Caminhos|22 Caminhos]] e sua S9. Recebe **todas** as capacidades e técnicas do pacote inicial. A poção e fórmula de entrada são antecedentes, sem teste de morte antes de jogar.
4. Distribua cinco níveis em duas ou três classes, respeitando [[Classes e identidade sobrenatural]]. O Caminho define o acesso sobrenatural; classes fornecem treinamento e especialização. Não escolha primeiro magia de outro domínio para depois justificar com uma poção que não a oferece.
5. Calcule [[Recursos e descanso|recursos e defesas]], adicionando benefícios iniciais de cada classe uma vez. A poção não concede PV/PM ocultos; suas transformações são as escritas na ficha.
6. Compre equipamento com 500 zênites; some 2d6 × 10 e a sobra ao dinheiro carregado. Comece com 3 Pontos de Fabula e 6 PI, salvo benefício oficial expresso.
7. Anote Digestão 0/6, Corrupção 0/6, duas pessoas importantes, princípio de atuação e lembrança que distingue pessoa e papel. Registre Laços pelo procedimento oficial, sem bônus por apenas escrever um nome.
8. Na folha, separe capacidades permanentes, técnicas e reação de Caminho. Registre fonte de cada habilidade de classe impossível. [[Modelo de personagem]] inclui esses campos.

## Oficial e adaptação

Perfis, níveis iniciais, benefícios de classe, equipamento, Fabula e PI resumem o básico, pp. 160–165. Acesso por Caminho, poção inicial e relógios são regras originais. Não se compra um novo ponto por cada técnica da poção: o pacote é adquirido inteiro.

Um investigador pode usar arma e uma Marinheira pode negociar. A fonte sobrenatural não limita profissões, personalidade ou treinamento. Vidente S9 não ganha luz e regeneração só por escolher Espiritualista; Espectador S9 não lê pensamento antes da S8. [[Personagens prontos]] aplica a arquitetura nova. Retreine fichas anteriores por [[Migração para a versão 0.2]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
