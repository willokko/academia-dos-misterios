---
titulo: "Caminho do Suplicante de Segredos"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
nome_divino: "Enforcado"
referencia: "https://lordofthemysteries.fandom.com/wiki/Hanged_Man_Pathway"
---

# Caminho do Suplicante de Segredos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Enforcado. **Tema:** Escuta perigosa, sombras, carne e almas. **Função:** Ocultismo, infiltração e versatilidade arriscada.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Suplicante de Segredos - Suplicante de Segredos|Suplicante de Segredos]] | [[Poder - Suplicante de Segredos S9 - Súplica delimitada|3 técnicas]] |
| 8 | [[Sequência 8 - Suplicante de Segredos - Ouvinte|Ouvinte]] | [[Poder - Suplicante de Segredos S8 - Escuta vedada|3 técnicas]] |
| 7 | [[Sequência 7 - Suplicante de Segredos - Asceta das Sombras|Asceta das Sombras]] | [[Poder - Suplicante de Segredos S7 - Abrigo de sombra|3 técnicas]] |
| 6 | [[Sequência 6 - Suplicante de Segredos - Bispo da Rosa|Bispo da Rosa]] | [[Poder - Suplicante de Segredos S6 - Carne maleável|3 técnicas]] |
| 5 | [[Sequência 5 - Suplicante de Segredos - Pastor|Pastor]] | [[Poder - Suplicante de Segredos S5 - Pastoreio de eco|3 técnicas]] |
| 4 | [[Sequência 4 - Suplicante de Segredos - Cavaleiro Negro|Cavaleiro Negro]] | [[Poder - Suplicante de Segredos S4 - Autoridade de Cavaleiro Negro|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Suplicante de Segredos - Templário da Trindade|Templário da Trindade]] | [[Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Suplicante de Segredos - Presbítero Profano|Presbítero Profano]] | [[Poder - Suplicante de Segredos S2 - Autoridade de Presbítero Profano|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Suplicante de Segredos - Anjo Sombrio|Anjo Sombrio]] | [[Poder - Suplicante de Segredos S1 - Autoridade de Anjo Sombrio|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Suplicante de Segredos - Enforcado|Enforcado]] | [[Poder - Suplicante de Segredos S0 - Autoridade de Enforcado|2 técnicas + operação]] |

## Como jogar

Buscar conhecimento sem entregar a própria responsabilidade à voz que responde. As ferramentas da S9 são misticismo inquietante. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Muito alta: almas e contatos. **Oposição:** Purificação, recusa de pactos e exposição da fonte dos sussurros. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Suplicante de Segredos]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Hanged_Man_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
