---
titulo: "Poder - Assassino S9 - Passo de emboscada"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Assassino"
sequencia: 9
nome_pacote: "Pacote de Assassino — Assassino S9"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Assassino S9 - Passo de emboscada

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Assassino, Assassino S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Assassino - Assassino]] ou melhor no [[Caminho do Assassino]]. **Referência nominal:** Assassin. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Passo do assassino:** +2 para furtividade e acrobacia em rota real; queda curta de até um andar não causa dano se houver ponto de aterrissagem livre. Não é invisibilidade.

## Técnicas adquiridas

### Preparar emboscada

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Próximo ataque |
| Teste | Automático |

Após esconder-se com sucesso, seu próximo ataque contra alvo que ainda ignore sua posição recebe +5 dano. Não gera ataque adicional.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Queda da pena

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | DES+VIG ND10 sob oposição |

Desça silenciosamente de até dez metros com apoio ou trajetória livre; pode alcançar ponto inacessível a uma escalada comum.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Estudar a presa

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Observe um alvo para descobrir um padrão de deslocamento e um local onde pode interceptá-lo. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S7 concede magia e ocultação; treinamento S9 não atravessa paredes ou registro visual.

## Preparação e oposição

Luz, espelhos preparados, distanciamento e purificação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Assassino]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
