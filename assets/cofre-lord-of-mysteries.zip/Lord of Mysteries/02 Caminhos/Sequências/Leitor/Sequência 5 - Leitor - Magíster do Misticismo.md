---
titulo: "Sequência 5 - Leitor - Magíster do Misticismo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 5
nome_ingles: "Mysticism Magister"
---

# Sequência 5 - Leitor - Magíster do Misticismo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 5. **Nome de referência:** Mysticism Magister. Tradução editorial: Magíster do Misticismo.

## O que a poção transforma

O [[Poder - Leitor S5 - Contrapadrão|pacote completo de Magíster do Misticismo]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Oficina de artes místicas.

- [[Poder - Leitor S5 - Contrapadrão#Raio de análise|Raio de análise]]
- [[Poder - Leitor S5 - Contrapadrão#Selo de método|Selo de método]]
- [[Poder - Leitor S5 - Contrapadrão#Artifício de resguardo|Artifício de resguardo]]



## Atuação e digestão

Interpretação original do papel **Magíster do Misticismo** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S5 - Magíster do Misticismo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Leitor - Polímata]]. Próxima: [[Sequência 4 - Leitor - Profeta]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
