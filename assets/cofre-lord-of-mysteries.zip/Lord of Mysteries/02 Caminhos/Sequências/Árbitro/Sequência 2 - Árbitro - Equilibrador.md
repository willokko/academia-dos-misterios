---
titulo: "Sequência 2 - Árbitro - Equilibrador"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 2
nome_ingles: "Balancer"
---

# Sequência 2 - Árbitro - Equilibrador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 2. **Nome de referência:** Balancer. Tradução editorial: Equilibrador.

## O que a poção transforma

O [[Poder - Árbitro S2 - Autoridade de Equilibrador|pacote completo de Equilibrador]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Equilibrador.

- [[Poder - Árbitro S2 - Autoridade de Equilibrador#Equilibrar campo|Equilibrar campo]]
- [[Poder - Árbitro S2 - Autoridade de Equilibrador#Regra de contrapeso|Regra de contrapeso]]

Operação: [[Poder - Árbitro S2 - Autoridade de Equilibrador#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Equilibrador** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S2 - Equilibrador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Árbitro - Caçador do Caos]]. Próxima: [[Sequência 1 - Árbitro - Mão da Ordem]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
