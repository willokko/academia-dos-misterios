---
titulo: "Sequência 7 - Suplicante de Segredos - Asceta das Sombras"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
sequencia: 7
nome_ingles: "Shadow Ascetic"
---

# Sequência 7 - Suplicante de Segredos - Asceta das Sombras

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Suplicante de Segredos]]. **Sequência:** 7. **Nome de referência:** Shadow Ascetic. Tradução editorial: Asceta das Sombras.

## O que a poção transforma

O [[Poder - Suplicante de Segredos S7 - Abrigo de sombra|pacote completo de Asceta das Sombras]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Afinidade sombria.

- [[Poder - Suplicante de Segredos S7 - Abrigo de sombra#Manto de sombra|Manto de sombra]]
- [[Poder - Suplicante de Segredos S7 - Abrigo de sombra#Gume de sombra|Gume de sombra]]
- [[Poder - Suplicante de Segredos S7 - Abrigo de sombra#Sombra que prende|Sombra que prende]]



## Atuação e digestão

Interpretação original do papel **Asceta das Sombras** no tema de escuta perigosa, sombras, carne e almas. Princípio de partida: buscar conhecimento sem entregar a própria responsabilidade à voz que responde. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Suplicante de Segredos#S7 - Asceta das Sombras]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Suplicante de Segredos - Ouvinte]]. Próxima: [[Sequência 6 - Suplicante de Segredos - Bispo da Rosa]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
