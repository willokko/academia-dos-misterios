---
titulo: "Poder - Espreitador de Mistérios S6 - Pergaminho preparado"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espreitador de Mistérios"
sequencia: 6
nome_pacote: "Pacote de Professor de Pergaminhos — Espreitador de Mistérios S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Espreitador de Mistérios S6 - Pergaminho preparado

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Professor de Pergaminhos, Espreitador de Mistérios S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Espreitador de Mistérios - Professor de Pergaminhos]] ou melhor no [[Caminho do Espreitador de Mistérios]]. **Referência nominal:** Scrolls Professor. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Professor de pergaminhos:** Prepara até quatro pergaminhos de técnicas ativas próprias S9–6. Cada um guarda um uso, não uma característica.

## Técnicas adquiridas

### Inscrever pergaminho

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até liberar |
| Teste | AST+VON ND10 |

Dez minutos e 25 zênites de material por inscrição. Pague os PM da técnica neste preparo e guarde um uso até liberar. Não perde o pergaminho ao descansar.

**Limites:** Só técnicas próprias sem criação de poderes, cópia ou pergaminhos recursivos.

### Liberar pergaminho

| Parâmetro | Regra |
|---|---|
| Custo | PM já pagos na preparação |
| Ação | Conforme técnica |
| Alcance | Cena |
| Duração | Conforme técnica |
| Teste | Conforme técnica |

Você ou um voluntário instruído usa a ação da técnica e seus próprios atributos; os PM já foram pagos. O pergaminho se consome.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Voz secreta

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | Automático |

Crie canal de frases entre você e até três voluntários na cena. Não lê pensamento alheio nem conecta mundo isolado.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5: seis pergaminhos e fórmulas próprias de S5. Transferir execução não gera mais turnos do que o grupo já possuía.

## Preparação e oposição

Informação falsa, falta de correspondência e revelação vedada. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espreitador de Mistérios]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
