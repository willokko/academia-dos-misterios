---
titulo: "Sequência 7 - Caçador - Piromaníaco"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
sequencia: 7
nome_ingles: "Pyromaniac"
---

# Sequência 7 - Caçador - Piromaníaco

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Caçador]]. **Sequência:** 7. **Nome de referência:** Pyromaniac. Tradução editorial: Piromaníaco.

## O que a poção transforma

O [[Poder - Caçador S7 - Lança de brasa|pacote completo de Piromaníaco]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Pirocinese.

- [[Poder - Caçador S7 - Lança de brasa#Bola de fogo|Bola de fogo]]
- [[Poder - Caçador S7 - Lança de brasa#Corvo de fogo|Corvo de fogo]]
- [[Poder - Caçador S7 - Lança de brasa#Manto de chamas|Manto de chamas]]



## Atuação e digestão

Interpretação original do papel **Piromaníaco** no tema de rastreio, provocação, fogo e guerra. Princípio de partida: conhecer a presa sem reduzir toda relação a caça. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Caçador#S7 - Piromaníaco]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Caçador - Provocador]]. Próxima: [[Sequência 6 - Caçador - Conspirador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
