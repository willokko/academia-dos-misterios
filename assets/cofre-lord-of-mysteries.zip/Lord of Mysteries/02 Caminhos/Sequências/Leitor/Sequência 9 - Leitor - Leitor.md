---
titulo: "Sequência 9 - Leitor - Leitor"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 9
nome_ingles: "Reader"
---

# Sequência 9 - Leitor - Leitor

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 9. **Nome de referência:** Reader. Tradução editorial: Leitor.

## O que a poção transforma

O [[Poder - Leitor S9 - Índice mental|pacote completo de Leitor]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Memória ampliada.

- [[Poder - Leitor S9 - Índice mental#Recuperar referência|Recuperar referência]]
- [[Poder - Leitor S9 - Índice mental#Pesquisa dirigida|Pesquisa dirigida]]
- [[Poder - Leitor S9 - Índice mental#Fundamento místico|Fundamento místico]]



## Atuação e digestão

Interpretação original do papel **Leitor** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S9 - Leitor]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Leitor - Estudante do Raciocínio]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
