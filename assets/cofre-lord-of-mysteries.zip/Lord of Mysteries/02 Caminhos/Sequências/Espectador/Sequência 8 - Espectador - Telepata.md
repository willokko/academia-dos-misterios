---
titulo: "Sequência 8 - Espectador - Telepata"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 8
nome_ingles: "Telepathist"
---

# Sequência 8 - Espectador - Telepata

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 8. **Nome de referência:** Telepathist. Tradução editorial: Telepata.

## O que a poção transforma

O [[Poder - Espectador S8 - Eco de pensamento|pacote completo de Telepata]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Percepção mental; Observação aprofundada.

- [[Poder - Espectador S8 - Eco de pensamento#Eco de pensamento|Eco de pensamento]]
- [[Poder - Espectador S8 - Eco de pensamento#Vínculo telepático|Vínculo telepático]]
- [[Poder - Espectador S8 - Eco de pensamento#Comparar gesto e mente|Comparar gesto e mente]]



## Atuação e digestão

Interpretação original do papel **Telepata** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S8 - Telepata]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Espectador - Espectador]]. Próxima: [[Sequência 7 - Espectador - Psiquiatra]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
