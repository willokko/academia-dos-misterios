---
titulo: "Sequência 8 - Suplicante de Segredos - Ouvinte"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
sequencia: 8
nome_ingles: "Listener"
---

# Sequência 8 - Suplicante de Segredos - Ouvinte

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Suplicante de Segredos]]. **Sequência:** 8. **Nome de referência:** Listener. Tradução editorial: Ouvinte.

## O que a poção transforma

O [[Poder - Suplicante de Segredos S8 - Escuta vedada|pacote completo de Ouvinte]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Audição do oculto.

- [[Poder - Suplicante de Segredos S8 - Escuta vedada#Escutar vínculo|Escutar vínculo]]
- [[Poder - Suplicante de Segredos S8 - Escuta vedada#Fechar a escuta|Fechar a escuta]]
- [[Poder - Suplicante de Segredos S8 - Escuta vedada#Voz intrusa|Voz intrusa]]



## Atuação e digestão

Interpretação original do papel **Ouvinte** no tema de escuta perigosa, sombras, carne e almas. Princípio de partida: buscar conhecimento sem entregar a própria responsabilidade à voz que responde. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Suplicante de Segredos#S8 - Ouvinte]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Suplicante de Segredos - Suplicante de Segredos]]. Próxima: [[Sequência 7 - Suplicante de Segredos - Asceta das Sombras]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
