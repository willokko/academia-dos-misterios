---
titulo: "Caminho do Espreitador de Mistérios"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
nome_divino: "Eremita"
referencia: "https://lordofthemysteries.fandom.com/wiki/Hermit_Pathway"
---

# Caminho do Espreitador de Mistérios

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Eremita. **Tema:** Conhecimento oculto, símbolos e histórias com poder. **Função:** Ocultismo, preparação e contramedidas.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Espreitador de Mistérios - Espreitador de Mistérios|Espreitador de Mistérios]] | [[Poder - Espreitador de Mistérios S9 - Anotação do oculto|3 técnicas]] |
| 8 | [[Sequência 8 - Espreitador de Mistérios - Erudito Marcial|Erudito Marcial]] | [[Poder - Espreitador de Mistérios S8 - Geometria marcial|3 técnicas]] |
| 7 | [[Sequência 7 - Espreitador de Mistérios - Bruxo|Bruxo]] | [[Poder - Espreitador de Mistérios S7 - Fórmula breve|3 técnicas]] |
| 6 | [[Sequência 6 - Espreitador de Mistérios - Professor de Pergaminhos|Professor de Pergaminhos]] | [[Poder - Espreitador de Mistérios S6 - Pergaminho preparado|3 técnicas]] |
| 5 | [[Sequência 5 - Espreitador de Mistérios - Mestre das Constelações|Mestre das Constelações]] | [[Poder - Espreitador de Mistérios S5 - Mapa das constelações|3 técnicas]] |
| 4 | [[Sequência 4 - Espreitador de Mistérios - Misticólogo|Misticólogo]] | [[Poder - Espreitador de Mistérios S4 - Autoridade de Misticólogo|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Espreitador de Mistérios - Clarividente|Clarividente]] | [[Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Espreitador de Mistérios - Sábio Místico|Sábio Místico]] | [[Poder - Espreitador de Mistérios S2 - Autoridade de Sábio Místico|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Espreitador de Mistérios - Imperador do Conhecimento|Imperador do Conhecimento]] | [[Poder - Espreitador de Mistérios S1 - Autoridade de Imperador do Conhecimento|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Espreitador de Mistérios - Eremita|Eremita]] | [[Poder - Espreitador de Mistérios S0 - Autoridade de Eremita|2 técnicas + operação]] |

## Como jogar

Investigar sem confundir curiosidade com direito a toda resposta. As ferramentas da S9 são olhos do mistério, conhecimento não solicitado. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: conhecimento perigoso. **Oposição:** Informação falsa, falta de correspondência e revelação vedada. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Espreitador de Mistérios]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Hermit_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
