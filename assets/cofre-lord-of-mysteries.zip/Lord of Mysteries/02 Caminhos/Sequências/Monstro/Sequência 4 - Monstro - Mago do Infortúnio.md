---
titulo: "Sequência 4 - Monstro - Mago do Infortúnio"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 4
nome_ingles: "Misfortune Mage"
---

# Sequência 4 - Monstro - Mago do Infortúnio

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 4. **Nome de referência:** Misfortune Mage. Tradução editorial: Mago do Infortúnio.

## O que a poção transforma

O [[Poder - Monstro S4 - Autoridade de Mago do Infortúnio|pacote completo de Mago do Infortúnio]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Mago do Infortúnio.

- [[Poder - Monstro S4 - Autoridade de Mago do Infortúnio#Marca de azar|Marca de azar]]
- [[Poder - Monstro S4 - Autoridade de Mago do Infortúnio#Cascata de risco|Cascata de risco]]

Operação: [[Poder - Monstro S4 - Autoridade de Mago do Infortúnio#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Mago do Infortúnio** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S4 - Mago do Infortúnio]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Monstro - Vencedor]]. Próxima: [[Sequência 3 - Monstro - Caminhante do Caos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
