---
titulo: "Sequência 0 - Sábio - Paragon"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 0
nome_ingles: "Paragon"
---

# Sequência 0 - Sábio - Paragon

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 0. **Nome de referência:** Paragon. Tradução editorial: Paragon.

## O que a poção transforma

O [[Poder - Sábio S0 - Autoridade de Paragon|pacote completo de Paragon]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Paragon.

- [[Poder - Sábio S0 - Autoridade de Paragon#Oficina do domínio|Oficina do domínio]]
- [[Poder - Sábio S0 - Autoridade de Paragon#Forma de informação|Forma de informação]]

Operação: [[Poder - Sábio S0 - Autoridade de Paragon#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Paragon** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S0 - Paragon]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Sábio - Iluminador]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
