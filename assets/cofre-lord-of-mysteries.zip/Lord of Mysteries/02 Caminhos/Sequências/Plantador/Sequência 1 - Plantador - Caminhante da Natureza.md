---
titulo: "Sequência 1 - Plantador - Caminhante da Natureza"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
sequencia: 1
nome_ingles: "Naturewalker"
---

# Sequência 1 - Plantador - Caminhante da Natureza

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Plantador]]. **Sequência:** 1. **Nome de referência:** Naturewalker. Tradução editorial: Caminhante da Natureza.

## O que a poção transforma

O [[Poder - Plantador S1 - Autoridade de Caminhante da Natureza|pacote completo de Caminhante da Natureza]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Caminhante da Natureza.

- [[Poder - Plantador S1 - Autoridade de Caminhante da Natureza#Passagem da natureza|Passagem da natureza]]
- [[Poder - Plantador S1 - Autoridade de Caminhante da Natureza#Voz do ecossistema|Voz do ecossistema]]

Operação: [[Poder - Plantador S1 - Autoridade de Caminhante da Natureza#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Caminhante da Natureza** no tema de cultivo, medicina, vida e transformações orgânicas. Princípio de partida: cultivar condições para que outros vivam sem possuir seu futuro. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Plantador#S1 - Caminhante da Natureza]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Plantador - Matriarca da Desolação]]. Próxima: [[Sequência 0 - Plantador - Mãe]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
