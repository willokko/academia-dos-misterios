---
titulo: "Sequência 6 - Sábio - Artesão"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 6
nome_ingles: "Artisan"
---

# Sequência 6 - Sábio - Artesão

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 6. **Nome de referência:** Artisan. Tradução editorial: Artesão.

## O que a poção transforma

O [[Poder - Sábio S6 - Oficina de urgência|pacote completo de Artesão]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Ofício do artesão.

- [[Poder - Sábio S6 - Oficina de urgência#Fabricar receptáculo|Fabricar receptáculo]]
- [[Poder - Sábio S6 - Oficina de urgência#Reconfigurar dispositivo|Reconfigurar dispositivo]]
- [[Poder - Sábio S6 - Oficina de urgência#Contenção de emergência|Contenção de emergência]]



## Atuação e digestão

Interpretação original do papel **Artesão** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S6 - Artesão]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Sábio - Avaliador]]. Próxima: [[Sequência 5 - Sábio - Astrônomo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
