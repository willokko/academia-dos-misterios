---
titulo: "Sequência 5 - Sábio - Astrônomo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 5
nome_ingles: "Astronomer"
---

# Sequência 5 - Sábio - Astrônomo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 5. **Nome de referência:** Astronomer. Tradução editorial: Astrônomo.

## O que a poção transforma

O [[Poder - Sábio S5 - Instrumento estelar|pacote completo de Astrônomo]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Astronomia aplicada.

- [[Poder - Sábio S5 - Instrumento estelar#Cálculo celeste|Cálculo celeste]]
- [[Poder - Sábio S5 - Instrumento estelar#Lente de projeção|Lente de projeção]]
- [[Poder - Sábio S5 - Instrumento estelar#Rede de instrumentos|Rede de instrumentos]]



## Atuação e digestão

Interpretação original do papel **Astrônomo** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S5 - Astrônomo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Sábio - Artesão]]. Próxima: [[Sequência 4 - Sábio - Alquimista]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
