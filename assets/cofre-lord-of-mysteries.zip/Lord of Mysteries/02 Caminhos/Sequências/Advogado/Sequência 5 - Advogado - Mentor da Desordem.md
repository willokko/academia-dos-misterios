---
titulo: "Sequência 5 - Advogado - Mentor da Desordem"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
sequencia: 5
nome_ingles: "Mentor of Disorder"
---

# Sequência 5 - Advogado - Mentor da Desordem

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Advogado]]. **Sequência:** 5. **Nome de referência:** Mentor of Disorder. Tradução editorial: Mentor da Desordem.

## O que a poção transforma

O [[Poder - Advogado S5 - Desordem focal|pacote completo de Mentor da Desordem]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Presença de desordem.

- [[Poder - Advogado S5 - Desordem focal#Desordenar percurso|Desordenar percurso]]
- [[Poder - Advogado S5 - Desordem focal#Partilhar aflição|Partilhar aflição]]
- [[Poder - Advogado S5 - Desordem focal#Degrau distorcido|Degrau distorcido]]



## Atuação e digestão

Interpretação original do papel **Mentor da Desordem** no tema de brechas, suborno e distorção de regras. Princípio de partida: conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Advogado#S5 - Mentor da Desordem]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Advogado - Barão da Corrupção]]. Próxima: [[Sequência 4 - Advogado - Conde dos Caídos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
