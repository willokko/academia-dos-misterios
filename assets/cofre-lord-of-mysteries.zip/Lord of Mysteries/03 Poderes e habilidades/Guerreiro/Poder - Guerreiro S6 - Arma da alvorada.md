---
titulo: "Poder - Guerreiro S6 - Arma da alvorada"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Guerreiro"
sequencia: 6
nome_pacote: "Pacote de Paladino da Alvorada — Guerreiro S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Guerreiro S6 - Arma da alvorada

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Paladino da Alvorada, Guerreiro S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Guerreiro - Paladino da Alvorada]] ou melhor no [[Caminho do Guerreiro]]. **Referência nominal:** Dawn Paladin. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Luz da alvorada:** Pode conjurar arma e armadura luminosas por uma cena: a arma corporal usa RA+15 físicos e atinge espírito exposto; a armadura reduz 5 dano físico. Criar ambas exige a técnica e não produz itens vendáveis.

## Técnicas adquiridas

### Armar a alvorada

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

Manifeste o equipamento descrito na capacidade permanente; ativação custa uma ação, mas mantê-lo não.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Lâmina de luz

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | VIG+VON contra DEF.M |

Um alvo sofre RA+20 de dano luz em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Tempestade de luz

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica atordoado e o alvo perde a clareza visual diante da luz; não elimina todos os espíritos da cena.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

## Evolução e acúmulo

S5 reforça proteção de companheiros; a redução de dano de armadura de Caminho não acumula outras reduções passivas de Caminho.

## Preparação e oposição

Riscos que exigem informação, ataques indiretos e múltiplos objetivos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Guerreiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
