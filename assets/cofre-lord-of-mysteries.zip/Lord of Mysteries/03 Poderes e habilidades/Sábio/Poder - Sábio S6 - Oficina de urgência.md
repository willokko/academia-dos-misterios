---
titulo: "Poder - Sábio S6 - Oficina de urgência"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Sábio"
sequencia: 6
nome_pacote: "Pacote de Artesão — Sábio S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Sábio S6 - Oficina de urgência

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Artesão, Sábio S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Sábio - Artesão]] ou melhor no [[Caminho do Sábio]]. **Referência nominal:** Artisan. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Ofício do artesão:** Habilita projetos de objetos selados com característica real e oficinas de Projetos e fabricação, sem exigir a classe Inventor para esses objetos específicos.

## Técnicas adquiridas

### Fabricar receptáculo

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Um intervalo de trabalho |
| Alcance | Cena |
| Duração | Permanente ao concluir |
| Teste | AST+AST ND13 |

Execute uma etapa de projeto para combinar característica registrada e recipiente; custo material, prazo e defeito seguem a nota normativa. Não consome a característica a cada teste.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Reconfigurar dispositivo

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+AST ND10 |

Com acesso a um item próprio e um componente preparado, troque qual de duas funções previamente projetadas está disponível nesta cena. Não inventa uma terceira função.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Contenção de emergência

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

+2 ao próximo teste para selar ou interromper vazamento de artefato cujo defeito conhece.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

A fabricação cria repertório por tempo e matéria; uma poção não entrega um arsenal gratuito.

## Preparação e oposição

Materiais escassos, falta de oficina e defeitos conhecidos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Sábio]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
