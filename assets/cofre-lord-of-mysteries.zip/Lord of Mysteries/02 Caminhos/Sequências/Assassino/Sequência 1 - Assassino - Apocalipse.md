---
titulo: "Sequência 1 - Assassino - Apocalipse"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 1
nome_ingles: "Apocalypse"
---

# Sequência 1 - Assassino - Apocalipse

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 1. **Nome de referência:** Apocalypse. Tradução editorial: Apocalipse.

## O que a poção transforma

O [[Poder - Assassino S1 - Autoridade de Apocalipse|pacote completo de Apocalipse]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Apocalipse.

- [[Poder - Assassino S1 - Autoridade de Apocalipse#Sinal do fim|Sinal do fim]]
- [[Poder - Assassino S1 - Autoridade de Apocalipse#Desfazer a ordem|Desfazer a ordem]]

Operação: [[Poder - Assassino S1 - Autoridade de Apocalipse#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Apocalipse** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S1 - Apocalipse]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Assassino - Catástrofe]]. Próxima: [[Sequência 0 - Assassino - Demoness]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
