---
titulo: "Sequência 4 - Bardo - Sem Sombra"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 4
nome_ingles: "Unshadowed"
---

# Sequência 4 - Bardo - Sem Sombra

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 4. **Nome de referência:** Unshadowed. Tradução editorial: Sem Sombra.

## O que a poção transforma

O [[Poder - Bardo S4 - Autoridade de Sem Sombra|pacote completo de Sem Sombra]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Sem Sombra.

- [[Poder - Bardo S4 - Autoridade de Sem Sombra#Corpo sem sombra|Corpo sem sombra]]
- [[Poder - Bardo S4 - Autoridade de Sem Sombra#Purificar manifestação|Purificar manifestação]]

Operação: [[Poder - Bardo S4 - Autoridade de Sem Sombra#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Sem Sombra** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S4 - Sem Sombra]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Bardo - Sacerdote da Luz]]. Próxima: [[Sequência 3 - Bardo - Mentor da Justiça]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
