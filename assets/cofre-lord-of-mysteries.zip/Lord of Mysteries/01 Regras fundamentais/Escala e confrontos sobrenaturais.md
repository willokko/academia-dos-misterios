---
titulo: "Escala e confrontos sobrenaturais"
tipo: "regras-fundamentais"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Escala e confrontos sobrenaturais

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

## A capacidade funciona

Uma porta ordinária não exige um arco para ser atravessada por Aprendiz. Água ordinária não apaga a afinidade do Marinheiro. Um espectro pode atravessar uma parede fina sem rolar por ser inconveniente ao cenário. A técnica estabelece a permissão; só risco, oposição ou limite real exigem teste. Custos de PM e ação permanecem quando impressos.

| Patamar | Graus | O que muda |
|---|---|---|
| Baixo | S9–8 | Sentidos, corpo e ofícios extraordinários |
| Médio | S7–5 | Repertórios, formas e controle especializado |
| Santo | S4–3 | Manifestação superior, domínio e forma mítica incompleta |
| Angelical | S2–1 | Âncoras, vínculos e operações de autoridade |
| Divino | S0 | Unicidade e domínio; sem equivalência a um bônus de PV |

Uma diferença dentro do mesmo patamar não é imunidade. A manifestação de alguém de patamar superior não pode ser encerrada por técnica inferior sem uma chave: artefato apropriado, fraqueza descoberta, vínculo roubado, pacto, distração ou apoio de autoridade. **Isso limita o resultado sobrenatural, não concede imunidade universal a balas, negociação ou resgate.** A ficha e a natureza da entidade definem como pode ser atingida.

## Três tamanhos de efeito

1. **Aplicação local sem oposição equivalente:** funciona pelo custo e ação escritos. Não abra relógio só por ser santo. Um recinto, pessoa ou passagem da cena é o alcance padrão, inclusive para deuses que escolhem agir localmente.
2. **Aplicação local resistida:** teste AST+VON contra DEF.M do alvo, ou ND13 para obstáculo sem ficha, ND16 se angelical/divino. Use atributos diferentes quando a ficha disser. Sem brecha de escala, primeiro consiga a chave, em vez de pagar PM numa tentativa impossível.
3. **Operação:** mudar cidade/região, encerrar uma fonte persistente equivalente, ressuscitar ou transformar uma ordem exige preparação, chaves e relógio. Santos usam [[Módulo dos santos]]; anjos/divindades usam [[Módulo angelical e divino]].

Não converta toda técnica de alta Sequência em operação. As duas aplicações locais de cada ficha são opções efetivas na cena; o feito de operação é o terceiro recurso de escala maior. Uma fonte pode voltar depois de suspensão local, dando sentido à operação que a encerra.

## Formas e retorno

Forma mítica incompleta: ação, 20 PM, +2 Corrupção, uma vez por sessão, pela cena. Se uma técnica já manifesta a forma mítica por custo próprio, pague esse custo em vez de somar outra taxa de 20 PM, mantendo +2 Corrupção e a frequência. Dá permissão de interagir com obstáculo de santo e as capacidades expressas da ficha. Não soma outro bônus de forma a si mesma. Observadores podem desviar olhar ao receber aviso; exposição vedada segue Corrupção. Formas corporais de baixo grau, como lobo ou espectro, usam seus próprios textos e não cobram esse custo adicional.

**Restituição após morte** só existe para a ficha que a concede. Exige vestígio, alma/identidade alcançável, característica não extraída e uma âncora. É uma operação com ao menos duas cenas; a ficha pode pedir mais. Cada personagem só inicia um retorno por arco. O perigo pode ser perda de memória, perseguição do vestígio ou captura da característica, anunciado antes. Não duplica a pessoa ou recursos e não devolve alma destruída por simples PM. Este limite é editorial, não contagem canônica de ressurreições.

Se o portador já morreu, um aliado que alcança o vestígio pode iniciar a operação e pagar a taxa do módulo com seus próprios PM. Isso é uma exceção expressa de Restituição, não compartilhamento geral de custos rituais. Não se cobra uma segunda taxa da técnica local; a ficha concede acesso ao retorno e o módulo resolve a tentativa. Sem aliado ou manifestação capaz de iniciar e proteger o vestígio, o retorno não acontece sozinho fora de cena.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
