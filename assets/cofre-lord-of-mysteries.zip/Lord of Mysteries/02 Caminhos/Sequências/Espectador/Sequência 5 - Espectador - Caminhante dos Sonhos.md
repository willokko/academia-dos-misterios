---
titulo: "Sequência 5 - Espectador - Caminhante dos Sonhos"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 5
nome_ingles: "Dreamwalker"
---

# Sequência 5 - Espectador - Caminhante dos Sonhos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 5. **Nome de referência:** Dreamwalker. Tradução editorial: Caminhante dos Sonhos.

## O que a poção transforma

O [[Poder - Espectador S5 - Passo no sonho|pacote completo de Caminhante dos Sonhos]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Corpo e sonho; Limites da imagem.

- [[Poder - Espectador S5 - Passo no sonho#Entrar no sonho|Entrar no sonho]]
- [[Poder - Espectador S5 - Passo no sonho#Moldar o cenário|Moldar o cenário]]
- [[Poder - Espectador S5 - Passo no sonho#Sair com companhia|Sair com companhia]]



## Atuação e digestão

Interpretação original do papel **Caminhante dos Sonhos** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S5 - Caminhante dos Sonhos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Espectador - Hipnotizador]]. Próxima: [[Sequência 4 - Espectador - Manipulador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
