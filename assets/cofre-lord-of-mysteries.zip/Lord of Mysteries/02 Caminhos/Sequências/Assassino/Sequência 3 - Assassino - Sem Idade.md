---
titulo: "Sequência 3 - Assassino - Sem Idade"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 3
nome_ingles: "Unaging"
---

# Sequência 3 - Assassino - Sem Idade

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 3. **Nome de referência:** Unaging. Tradução editorial: Sem Idade.

## O que a poção transforma

O [[Poder - Assassino S3 - Autoridade de Sem Idade|pacote completo de Sem Idade]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Sem Idade.

- [[Poder - Assassino S3 - Autoridade de Sem Idade#Corpo sem idade|Corpo sem idade]]
- [[Poder - Assassino S3 - Autoridade de Sem Idade#Refúgio refletido|Refúgio refletido]]

Operação: [[Poder - Assassino S3 - Autoridade de Sem Idade#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Sem Idade** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S3 - Sem Idade]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Assassino - Desespero]]. Próxima: [[Sequência 2 - Assassino - Catástrofe]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
