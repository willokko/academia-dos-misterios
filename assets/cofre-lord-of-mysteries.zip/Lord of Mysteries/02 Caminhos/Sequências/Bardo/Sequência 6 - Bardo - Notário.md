---
titulo: "Sequência 6 - Bardo - Notário"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 6
nome_ingles: "Notary"
---

# Sequência 6 - Bardo - Notário

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 6. **Nome de referência:** Notary. Tradução editorial: Notário.

## O que a poção transforma

O [[Poder - Bardo S6 - Pacto testemunhado|pacote completo de Notário]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Testemunha sobrenatural.

- [[Poder - Bardo S6 - Pacto testemunhado#Reconhecer pacto|Reconhecer pacto]]
- [[Poder - Bardo S6 - Pacto testemunhado#Notarizar técnica|Notarizar técnica]]
- [[Poder - Bardo S6 - Pacto testemunhado#Ato inválido|Ato inválido]]



## Atuação e digestão

Interpretação original do papel **Notário** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S6 - Notário]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Bardo - Sumo Sacerdote Solar]]. Próxima: [[Sequência 5 - Bardo - Sacerdote da Luz]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
