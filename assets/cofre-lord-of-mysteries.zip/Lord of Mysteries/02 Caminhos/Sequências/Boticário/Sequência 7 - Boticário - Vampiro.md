---
titulo: "Sequência 7 - Boticário - Vampiro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 7
nome_ingles: "Vampire"
---

# Sequência 7 - Boticário - Vampiro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 7. **Nome de referência:** Vampire. Tradução editorial: Vampiro.

## O que a poção transforma

O [[Poder - Boticário S7 - Vigor sanguíneo|pacote completo de Vampiro]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Fisiologia sanguínea.

- [[Poder - Boticário S7 - Vigor sanguíneo#Asas sanguíneas|Asas sanguíneas]]
- [[Poder - Boticário S7 - Vigor sanguíneo#Garras do sanguíneo|Garras do sanguíneo]]
- [[Poder - Boticário S7 - Vigor sanguíneo#Regeneração sanguínea|Regeneração sanguínea]]



## Atuação e digestão

Interpretação original do papel **Vampiro** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S7 - Vampiro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Boticário - Domador de Bestas]]. Próxima: [[Sequência 6 - Boticário - Professor de Poções]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
