---
titulo: "Sequência 1 - Caçador - Conquistador"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
sequencia: 1
nome_ingles: "Conqueror"
---

# Sequência 1 - Caçador - Conquistador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Caçador]]. **Sequência:** 1. **Nome de referência:** Conqueror. Tradução editorial: Conquistador.

## O que a poção transforma

O [[Poder - Caçador S1 - Autoridade de Conquistador|pacote completo de Conquistador]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Conquistador.

- [[Poder - Caçador S1 - Autoridade de Conquistador#Marca de conquista|Marca de conquista]]
- [[Poder - Caçador S1 - Autoridade de Conquistador#Marcha do conquistador|Marcha do conquistador]]

Operação: [[Poder - Caçador S1 - Autoridade de Conquistador#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Conquistador** no tema de rastreio, provocação, fogo e guerra. Princípio de partida: conhecer a presa sem reduzir toda relação a caça. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Caçador#S1 - Conquistador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Caçador - Feiticeiro do Clima]]. Próxima: [[Sequência 0 - Caçador - Sacerdote Vermelho]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
