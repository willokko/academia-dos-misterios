---
titulo: "Sequência 7 - Prisioneiro - Lobisomem"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 7
nome_ingles: "Werewolf"
---

# Sequência 7 - Prisioneiro - Lobisomem

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 7. **Nome de referência:** Werewolf. Tradução editorial: Lobisomem.

## O que a poção transforma

O [[Poder - Prisioneiro S7 - Garras do limiar|pacote completo de Lobisomem]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Forma lupina.

- [[Poder - Prisioneiro S7 - Garras do limiar#Transformação lupina|Transformação lupina]]
- [[Poder - Prisioneiro S7 - Garras do limiar#Regeneração do lobo|Regeneração do lobo]]
- [[Poder - Prisioneiro S7 - Garras do limiar#Resistir à leitura|Resistir à leitura]]



## Atuação e digestão

Interpretação original do papel **Lobisomem** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S7 - Lobisomem]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Prisioneiro - Lunático]]. Próxima: [[Sequência 6 - Prisioneiro - Zumbi]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
