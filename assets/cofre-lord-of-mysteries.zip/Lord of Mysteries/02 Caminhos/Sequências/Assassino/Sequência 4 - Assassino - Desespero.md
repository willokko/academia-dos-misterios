---
titulo: "Sequência 4 - Assassino - Desespero"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 4
nome_ingles: "Despair"
---

# Sequência 4 - Assassino - Desespero

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 4. **Nome de referência:** Despair. Tradução editorial: Desespero.

## O que a poção transforma

O [[Poder - Assassino S4 - Autoridade de Desespero|pacote completo de Desespero]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Desespero.

- [[Poder - Assassino S4 - Autoridade de Desespero#Praga espiritual|Praga espiritual]]
- [[Poder - Assassino S4 - Autoridade de Desespero#Petrificar o toque|Petrificar o toque]]

Operação: [[Poder - Assassino S4 - Autoridade de Desespero#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Desespero** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S4 - Desespero]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Assassino - Aflição]]. Próxima: [[Sequência 3 - Assassino - Sem Idade]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
