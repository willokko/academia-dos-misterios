---
titulo: "Poder - Coletor de Cadáveres S8 - Voz junto à sepultura"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Coletor de Cadáveres"
sequencia: 8
nome_pacote: "Pacote de Coveiro — Coletor de Cadáveres S8"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Coletor de Cadáveres S8 - Voz junto à sepultura

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Coveiro, Coletor de Cadáveres S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Coletor de Cadáveres - Coveiro]] ou melhor no [[Caminho do Coletor de Cadáveres]]. **Referência nominal:** Gravedigger. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Força do coveiro:** +2 para cavar, erguer ou transportar corpos e obstáculos inertes; não concede bônus universal de ataque.

## Técnicas adquiridas

### Disfarce cadavérico

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

Suprima sinais vitais superficiais por uma cena. Um exame espiritual atento exige AST+VON oposto; não o torna imune à morte.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Afastar morto errante

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma rodada |
| Teste | AST+VON contra DEF.M |

Um morto-vivo inferior sem mestre recua do espaço imediato por um turno em sucesso; não domina entidade inteligente.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Toque gelado

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Toque |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+15 de dano trevas em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S7 pode negociar em vez de afastar; S6 coordena mortos por vínculos preparados.

## Preparação e oposição

Purificação, restos sem identidade e espíritos sob domínio alheio. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Coletor de Cadáveres]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
