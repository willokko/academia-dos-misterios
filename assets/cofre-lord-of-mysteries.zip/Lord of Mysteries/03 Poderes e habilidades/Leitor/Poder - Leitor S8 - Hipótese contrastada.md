---
titulo: "Poder - Leitor S8 - Hipótese contrastada"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Leitor"
sequencia: 8
nome_pacote: "Pacote de Estudante do Raciocínio — Leitor S8"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Leitor S8 - Hipótese contrastada

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Estudante do Raciocínio, Leitor S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Leitor - Estudante do Raciocínio]] ou melhor no [[Caminho do Leitor]]. **Referência nominal:** Student of Ratiocination. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Raciocínio:** +2 para relacionar pelo menos duas evidências verdadeiras; não produz uma conclusão factual a partir de premissa falsa.

## Técnicas adquiridas

### Cadeia de inferência

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Duas pistas revelam uma ligação provável e uma pergunta para testá-la. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Encontrar contradição

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Compare dois relatos com documentos: identifique uma incompatibilidade observável, sem apontar automaticamente o culpado. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Prever o método

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

Após analisar um adversário, +2 ao próximo Objetivo contra o método que identificou, sem bônus universal de combate.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S7 permite transformar análise em localização e identificação técnica; novas fontes continuam necessárias.

## Preparação e oposição

Informação falsa, fenômenos novos e acesso negado a evidências. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Leitor]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
