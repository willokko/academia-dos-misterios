---
titulo: "Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Coletor de Cadáveres"
sequencia: 4
nome_pacote: "Pacote de Imorredouro — Coletor de Cadáveres S4"
quantidade_tecnicas: 2
quantidade_capacidades: 1
quantidade_operacoes: 1
---

# Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Imorredouro, Coletor de Cadáveres S4.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 4 - Coletor de Cadáveres - Imorredouro]] ou melhor no [[Caminho do Coletor de Cadáveres]]. **Referência nominal:** Undying. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Transformação de Imorredouro:** Sua continuidade após morte exige um vestígio e memória preservados; cada retorno altera sua relação com a própria identidade.

## Técnicas adquiridas

### Corpo imorredouro

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND13 em obstáculo sem ficha |

Pela cena, sobreviva a uma mutilação que normalmente interromperia sua participação; não recupera PV nem ignora purificação.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

### Retorno funerário

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Início de operação de Restituição |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Até encerrar a operação |
| Teste | Contribuições de Objetivo ND13; aliado iniciador paga a taxa quando o portador já morreu |

Após morte e com característica não extraída, aliados podem iniciar Restituição; exige duas cenas de proteção e tratamento, uma vez por arco.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

## Feito de operação

Recuperar uma identidade em retorno sem deixá-la ser substituída pela impressão da característica.

**Procedimento:** [[Módulo dos santos]]. Reúna duas chaves, declare alvo, transformação e consequência do perigo. O portador inicia uma vez por cena, ação Poder, 20 PM e primeiro teste ND13; objetivo de 8 seções. Cada PJ contribui uma vez por rodada com Objetivo e margens normais, sem pagar novamente a taxa. Não use esse relógio para atrasar as aplicações locais sem oposição equivalente.

## Evolução e acúmulo

Conserva todos os pacotes anteriores. O novo grau amplia a natureza do que pode fazer, não soma automaticamente dano ou bônus de todas as formas. Capacidades de operação seguem seu módulo e Escala e confrontos sobrenaturais.

## Preparação e oposição

Purificação, restos sem identidade e espíritos sob domínio alheio. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Coletor de Cadáveres]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
