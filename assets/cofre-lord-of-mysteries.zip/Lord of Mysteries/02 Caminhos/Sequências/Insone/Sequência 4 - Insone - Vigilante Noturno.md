---
titulo: "Sequência 4 - Insone - Vigilante Noturno"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 4
nome_ingles: "Nightwatcher"
---

# Sequência 4 - Insone - Vigilante Noturno

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 4. **Nome de referência:** Nightwatcher. Tradução editorial: Vigilante Noturno.

## O que a poção transforma

O [[Poder - Insone S4 - Autoridade de Vigilante Noturno|pacote completo de Vigilante Noturno]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Vigilante Noturno.

- [[Poder - Insone S4 - Autoridade de Vigilante Noturno#Vigília sombria|Vigília sombria]]
- [[Poder - Insone S4 - Autoridade de Vigilante Noturno#Lacre da noite|Lacre da noite]]

Operação: [[Poder - Insone S4 - Autoridade de Vigilante Noturno#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Vigilante Noturno** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S4 - Vigilante Noturno]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Insone - Feiticeiro dos Espíritos]]. Próxima: [[Sequência 3 - Insone - Bispo do Horror]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
