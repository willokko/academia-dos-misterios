---
titulo: "Poder - Advogado S6 - Distorção de percurso"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Advogado"
sequencia: 6
nome_pacote: "Pacote de Barão da Corrupção — Advogado S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Advogado S6 - Distorção de percurso

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Barão da Corrupção, Advogado S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Advogado - Barão da Corrupção]] ou melhor no [[Caminho do Advogado]]. **Referência nominal:** Baron of Corruption. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Leitura da distorção:** Reconhece efeitos próprios de distorção e as condições que os sustentam, sem decifrar autoridades de outras origens.

## Técnicas adquiridas

### Desviar trajetória

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Um ataque |
| Teste | Automático |

Antes da rolagem de um ataque com trajetória, distorça seu rumo: +2 DEF para um alvo. Não redireciona dano a um segundo inimigo nesta versão.

**Limites:** Uma reação de Caminho por rodada.

### Distorcer passagem

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON ND13 |

Distorça abrir ou fechar uma porta: crie uma barreira de 4 seções num recinto ordinário, que pode ser rompida por Objetivo. Não atravessa autoridade maior.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Corroer a intenção

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica abalado e a ambição manifesta do alvo interfere em seu julgamento, sem impor crime ou submissão.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

## Evolução e acúmulo

S5 desordena posições e compartilha efeitos por uma conexão; cada uso precisa declarar o aspecto alterado.

## Preparação e oposição

Termos claros, ausência de troca aceita e jurisdição rival. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Advogado]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
