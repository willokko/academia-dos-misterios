---
titulo: "Sequência 6 - Caçador - Conspirador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
sequencia: 6
nome_ingles: "Conspirer"
---

# Sequência 6 - Caçador - Conspirador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Caçador]]. **Sequência:** 6. **Nome de referência:** Conspirer. Tradução editorial: Conspirador.

## O que a poção transforma

O [[Poder - Caçador S6 - Plano em camadas|pacote completo de Conspirador]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Mente do conspirador.

- [[Poder - Caçador S6 - Plano em camadas#Conspiração preparada|Conspiração preparada]]
- [[Poder - Caçador S6 - Plano em camadas#Corpo na chama|Corpo na chama]]
- [[Poder - Caçador S6 - Plano em camadas#Desorientar o plano|Desorientar o plano]]



## Atuação e digestão

Interpretação original do papel **Conspirador** no tema de rastreio, provocação, fogo e guerra. Princípio de partida: conhecer a presa sem reduzir toda relação a caça. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Caçador#S6 - Conspirador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Caçador - Piromaníaco]]. Próxima: [[Sequência 5 - Caçador - Ceifador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
