---
titulo: "Glossário"
tipo: "início"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Glossário

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

| Termo | Uso neste suplemento |
|---|---|
| Beyonder | Pessoa ou criatura portadora de poder sobrenatural; mantido sem tradução |
| Caminho / Pathway | Progressão temática sobrenatural; não é uma classe de FU |
| Sequência / Sequence | Grau decrescente de 9 a 0; número menor indica maior patamar |
| Poção | Fórmula de avanço; distinta dos consumíveis comuns comprados com PI |
| Digestão | Integração da característica, acompanhada por [[Digestão e atuação]] |
| Método de Atuação | Interpretação simbólica do papel sem perder a própria identidade |
| Espiritualidade | Conceito do cenário; seu gasto mecânico usa PM |
| Corrupção | Relógio ficcional da adaptação; não representa saúde mental real |
| Característica | Material sobrenatural persistente, ver [[Características Beyonder]] |
| Âncora | Vínculo ou instituição que sustenta identidade, sobretudo nas altas Sequências |
| Unicidade / Uniqueness | Elemento único do Caminho; objetivo de campanha, não mercadoria |
| RA | Rolagem alta: maior dos dois resultados individuais de um teste |
| ND | Nível de dificuldade |
| AST / DES / VIG / VON | Astúcia / Destreza / Vigor / Vontade |
| PV / PM / PI | Pontos de Vida / Mana / Inventário |
| Cena | Situação contínua com objetivos e oposição; mudar de cômodo não renova limites |
| Descanso | Cena de descanso definida pelo básico; não um intervalo de alguns minutos |

[[Índice dos 22 Caminhos]] relaciona os nomes de entrada aos nomes divinos. `S5 ou melhor` significa Sequência 5, 4, 3, 2, 1 ou 0 daquele Caminho.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
