---
titulo: "Poder - Coletor de Cadáveres S6 - Guia do limiar"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Coletor de Cadáveres"
sequencia: 6
nome_pacote: "Pacote de Guia Espiritual — Coletor de Cadáveres S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Coletor de Cadáveres S6 - Guia do limiar

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Guia Espiritual, Coletor de Cadáveres S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Coletor de Cadáveres - Guia Espiritual]] ou melhor no [[Caminho do Coletor de Cadáveres]]. **Referência nominal:** Spirit Guide. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Guia de almas:** Pode manter dois espíritos conhecidos como contatos; são vínculos, não duas ações extras nem poderes de todos os mortos.

## Técnicas adquiridas

### Mensageiro espiritual

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até uma hora |
| Teste | AST+VON ND13 sob oposição |

Envie espírito cooperativo a lugar conhecido na mesma região; ele leva frase e retorna com o que percebeu. Selos podem barrá-lo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Saída do corpo

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Dez minutos |
| Teste | AST+VON ND10; ND13 sob interferência |

Projete percepção com um guia para explorar a cena adjacente por dez minutos; seu corpo fica imóvel. Não ataca nos dois locais.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Correntes funerárias

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica lento e vínculos frios prendem o passo, sem apagar a mente do alvo.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

## Evolução e acúmulo

S5 permite dar abrigo aos contatos e manifestar o limiar do submundo.

## Preparação e oposição

Purificação, restos sem identidade e espíritos sob domínio alheio. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Coletor de Cadáveres]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
