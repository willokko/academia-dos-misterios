---
titulo: "Poder - Advogado S5 - Desordem focal"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Advogado"
sequencia: 5
nome_pacote: "Pacote de Mentor da Desordem — Advogado S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Advogado S5 - Desordem focal

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Mentor da Desordem, Advogado S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Advogado - Mentor da Desordem]] ou melhor no [[Caminho do Advogado]]. **Referência nominal:** Mentor of Disorder. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Presença de desordem:** Pode perceber contradição entre movimento declarado e espaço afetado por sua própria técnica; não define todas as leis do local.

## Técnicas adquiridas

### Desordenar percurso

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o fim do próximo turno dos alvos |
| Teste | AST+VON contra DEF.M |

Até dois alvos testam separadamente; em sucesso ficam lentos e não podem atravessar uma passagem marcada sem Objetivo AST+VON ND13.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Partilhar aflição

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Com suborno de conexão ativo, uma condição sua pode ser compartilhada: NPC sofre a mesma condição em sucesso e a sua termina. Não transfere Corrupção ou morte.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Degrau distorcido

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | Automático |

Uma escada ou apoio ordinário muda posição para oferecer uma rota de travessia na cena. Não altera um ataque, edifício inteiro ou selo no mesmo uso.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 começa a explorar estados e leis; efeitos de autoridade precisam de alvo e brecha, não de jogo de palavras ilimitado.

## Preparação e oposição

Termos claros, ausência de troca aceita e jurisdição rival. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Advogado]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
