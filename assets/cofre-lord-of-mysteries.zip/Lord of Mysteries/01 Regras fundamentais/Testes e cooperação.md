---
titulo: "Testes e cooperação"
tipo: "regras-fundamentais"
origem: "oficial-fu"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/oficial-fu"]
---

# Testes e cooperação

> [!info] Regra oficial resumida
> Paráfrase do livro básico local. Consulte [[Fontes de Fabula Ultima]] para páginas e limitações.

Role exatamente dois dados de atributos e some seus resultados com os modificadores aplicáveis. O maior resultado individual é a RA. Igualar ou superar o ND basta. Dois resultados iguais, ambos 6 ou mais, são sucesso crítico automático e oportunidade; dois 1 são falha crítica automática, oportunidade da oposição e 1 Ponto de Fabula para o PJ.

| ND | 7 | 10 | 13 | 16 |
|---|---|---|---|---|
| Dificuldade | Fácil | Normal | Difícil | Muito difícil |

Não role por uma pista inevitavelmente disponível ou por uma tarefa sem risco. Declare objetivo, abordagem, consequência e ND antes de rolar. Testes opostos usam o procedimento do básico; poderes desta adaptação normalmente especificam DEF.M ou um ND fixo para reduzir rolagens. Um efeito que não pede teste é automático dentro de seus limites.

## Cooperação oficial

Nomeie um líder. Cada apoiador faz o mesmo teste contra ND 10. Cada sucesso dá +1 ao teste do líder; entre os apoiadores bem-sucedidos, some ainda a maior força de Laço com o líder. Críticos de apoio não geram oportunidades. O teste final afeta todos os participantes. Não some todas as forças de Laço.

## Relógios oficiais

Em testes para avançar um relógio: sucesso preenche uma seção, margem +3 preenche duas, margem +6 preenche três. Uma oportunidade pode acrescentar duas. Falhas podem avançar relógios de perigo com margens equivalentes. Os relógios de digestão possuem seu próprio procedimento de fechamento, sem rolagem.

Exemplo: para selar uma passagem, o líder precisa de 13. Um apoiador passa e tem Laço 2 com ele: bônus total +3. Se o resultado final é 16, preenche duas seções. Se o dado foi crítico, pode usar a oportunidade para mais duas.

Referências: básico pp. 38–53; Traços e Laços pp. 46–57. [[Validação e exemplos]] mostra probabilidades enumeradas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
