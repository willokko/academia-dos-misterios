---
titulo: "Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Suplicante de Segredos"
sequencia: 3
nome_pacote: "Pacote de Templário da Trindade — Suplicante de Segredos S3"
quantidade_tecnicas: 2
quantidade_capacidades: 1
quantidade_operacoes: 1
---

# Poder - Suplicante de Segredos S3 - Autoridade de Templário da Trindade

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Templário da Trindade, Suplicante de Segredos S3.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 3 - Suplicante de Segredos - Templário da Trindade]] ou melhor no [[Caminho do Suplicante de Segredos]]. **Referência nominal:** Trinity Templar. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Transformação de Templário da Trindade:** Pode sustentar três aspectos visuais, todos com uma só reserva de ações, PV e PM.

## Técnicas adquiridas

### Trindade manifesta

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND13 em obstáculo sem ficha |

Desloque seus aspectos entre três apoios conhecidos do mesmo local; um deles executa a ação a cada turno.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

### Carne reconstruída

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND13 em obstáculo sem ficha |

Restaure 30 PV seus ou de voluntário em contato; não restitui característica destruída ou identidade perdida.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

## Feito de operação

Distribuir e conter uma pressão espiritual entre receptáculos preparados sem criar matéria infinita.

**Procedimento:** [[Módulo dos santos]]. Reúna duas chaves, declare alvo, transformação e consequência do perigo. O portador inicia uma vez por cena, ação Poder, 20 PM e primeiro teste ND13; objetivo de 10 seções. Cada PJ contribui uma vez por rodada com Objetivo e margens normais, sem pagar novamente a taxa. Não use esse relógio para atrasar as aplicações locais sem oposição equivalente.

## Evolução e acúmulo

Conserva todos os pacotes anteriores. O novo grau amplia a natureza do que pode fazer, não soma automaticamente dano ou bônus de todas as formas. Capacidades de operação seguem seu módulo e Escala e confrontos sobrenaturais.

## Preparação e oposição

Purificação, recusa de pactos e exposição da fonte dos sussurros. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Suplicante de Segredos]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
