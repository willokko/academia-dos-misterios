---
titulo: "Sequência 2 - Suplicante de Segredos - Presbítero Profano"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
sequencia: 2
nome_ingles: "Profane Presbyter"
---

# Sequência 2 - Suplicante de Segredos - Presbítero Profano

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Suplicante de Segredos]]. **Sequência:** 2. **Nome de referência:** Profane Presbyter. Tradução editorial: Presbítero Profano.

## O que a poção transforma

O [[Poder - Suplicante de Segredos S2 - Autoridade de Presbítero Profano|pacote completo de Presbítero Profano]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Presbítero Profano.

- [[Poder - Suplicante de Segredos S2 - Autoridade de Presbítero Profano#Palavra de degeneração|Palavra de degeneração]]
- [[Poder - Suplicante de Segredos S2 - Autoridade de Presbítero Profano#Rebanho consagrado|Rebanho consagrado]]

Operação: [[Poder - Suplicante de Segredos S2 - Autoridade de Presbítero Profano#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Presbítero Profano** no tema de escuta perigosa, sombras, carne e almas. Princípio de partida: buscar conhecimento sem entregar a própria responsabilidade à voz que responde. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Suplicante de Segredos#S2 - Presbítero Profano]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Suplicante de Segredos - Templário da Trindade]]. Próxima: [[Sequência 1 - Suplicante de Segredos - Anjo Sombrio]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
