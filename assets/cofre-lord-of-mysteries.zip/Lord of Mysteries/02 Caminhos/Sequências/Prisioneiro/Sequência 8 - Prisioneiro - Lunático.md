---
titulo: "Sequência 8 - Prisioneiro - Lunático"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 8
nome_ingles: "Lunatic"
---

# Sequência 8 - Prisioneiro - Lunático

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 8. **Nome de referência:** Lunatic. Tradução editorial: Lunático.

## O que a poção transforma

O [[Poder - Prisioneiro S8 - Instinto contido|pacote completo de Lunático]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Maldição da lua.

- [[Poder - Prisioneiro S8 - Instinto contido#Frenesi|Frenesi]]
- [[Poder - Prisioneiro S8 - Instinto contido#Conter o frenesi|Conter o frenesi]]
- [[Poder - Prisioneiro S8 - Instinto contido#Investida brutal|Investida brutal]]



## Atuação e digestão

Interpretação original do papel **Lunático** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S8 - Lunático]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Prisioneiro - Prisioneiro]]. Próxima: [[Sequência 7 - Prisioneiro - Lobisomem]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
