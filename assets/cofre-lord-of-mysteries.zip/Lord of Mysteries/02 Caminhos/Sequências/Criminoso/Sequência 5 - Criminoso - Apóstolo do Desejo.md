---
titulo: "Sequência 5 - Criminoso - Apóstolo do Desejo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 5
nome_ingles: "Desire Apostle"
---

# Sequência 5 - Criminoso - Apóstolo do Desejo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 5. **Nome de referência:** Desire Apostle. Tradução editorial: Apóstolo do Desejo.

## O que a poção transforma

O [[Poder - Criminoso S5 - Desejo exposto|pacote completo de Apóstolo do Desejo]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Sinal do desejo.

- [[Poder - Criminoso S5 - Desejo exposto#Semente do desejo|Semente do desejo]]
- [[Poder - Criminoso S5 - Desejo exposto#Catalisar o desejo|Catalisar o desejo]]
- [[Poder - Criminoso S5 - Desejo exposto#Sombra de fuga|Sombra de fuga]]



## Atuação e digestão

Interpretação original do papel **Apóstolo do Desejo** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S5 - Apóstolo do Desejo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Criminoso - Diabo]]. Próxima: [[Sequência 4 - Criminoso - Demônio]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
