---
titulo: "Sequência 0 - Coletor de Cadáveres - Morte"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 0
nome_ingles: "Death"
---

# Sequência 0 - Coletor de Cadáveres - Morte

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 0. **Nome de referência:** Death. Tradução editorial: Morte.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S0 - Autoridade de Morte|pacote completo de Morte]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Morte.

- [[Poder - Coletor de Cadáveres S0 - Autoridade de Morte#Limiar soberano|Limiar soberano]]
- [[Poder - Coletor de Cadáveres S0 - Autoridade de Morte#Restituição divina|Restituição divina]]

Operação: [[Poder - Coletor de Cadáveres S0 - Autoridade de Morte#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Morte** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S0 - Morte]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Coletor de Cadáveres - Imperador Pálido]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
