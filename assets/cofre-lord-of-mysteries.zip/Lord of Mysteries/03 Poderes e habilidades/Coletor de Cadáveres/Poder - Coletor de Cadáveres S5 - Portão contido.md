---
titulo: "Poder - Coletor de Cadáveres S5 - Portão contido"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Coletor de Cadáveres"
sequencia: 5
nome_pacote: "Pacote de Guardião do Portão — Coletor de Cadáveres S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Coletor de Cadáveres S5 - Portão contido

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Guardião do Portão, Coletor de Cadáveres S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Coletor de Cadáveres - Guardião do Portão]] ou melhor no [[Caminho do Coletor de Cadáveres]]. **Referência nominal:** Gatekeeper. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Abrigo do portão:** Hospeda até três espíritos reais, uma técnica ativa de cada, um manifesto por vez; obrigações e características ficam registradas.

## Técnicas adquiridas

### Portão do submundo

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até romper ou fim da cena |
| Teste | AST+VON contra DEF.M |

Abra Arrastar 0/8 contra um alvo presente. Ao completar contra NPC de igual patamar ou menor, prende-o além do limiar até o fim da cena. Aliados podem romper o círculo com Objetivo 0/4; não é morte automática.

**Limites:** Um portão ativo; cada contribuição usa ação e 10 PM após a abertura. PJs usam a regra de agência.

### Manifestar o abrigado

| Parâmetro | Regra |
|---|---|
| Custo | PM da técnica; trocar custa 0 PM e ação |
| Ação | Conforme técnica |
| Alcance | Cena |
| Duração | Conforme técnica |
| Teste | Conforme técnica |

Use uma técnica do espírito manifesto com ação, atributos e PM seus. Trocar hóspede exige ação sem PM.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Fechar o limiar

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Uma passagem |
| Duração | Até o próximo turno |
| Teste | Automático |

Enquanto mantiver a ação de Guarda, impede espíritos de igual patamar ou menor de atravessar a passagem marcada sem teste oposto AST+VON.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 trata retorno após morte com perda e intervalo reais; não é reanimação gratuita por PM.

## Preparação e oposição

Purificação, restos sem identidade e espíritos sob domínio alheio. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Coletor de Cadáveres]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
