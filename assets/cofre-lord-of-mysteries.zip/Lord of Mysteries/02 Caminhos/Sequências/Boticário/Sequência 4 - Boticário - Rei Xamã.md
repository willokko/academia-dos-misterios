---
titulo: "Sequência 4 - Boticário - Rei Xamã"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 4
nome_ingles: "Shaman King"
---

# Sequência 4 - Boticário - Rei Xamã

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 4. **Nome de referência:** Shaman King. Tradução editorial: Rei Xamã.

## O que a poção transforma

O [[Poder - Boticário S4 - Autoridade de Rei Xamã|pacote completo de Rei Xamã]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Rei Xamã.

- [[Poder - Boticário S4 - Autoridade de Rei Xamã#Círculo xamânico|Círculo xamânico]]
- [[Poder - Boticário S4 - Autoridade de Rei Xamã#Luar de contenção|Luar de contenção]]

Operação: [[Poder - Boticário S4 - Autoridade de Rei Xamã#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Rei Xamã** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S4 - Rei Xamã]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Boticário - Erudito Escarlate]]. Próxima: [[Sequência 3 - Boticário - Alto Invocador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
