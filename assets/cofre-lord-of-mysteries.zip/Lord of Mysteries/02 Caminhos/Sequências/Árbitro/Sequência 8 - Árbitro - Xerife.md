---
titulo: "Sequência 8 - Árbitro - Xerife"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 8
nome_ingles: "Sheriff"
---

# Sequência 8 - Árbitro - Xerife

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 8. **Nome de referência:** Sheriff. Tradução editorial: Xerife.

## O que a poção transforma

O [[Poder - Árbitro S8 - Olhar do xerife|pacote completo de Xerife]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Percepção do xerife.

- [[Poder - Árbitro S8 - Olhar do xerife#Reconstituir infração|Reconstituir infração]]
- [[Poder - Árbitro S8 - Olhar do xerife#Perseguição|Perseguição]]
- [[Poder - Árbitro S8 - Olhar do xerife#Contenção policial|Contenção policial]]



## Atuação e digestão

Interpretação original do papel **Xerife** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S8 - Xerife]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Árbitro - Árbitro]]. Próxima: [[Sequência 7 - Árbitro - Interrogador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
