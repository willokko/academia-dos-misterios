---
titulo: "Sequência 1 - Espreitador de Mistérios - Imperador do Conhecimento"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
sequencia: 1
nome_ingles: "Knowledge Emperor"
---

# Sequência 1 - Espreitador de Mistérios - Imperador do Conhecimento

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espreitador de Mistérios]]. **Sequência:** 1. **Nome de referência:** Knowledge Emperor. Tradução editorial: Imperador do Conhecimento.

## O que a poção transforma

O [[Poder - Espreitador de Mistérios S1 - Autoridade de Imperador do Conhecimento|pacote completo de Imperador do Conhecimento]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Imperador do Conhecimento.

- [[Poder - Espreitador de Mistérios S1 - Autoridade de Imperador do Conhecimento#Coroa de conhecimento|Coroa de conhecimento]]
- [[Poder - Espreitador de Mistérios S1 - Autoridade de Imperador do Conhecimento#Inscrição de autoridade|Inscrição de autoridade]]

Operação: [[Poder - Espreitador de Mistérios S1 - Autoridade de Imperador do Conhecimento#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Imperador do Conhecimento** no tema de conhecimento oculto, símbolos e histórias com poder. Princípio de partida: investigar sem confundir curiosidade com direito a toda resposta. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espreitador de Mistérios#S1 - Imperador do Conhecimento]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Espreitador de Mistérios - Sábio Místico]]. Próxima: [[Sequência 0 - Espreitador de Mistérios - Eremita]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
