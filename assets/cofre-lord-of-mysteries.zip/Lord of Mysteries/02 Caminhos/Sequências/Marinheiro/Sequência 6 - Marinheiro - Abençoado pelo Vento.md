---
titulo: "Sequência 6 - Marinheiro - Abençoado pelo Vento"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 6
nome_ingles: "Wind-blessed"
---

# Sequência 6 - Marinheiro - Abençoado pelo Vento

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 6. **Nome de referência:** Wind-blessed. Tradução editorial: Abençoado pelo Vento.

## O que a poção transforma

O [[Poder - Marinheiro S6 - Passagem do vento|pacote completo de Abençoado pelo Vento]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Afinidade aérea; Brisa manipulada.

- [[Poder - Marinheiro S6 - Passagem do vento#Voo do vendaval|Voo do vendaval]]
- [[Poder - Marinheiro S6 - Passagem do vento#Lâmina de vento|Lâmina de vento]]
- [[Poder - Marinheiro S6 - Passagem do vento#Parede de vento|Parede de vento]]



## Atuação e digestão

Interpretação original do papel **Abençoado pelo Vento** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S6 - Abençoado pelo Vento]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Marinheiro - Navegante]]. Próxima: [[Sequência 5 - Marinheiro - Cantor do Oceano]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
