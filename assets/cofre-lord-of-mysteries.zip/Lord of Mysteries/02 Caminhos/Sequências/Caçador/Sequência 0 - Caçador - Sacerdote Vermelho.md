---
titulo: "Sequência 0 - Caçador - Sacerdote Vermelho"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
sequencia: 0
nome_ingles: "Red Priest"
---

# Sequência 0 - Caçador - Sacerdote Vermelho

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Caçador]]. **Sequência:** 0. **Nome de referência:** Red Priest. Tradução editorial: Sacerdote Vermelho.

## O que a poção transforma

O [[Poder - Caçador S0 - Autoridade de Sacerdote Vermelho|pacote completo de Sacerdote Vermelho]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Sacerdote Vermelho.

- [[Poder - Caçador S0 - Autoridade de Sacerdote Vermelho#Corpo da guerra|Corpo da guerra]]
- [[Poder - Caçador S0 - Autoridade de Sacerdote Vermelho#Ordem de destruição|Ordem de destruição]]

Operação: [[Poder - Caçador S0 - Autoridade de Sacerdote Vermelho#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Sacerdote Vermelho** no tema de rastreio, provocação, fogo e guerra. Princípio de partida: conhecer a presa sem reduzir toda relação a caça. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Caçador#S0 - Sacerdote Vermelho]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Caçador - Conquistador]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
