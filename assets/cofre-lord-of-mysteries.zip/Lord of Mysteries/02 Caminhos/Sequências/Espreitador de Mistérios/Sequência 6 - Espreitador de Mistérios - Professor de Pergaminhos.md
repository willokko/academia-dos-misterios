---
titulo: "Sequência 6 - Espreitador de Mistérios - Professor de Pergaminhos"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
sequencia: 6
nome_ingles: "Scrolls Professor"
---

# Sequência 6 - Espreitador de Mistérios - Professor de Pergaminhos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espreitador de Mistérios]]. **Sequência:** 6. **Nome de referência:** Scrolls Professor. Tradução editorial: Professor de Pergaminhos.

## O que a poção transforma

O [[Poder - Espreitador de Mistérios S6 - Pergaminho preparado|pacote completo de Professor de Pergaminhos]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Professor de pergaminhos.

- [[Poder - Espreitador de Mistérios S6 - Pergaminho preparado#Inscrever pergaminho|Inscrever pergaminho]]
- [[Poder - Espreitador de Mistérios S6 - Pergaminho preparado#Liberar pergaminho|Liberar pergaminho]]
- [[Poder - Espreitador de Mistérios S6 - Pergaminho preparado#Voz secreta|Voz secreta]]



## Atuação e digestão

Interpretação original do papel **Professor de Pergaminhos** no tema de conhecimento oculto, símbolos e histórias com poder. Princípio de partida: investigar sem confundir curiosidade com direito a toda resposta. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espreitador de Mistérios#S6 - Professor de Pergaminhos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Espreitador de Mistérios - Bruxo]]. Próxima: [[Sequência 5 - Espreitador de Mistérios - Mestre das Constelações]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
