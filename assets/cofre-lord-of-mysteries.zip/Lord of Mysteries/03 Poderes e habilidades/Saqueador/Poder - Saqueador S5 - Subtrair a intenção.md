---
titulo: "Poder - Saqueador S5 - Subtrair a intenção"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Saqueador"
sequencia: 5
nome_pacote: "Pacote de Ladrão de Sonhos — Saqueador S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Saqueador S5 - Subtrair a intenção

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Ladrão de Sonhos, Saqueador S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Saqueador - Ladrão de Sonhos]] ou melhor no [[Caminho do Saqueador]]. **Referência nominal:** Dream Stealer. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Intenção imediata:** Pode perceber o começo de um gesto ou impulso manifestado; não conhece planos inteiros.

## Técnicas adquiridas

### Subtrair intenção

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Uma ação |
| Teste | AST+VON contra DEF.M |

Antes do teste de um alvo, em sucesso ele perde aquela intenção: NPC escolhe outra ação; PJ escolhe mudar a abordagem ou sofrer -2. Não perde o turno inteiro.

**Limites:** Uma reação por rodada; uma tentativa por alvo por cena.

### Roubar um ataque

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Um ataque |
| Teste | AST+VON contra DEF.M |

Antes de rolar um ataque contra você, conteste: em sucesso o ataque contra você se dispersa. Não o devolve nem remove outros alvos; falha gasta PM.

**Limites:** Uma reação por rodada e uma defesa deste tipo por cena. Autoridade superior exige brecha.

### Tomar uma faculdade

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o fim do próximo turno do alvo |
| Teste | AST+VON contra DEF.M |

Suprima uma faculdade específica: caminhar causa lento; falar impede um idioma escolhido. Nunca retira inteligência, nível ou características.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 desenvolve parasitismo; não recebe outra vida por copiar uma técnica.

## Preparação e oposição

Vigilância cruzada, vínculos protegidos e ações sem habilidade ativa. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Saqueador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
