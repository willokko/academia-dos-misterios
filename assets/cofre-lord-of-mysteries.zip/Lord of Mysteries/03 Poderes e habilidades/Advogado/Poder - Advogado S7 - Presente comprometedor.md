---
titulo: "Poder - Advogado S7 - Presente comprometedor"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Advogado"
sequencia: 7
nome_pacote: "Pacote de Subornador — Advogado S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Advogado S7 - Presente comprometedor

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Subornador, Advogado S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Advogado - Subornador]] ou melhor no [[Caminho do Advogado]]. **Referência nominal:** Briber. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Conexão de suborno:** Uma oferta real ou simbólica permite tentar criar vínculo com alvo presente. Não exige que o alvo aceite compra moral; o efeito é sobrenatural e resistível.

## Técnicas adquiridas

### Suborno enfraquecedor

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o próximo turno |
| Teste | AST+VON contra DEF.M |

Ofereça objeto ou valor simbólico disponível. Em sucesso, o alvo causa -5 dano contra você até o fim do próximo turno dele.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Suborno da arrogância

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica atordoado e o alvo desconsidera uma precaução pequena que tinha manifestado, sem mudar seus objetivos inteiros.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

### Suborno de conexão

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON contra DEF.M |

Crie ligação que permite reconhecer a presença do alvo no mesmo recinto pela cena; não o localiza em outro país ou atravessa ocultação.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 usa a brecha e ligação para distorcer atos concretos; não precisa fingir que é só negociação mundana.

## Preparação e oposição

Termos claros, ausência de troca aceita e jurisdição rival. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Advogado]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
