---
titulo: "Caminho do Saqueador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
nome_divino: "Erro"
referencia: "https://lordofthemysteries.fandom.com/wiki/Error_Pathway"
---

# Caminho do Saqueador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Erro. **Tema:** Subtração, engano e brechas de identidade. **Função:** Infiltração, interrupção e informação.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Saqueador - Saqueador|Saqueador]] | [[Poder - Saqueador S9 - Mãos do intervalo|3 técnicas]] |
| 8 | [[Sequência 8 - Saqueador - Vigarista|Vigarista]] | [[Poder - Saqueador S8 - Proposta enviesada|3 técnicas]] |
| 7 | [[Sequência 7 - Saqueador - Criptologista|Criptologista]] | [[Poder - Saqueador S7 - Chave de leitura|3 técnicas]] |
| 6 | [[Sequência 6 - Saqueador - Prometeu|Prometeu]] | [[Poder - Saqueador S6 - Furto de chama|3 técnicas]] |
| 5 | [[Sequência 5 - Saqueador - Ladrão de Sonhos|Ladrão de Sonhos]] | [[Poder - Saqueador S5 - Subtrair a intenção|3 técnicas]] |
| 4 | [[Sequência 4 - Saqueador - Parasita|Parasita]] | [[Poder - Saqueador S4 - Autoridade de Parasita|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Saqueador - Mentor do Engano|Mentor do Engano]] | [[Poder - Saqueador S3 - Autoridade de Mentor do Engano|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Saqueador - Cavalo de Troia do Destino|Cavalo de Troia do Destino]] | [[Poder - Saqueador S2 - Autoridade de Cavalo de Troia do Destino|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Saqueador - Verme do Tempo|Verme do Tempo]] | [[Poder - Saqueador S1 - Autoridade de Verme do Tempo|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Saqueador - Erro|Erro]] | [[Poder - Saqueador S0 - Autoridade de Erro|2 técnicas + operação]] |

## Como jogar

Encontrar uma brecha e reconhecer aquilo que não se pode tomar. As ferramentas da S9 são olho para o valioso. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Muito alta: roubo e cópia. **Oposição:** Vigilância cruzada, vínculos protegidos e ações sem habilidade ativa. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Saqueador]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Error_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
