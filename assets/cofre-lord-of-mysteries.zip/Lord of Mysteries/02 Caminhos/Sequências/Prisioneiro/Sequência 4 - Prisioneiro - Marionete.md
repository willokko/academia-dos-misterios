---
titulo: "Sequência 4 - Prisioneiro - Marionete"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 4
nome_ingles: "Puppet"
---

# Sequência 4 - Prisioneiro - Marionete

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 4. **Nome de referência:** Puppet. Tradução editorial: Marionete.

## O que a poção transforma

O [[Poder - Prisioneiro S4 - Autoridade de Marionete|pacote completo de Marionete]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Marionete.

- [[Poder - Prisioneiro S4 - Autoridade de Marionete#Corpo de marionete|Corpo de marionete]]
- [[Poder - Prisioneiro S4 - Autoridade de Marionete#Maldição de objeto|Maldição de objeto]]

Operação: [[Poder - Prisioneiro S4 - Autoridade de Marionete#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Marionete** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S4 - Marionete]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Prisioneiro - Espectro]]. Próxima: [[Sequência 3 - Prisioneiro - Discípulo do Silêncio]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
