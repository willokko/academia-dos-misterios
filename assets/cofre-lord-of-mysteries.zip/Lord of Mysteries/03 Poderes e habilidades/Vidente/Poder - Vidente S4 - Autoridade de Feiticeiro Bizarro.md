---
titulo: "Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Vidente"
sequencia: 4
nome_pacote: "Pacote de Feiticeiro Bizarro — Vidente S4"
quantidade_tecnicas: 2
quantidade_capacidades: 1
quantidade_operacoes: 1
---

# Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Feiticeiro Bizarro, Vidente S4.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 4 - Vidente - Feiticeiro Bizarro]] ou melhor no [[Caminho do Vidente]]. **Referência nominal:** Bizarro Sorcerer. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Transformação de Feiticeiro Bizarro:** Rede de marionetes: mantém seis vínculos S9–5, apenas um operador mecânico por ação.

## Técnicas adquiridas

### Troca pelos fios

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Reação antes da rolagem de ataque |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Instantânea |
| Teste | Automático com vínculo desimpedido; oposição espacial exige AST+VON contra DEF.M |

Antes de um ataque ser rolado contra você, troque posição com marionete vinculada na cena. Ela torna-se o alvo e sofre o ataque normalmente. Não cancela um dano já resolvido.

**Limites:** Uma reação de Caminho por rodada; não atravessa selo que bloqueie o vínculo. Perder o corpo ou sua característica continua uma consequência real.

### Espírito partilhado

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND13 em obstáculo sem ficha |

Uma marionete vinculada pode executar uma técnica sua S9–5 pela sua ação, PM e atributos.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

## Feito de operação

Substituir uma rede de perseguidores por uma rede de marionetes para retirar um grupo de um cerco.

**Procedimento:** [[Módulo dos santos]]. Reúna duas chaves, declare alvo, transformação e consequência do perigo. O portador inicia uma vez por cena, ação Poder, 20 PM e primeiro teste ND13; objetivo de 8 seções. Cada PJ contribui uma vez por rodada com Objetivo e margens normais, sem pagar novamente a taxa. Não use esse relógio para atrasar as aplicações locais sem oposição equivalente.

## Evolução e acúmulo

Conserva todos os pacotes anteriores. O novo grau amplia a natureza do que pode fazer, não soma automaticamente dano ou bônus de todas as formas. Capacidades de operação seguem seu módulo e Escala e confrontos sobrenaturais.

## Preparação e oposição

Ocultação de vínculos, identidades verificadas por relações e interrupção de preparação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Vidente]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
