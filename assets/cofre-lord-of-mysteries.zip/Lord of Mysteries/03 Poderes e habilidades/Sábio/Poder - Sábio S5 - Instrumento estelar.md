---
titulo: "Poder - Sábio S5 - Instrumento estelar"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Sábio"
sequencia: 5
nome_pacote: "Pacote de Astrônomo — Sábio S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Sábio S5 - Instrumento estelar

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Astrônomo, Sábio S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Sábio - Astrônomo]] ou melhor no [[Caminho do Sábio]]. **Referência nominal:** Astronomer. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Astronomia aplicada:** Pode criar cartas de posição e instrumentos calibrados, relacionando céu observado a trajetórias e referências.

## Técnicas adquiridas

### Cálculo celeste

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Com céu ou instrumento apropriado, descubra interferência num trajeto conhecido e um parâmetro para corrigi-la. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Lente de projeção

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um instrumento previamente construído libera energia: RA+25 luz num alvo. Sem instrumento, esta técnica não cria um raio do nada.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Rede de instrumentos

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | Automático |

Até três equipamentos próprios calibrados fornecem +2 a um único Objetivo coletivo de observação, navegação ou comunicação na cena.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 amplia alquimia e S3 construções arcanas; objetos continuam obedecendo conservação de características.

## Preparação e oposição

Materiais escassos, falta de oficina e defeitos conhecidos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Sábio]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
