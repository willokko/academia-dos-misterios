---
titulo: "Poder - Monstro S1 - Autoridade de Serpente de Mercúrio"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Monstro"
sequencia: 1
nome_pacote: "Pacote de Serpente de Mercúrio — Monstro S1"
quantidade_tecnicas: 2
quantidade_capacidades: 1
quantidade_operacoes: 1
---

# Poder - Monstro S1 - Autoridade de Serpente de Mercúrio

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Serpente de Mercúrio, Monstro S1.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 1 - Monstro - Serpente de Mercúrio]] ou melhor no [[Caminho do Monstro]]. **Referência nominal:** Snake of Mercury. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Transformação de Serpente de Mercúrio:** Retorno cíclico conserva uma identidade ameaçada; não é uma recarga infinita de sessões ou características.

## Técnicas adquiridas

### Marca do ciclo

| Parâmetro | Regra |
|---|---|
| Custo | 40 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND16 em obstáculo sem ficha |

Registre um estado de uma estrutura própria. Pode restaurá-lo nesta cena se matéria e característica ainda existirem.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

### Recomeço pessoal

| Parâmetro | Regra |
|---|---|
| Custo | 40 PM |
| Ação | Início de operação de Restituição |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Até encerrar a operação |
| Teste | Contribuições de Objetivo ND16; aliado iniciador paga a taxa quando o portador já morreu |

Após morte, com âncora e vestígio intactos, inicie Restituição uma vez por arco. O retorno exige operação e produz perda de uma memória acordada.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

## Feito de operação

Reiniciar uma condição delimitada de crise sem apagar as decisões e vínculos protegidos dos outros jogadores.

**Procedimento:** [[Módulo angelical e divino]]. Reúna três chaves, declare alvo, transformação e consequência do perigo. O portador inicia uma vez por operação, ação Poder, 40 PM e primeiro teste ND16; objetivo de 14 seções. Cada PJ contribui uma vez por rodada com Objetivo e margens normais, sem pagar novamente a taxa. Não use esse relógio para atrasar as aplicações locais sem oposição equivalente.

## Evolução e acúmulo

Conserva todos os pacotes anteriores. O novo grau amplia a natureza do que pode fazer, não soma automaticamente dano ou bônus de todas as formas. Capacidades de operação seguem seu módulo e Escala e confrontos sobrenaturais.

## Preparação e oposição

Consequências sem teste, escolhas comprometidas e vínculos opacos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Monstro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
