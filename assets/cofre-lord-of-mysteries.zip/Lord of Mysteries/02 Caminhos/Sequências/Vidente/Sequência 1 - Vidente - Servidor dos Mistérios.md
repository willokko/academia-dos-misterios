---
titulo: "Sequência 1 - Vidente - Servidor dos Mistérios"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 1
nome_ingles: "Attendant of Mysteries"
---

# Sequência 1 - Vidente - Servidor dos Mistérios

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 1. **Nome de referência:** Attendant of Mysteries. Tradução editorial: Servidor dos Mistérios.

## O que a poção transforma

O [[Poder - Vidente S1 - Autoridade de Servidor dos Mistérios|pacote completo de Servidor dos Mistérios]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Servidor dos Mistérios.

- [[Poder - Vidente S1 - Autoridade de Servidor dos Mistérios#Enxerto de posições|Enxerto de posições]]
- [[Poder - Vidente S1 - Autoridade de Servidor dos Mistérios#Enxerto de efeito|Enxerto de efeito]]

Operação: [[Poder - Vidente S1 - Autoridade de Servidor dos Mistérios#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Servidor dos Mistérios** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S1 - Servidor dos Mistérios]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Vidente - Invocador de Milagres]]. Próxima: [[Sequência 0 - Vidente - Louco]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
