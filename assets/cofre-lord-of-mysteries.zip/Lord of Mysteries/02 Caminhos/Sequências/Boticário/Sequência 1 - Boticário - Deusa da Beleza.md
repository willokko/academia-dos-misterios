---
titulo: "Sequência 1 - Boticário - Deusa da Beleza"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 1
nome_ingles: "Beauty Goddess"
---

# Sequência 1 - Boticário - Deusa da Beleza

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 1. **Nome de referência:** Beauty Goddess. Tradução editorial: Deusa da Beleza.

## O que a poção transforma

O [[Poder - Boticário S1 - Autoridade de Deusa da Beleza|pacote completo de Deusa da Beleza]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Deusa da Beleza.

- [[Poder - Boticário S1 - Autoridade de Deusa da Beleza#Presença lunar|Presença lunar]]
- [[Poder - Boticário S1 - Autoridade de Deusa da Beleza#Imagem ideal|Imagem ideal]]

Operação: [[Poder - Boticário S1 - Autoridade de Deusa da Beleza#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Deusa da Beleza** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S1 - Deusa da Beleza]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Boticário - Doador de Vida]]. Próxima: [[Sequência 0 - Boticário - Lua]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
