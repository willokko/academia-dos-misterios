---
titulo: "Poder - Prisioneiro S8 - Instinto contido"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Prisioneiro"
sequencia: 8
nome_pacote: "Pacote de Lunático — Prisioneiro S8"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Prisioneiro S8 - Instinto contido

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Lunático, Prisioneiro S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Prisioneiro - Lunático]] ou melhor no [[Caminho do Prisioneiro]]. **Referência nominal:** Lunatic. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Maldição da lua:** Nas noites de lua cheia, surge um impulso anunciado. Prepare contenção, tratamento ou aceite a escolha de custo da nota Maldições e humanidade. Não acumula maldições de todos os graus.

## Técnicas adquiridas

### Frenesi

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um acerto ou próximo turno |
| Teste | Automático |

Até seu próximo turno, +5 ao dano de um golpe corporal e -2 DEF. Não ganha ação adicional.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Conter o frenesi

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Instantânea |
| Teste | Automático |

Reduza a pressão de uma maldição nesta cena: você aceita lento por um turno ou gasta 10 PM, sem marcar Corrupção só por resistir ao papel.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Investida brutal

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Corpo a corpo |
| Duração | Instantânea |
| Teste | VIG+VIG contra DEF |

Um alvo sofre RA+15 de dano físico em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S7 substitui a maldição pela condição de lobisomem; a lista não cresce como pilha de penalidades.

## Preparação e oposição

Recipientes preparados, purificação e reconhecimento da âncora. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Prisioneiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
