---
titulo: "Sequência 2 - Bardo - Buscador da Luz"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 2
nome_ingles: "Lightseeker"
---

# Sequência 2 - Bardo - Buscador da Luz

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 2. **Nome de referência:** Lightseeker. Tradução editorial: Buscador da Luz.

## O que a poção transforma

O [[Poder - Bardo S2 - Autoridade de Buscador da Luz|pacote completo de Buscador da Luz]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Buscador da Luz.

- [[Poder - Bardo S2 - Autoridade de Buscador da Luz#Passagem luminosa|Passagem luminosa]]
- [[Poder - Bardo S2 - Autoridade de Buscador da Luz#Sol de proteção|Sol de proteção]]

Operação: [[Poder - Bardo S2 - Autoridade de Buscador da Luz#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Buscador da Luz** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S2 - Buscador da Luz]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Bardo - Mentor da Justiça]]. Próxima: [[Sequência 1 - Bardo - Anjo Branco]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
