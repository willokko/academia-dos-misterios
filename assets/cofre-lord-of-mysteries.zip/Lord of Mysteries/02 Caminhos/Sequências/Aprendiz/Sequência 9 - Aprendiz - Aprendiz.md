---
titulo: "Sequência 9 - Aprendiz - Aprendiz"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 9
nome_ingles: "Apprentice"
---

# Sequência 9 - Aprendiz - Aprendiz

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 9. **Nome de referência:** Apprentice. Tradução editorial: Aprendiz.

## O que a poção transforma

O [[Poder - Aprendiz S9 - Porta simbólica|pacote completo de Aprendiz]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Sentido de passagem.

- [[Poder - Aprendiz S9 - Porta simbólica#Abrir passagem|Abrir passagem]]
- [[Poder - Aprendiz S9 - Porta simbólica#Examinar o limiar|Examinar o limiar]]
- [[Poder - Aprendiz S9 - Porta simbólica#Fuga por fresta|Fuga por fresta]]



## Atuação e digestão

Interpretação original do papel **Aprendiz** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S9 - Aprendiz]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Aprendiz - Mestre dos Truques]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
