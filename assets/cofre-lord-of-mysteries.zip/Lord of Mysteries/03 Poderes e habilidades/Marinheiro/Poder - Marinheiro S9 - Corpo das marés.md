---
titulo: "Poder - Marinheiro S9 - Corpo das marés"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Marinheiro"
sequencia: 9
nome_pacote: "Pacote de Marinheiro — Marinheiro S9"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Marinheiro S9 - Corpo das marés

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Marinheiro, Marinheiro S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Marinheiro - Marinheiro]] ou melhor no [[Caminho do Marinheiro]]. **Referência nominal:** Sailor. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Corpo aquático:** Nade com destreza, fique submerso por dez minutos e mergulhe até 15 m sem equipamento em água ordinária. Perigos maiores continuam existindo.
- **Equilíbrio naval e escamas:** Não testa para andar num convés ordinário oscilante. +2 para resistir a agarrão físico; não concede defesa universal.

## Técnicas adquiridas

### Resgate das marés

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | DES+VIG ND10 em correnteza; automático em água calma |

Transporte uma pessoa voluntária ou inconsciente pela água até apoio na mesma cena, sem perder sua capacidade de respirar. A técnica não faz o alvo respirar água.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Golpe de marujo

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Corpo a corpo |
| Duração | Instantânea |
| Teste | DES+VIG contra DEF |

Um alvo sofre RA+10 de dano físico em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Firmar o convés

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Você e um aliado |
| Duração | Próximo teste na cena |
| Teste | Automático |

Você e um aliado próximo recebem +2 no próximo Objetivo para resistir a queda, onda ou inclinação. Cada qual ainda usa sua ação.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S7 aumenta o tempo submerso para trinta minutos e permite orientar o grupo no mar. S5 permite respiração aquática contínua em água ordinária.

## Preparação e oposição

Locais sem acesso aéreo/aquático, preparação interrompida e proteção elemental. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Marinheiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
