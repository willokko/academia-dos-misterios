---
titulo: "Avanço e consumo"
tipo: "poções-e-avanço"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Avanço e consumo

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

## Antes de beber

Registre nível mínimo de [[Progressão e Sequências]], digestão, fórmula, materiais, origem da característica, Corrupção atual e rito do dossiê de Caminho. Um auxílio prometido por uma entidade não conta como obtido até ocorrer na ficção. Avanços convencionais são marcos preparados pelo grupo, não testes competitivos entre jogadores.

Com digestão completa, Corrupção 0–2, fórmula íntegra, materiais preparados e rito satisfeito, o consumo é estável e dispensa teste nas S9–5. Avance a Sequência e zere o novo relógio de Digestão. O risco esteve em conseguir as condições; não coloque uma morte aleatória depois de um arco bem resolvido.

## Avanço arriscado

Pode tentar faltando digestão ou com Corrupção 3–5, mas não sem nível, característica, fórmula ou rito. Role VIG+VON. ND base 10, +3 por cada fator: digestão incompleta; Corrupção 3+; característica contaminada/impressão ativa. Máximo ND16; se existirem três fatores, primeiro resolva um deles. Não troque rito ausente por aumento de ND.

Sucesso: avança e sofre +1 Corrupção por fator de risco, no máximo +2. Falha: não avança, recebe +2 Corrupção; a característica permanece num precipitado recuperável, e os auxiliares são perdidos. A dose não pode ser tentada de novo na mesma cena. Falha crítica: a mesma falha mais início imediato de [[Perda de controle]]. O Ponto de Fabula por falha crítica continua sendo recebido.

Nas S4–0, mesmo preparo íntegro exige um projeto de estabilização conforme o módulo. O teste final usa ND13 nos santos e ND16 nos anjos/divindades; os preparos do módulo e cooperação importam. Falhar nunca cria uma segunda cópia da característica.

## Ritual desconhecido

Cada dossiê marca explicitamente o que foi verificado. Onde a pesquisa não bastou, há uma **prova original opcional** para esta campanha. Ao escolher essa alternativa, registre que a mesa adotou um substituto de cenário; não finja que é o ritual do romance. [[Registro de decisões]] explica a política.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
