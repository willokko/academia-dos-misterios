---
titulo: "Sequência 9 - Assassino - Assassino"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 9
nome_ingles: "Assassin"
---

# Sequência 9 - Assassino - Assassino

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 9. **Nome de referência:** Assassin. Tradução editorial: Assassino.

## O que a poção transforma

O [[Poder - Assassino S9 - Passo de emboscada|pacote completo de Assassino]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Passo do assassino.

- [[Poder - Assassino S9 - Passo de emboscada#Preparar emboscada|Preparar emboscada]]
- [[Poder - Assassino S9 - Passo de emboscada#Queda da pena|Queda da pena]]
- [[Poder - Assassino S9 - Passo de emboscada#Estudar a presa|Estudar a presa]]



## Atuação e digestão

Interpretação original do papel **Assassino** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S9 - Assassino]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Assassino - Instigador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
