---
titulo: "Caminho do Caçador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
nome_divino: "Sacerdote Vermelho"
referencia: "https://lordofthemysteries.fandom.com/wiki/Red_Priest_Pathway"
---

# Caminho do Caçador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Sacerdote Vermelho. **Tema:** Rastreio, provocação, fogo e guerra. **Função:** Pressão ofensiva e coordenação.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Caçador - Caçador|Caçador]] | [[Poder - Caçador S9 - Rastro escolhido|3 técnicas]] |
| 8 | [[Sequência 8 - Caçador - Provocador|Provocador]] | [[Poder - Caçador S8 - Provocação calculada|3 técnicas]] |
| 7 | [[Sequência 7 - Caçador - Piromaníaco|Piromaníaco]] | [[Poder - Caçador S7 - Lança de brasa|3 técnicas]] |
| 6 | [[Sequência 6 - Caçador - Conspirador|Conspirador]] | [[Poder - Caçador S6 - Plano em camadas|3 técnicas]] |
| 5 | [[Sequência 5 - Caçador - Ceifador|Ceifador]] | [[Poder - Caçador S5 - Golpe na abertura|3 técnicas]] |
| 4 | [[Sequência 4 - Caçador - Cavaleiro de Sangue e Ferro|Cavaleiro de Sangue e Ferro]] | [[Poder - Caçador S4 - Autoridade de Cavaleiro de Sangue e Ferro|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Caçador - Bispo da Guerra|Bispo da Guerra]] | [[Poder - Caçador S3 - Autoridade de Bispo da Guerra|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Caçador - Feiticeiro do Clima|Feiticeiro do Clima]] | [[Poder - Caçador S2 - Autoridade de Feiticeiro do Clima|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Caçador - Conquistador|Conquistador]] | [[Poder - Caçador S1 - Autoridade de Conquistador|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Caçador - Sacerdote Vermelho|Sacerdote Vermelho]] | [[Poder - Caçador S0 - Autoridade de Sacerdote Vermelho|2 técnicas + operação]] |

## Como jogar

Conhecer a presa sem reduzir toda relação a caça. As ferramentas da S9 são sentidos de caça. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Média: conspiração e tropas. **Oposição:** Terreno estudado pelo oponente, objetivos múltiplos e proteção contra fogo. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Caçador]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Red_Priest_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
