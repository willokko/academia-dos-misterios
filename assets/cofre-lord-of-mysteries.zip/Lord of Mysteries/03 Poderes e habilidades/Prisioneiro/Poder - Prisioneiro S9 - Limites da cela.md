---
titulo: "Poder - Prisioneiro S9 - Limites da cela"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Prisioneiro"
sequencia: 9
nome_pacote: "Pacote de Prisioneiro — Prisioneiro S9"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Prisioneiro S9 - Limites da cela

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Prisioneiro, Prisioneiro S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Prisioneiro - Prisioneiro]] ou melhor no [[Caminho do Prisioneiro]]. **Referência nominal:** Prisoner. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Corpo encarcerado:** +2 para resistir a contenções físicas e suportar esforço em ambiente apertado. Não concede imunidade a controle mental.

## Técnicas adquiridas

### Romper grilhões

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | VIG+VIG ND10 ou oposição |

Quebre ou afrouxe amarras ordinárias; contra contenção sobrenatural, contribua num Objetivo existente com VIG+VIG.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Violência contida

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Corpo a corpo |
| Duração | Instantânea |
| Teste | VIG+VIG contra DEF |

Um alvo sofre RA+10 de dano físico em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Disciplina do limite

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

+2 no próximo teste contra impulso sobrenatural identificado; não remove a fonte.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S8 traz frenesi; a maldição não obriga o jogador a atacar seu grupo.

## Preparação e oposição

Recipientes preparados, purificação e reconhecimento da âncora. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Prisioneiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
