---
titulo: "Caminho do Advogado"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
nome_divino: "Imperador Negro"
referencia: "https://lordofthemysteries.fandom.com/wiki/Black_Emperor_Pathway"
---

# Caminho do Advogado

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Imperador Negro. **Tema:** Brechas, suborno e distorção de regras. **Função:** Negociação e interferência contextual.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Advogado - Advogado|Advogado]] | [[Poder - Advogado S9 - Brecha contratual|3 técnicas]] |
| 8 | [[Sequência 8 - Advogado - Bárbaro|Bárbaro]] | [[Poder - Advogado S8 - Autoridade da força|3 técnicas]] |
| 7 | [[Sequência 7 - Advogado - Subornador|Subornador]] | [[Poder - Advogado S7 - Presente comprometedor|3 técnicas]] |
| 6 | [[Sequência 6 - Advogado - Barão da Corrupção|Barão da Corrupção]] | [[Poder - Advogado S6 - Distorção de percurso|3 técnicas]] |
| 5 | [[Sequência 5 - Advogado - Mentor da Desordem|Mentor da Desordem]] | [[Poder - Advogado S5 - Desordem focal|3 técnicas]] |
| 4 | [[Sequência 4 - Advogado - Conde dos Caídos|Conde dos Caídos]] | [[Poder - Advogado S4 - Autoridade de Conde dos Caídos|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Advogado - Mago Frenético|Mago Frenético]] | [[Poder - Advogado S3 - Autoridade de Mago Frenético|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Advogado - Duque da Entropia|Duque da Entropia]] | [[Poder - Advogado S2 - Autoridade de Duque da Entropia|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Advogado - Príncipe da Abolição|Príncipe da Abolição]] | [[Poder - Advogado S1 - Autoridade de Príncipe da Abolição|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Advogado - Imperador Negro|Imperador Negro]] | [[Poder - Advogado S0 - Autoridade de Imperador Negro|2 técnicas + operação]] |

## Como jogar

Conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. As ferramentas da S9 são brecha nas regras. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Muito alta: linguagem e leis. **Oposição:** Termos claros, ausência de troca aceita e jurisdição rival. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Advogado]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Black_Emperor_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
