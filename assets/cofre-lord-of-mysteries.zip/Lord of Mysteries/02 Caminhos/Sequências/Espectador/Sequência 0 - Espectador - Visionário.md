---
titulo: "Sequência 0 - Espectador - Visionário"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 0
nome_ingles: "Visionary"
---

# Sequência 0 - Espectador - Visionário

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 0. **Nome de referência:** Visionary. Tradução editorial: Visionário.

## O que a poção transforma

O [[Poder - Espectador S0 - Autoridade de Visionário|pacote completo de Visionário]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Visionário.

- [[Poder - Espectador S0 - Autoridade de Visionário#Manifestar cenário|Manifestar cenário]]
- [[Poder - Espectador S0 - Autoridade de Visionário#Identidade imaginada|Identidade imaginada]]

Operação: [[Poder - Espectador S0 - Autoridade de Visionário#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Visionário** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S0 - Visionário]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Espectador - Autor]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
