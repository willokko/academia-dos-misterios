---
titulo: "Sequência 2 - Vidente - Invocador de Milagres"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 2
nome_ingles: "Miracle Invoker"
---

# Sequência 2 - Vidente - Invocador de Milagres

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 2. **Nome de referência:** Miracle Invoker. Tradução editorial: Invocador de Milagres.

## O que a poção transforma

O [[Poder - Vidente S2 - Autoridade de Invocador de Milagres|pacote completo de Invocador de Milagres]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Invocador de Milagres.

- [[Poder - Vidente S2 - Autoridade de Invocador de Milagres#Milagre preparado|Milagre preparado]]
- [[Poder - Vidente S2 - Autoridade de Invocador de Milagres#Retorno do milagroso|Retorno do milagroso]]

Operação: [[Poder - Vidente S2 - Autoridade de Invocador de Milagres#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Invocador de Milagres** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S2 - Invocador de Milagres]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Vidente - Erudito do Passado]]. Próxima: [[Sequência 1 - Vidente - Servidor dos Mistérios]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
