---
titulo: "Sequência 9 - Criminoso - Criminoso"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 9
nome_ingles: "Criminal"
---

# Sequência 9 - Criminoso - Criminoso

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 9. **Nome de referência:** Criminal. Tradução editorial: Criminoso.

## O que a poção transforma

O [[Poder - Criminoso S9 - Sentido de ameaça|pacote completo de Criminoso]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Instinto predatório.

- [[Poder - Criminoso S9 - Sentido de ameaça#Pressentir emboscada|Pressentir emboscada]]
- [[Poder - Criminoso S9 - Sentido de ameaça#Golpe predatório|Golpe predatório]]
- [[Poder - Criminoso S9 - Sentido de ameaça#Não ser encurralado|Não ser encurralado]]



## Atuação e digestão

Interpretação original do papel **Criminoso** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S9 - Criminoso]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Criminoso - Anjo sem Asas]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
