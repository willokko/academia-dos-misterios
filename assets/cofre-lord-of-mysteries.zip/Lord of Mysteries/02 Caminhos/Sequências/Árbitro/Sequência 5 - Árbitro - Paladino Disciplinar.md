---
titulo: "Sequência 5 - Árbitro - Paladino Disciplinar"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 5
nome_ingles: "Disciplinary Paladin"
---

# Sequência 5 - Árbitro - Paladino Disciplinar

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 5. **Nome de referência:** Disciplinary Paladin. Tradução editorial: Paladino Disciplinar.

## O que a poção transforma

O [[Poder - Árbitro S5 - Sanção disciplinar|pacote completo de Paladino Disciplinar]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Majestade disciplinar.

- [[Poder - Árbitro S5 - Sanção disciplinar#Execução de veredito|Execução de veredito]]
- [[Poder - Árbitro S5 - Sanção disciplinar#Decreto de trégua|Decreto de trégua]]
- [[Poder - Árbitro S5 - Sanção disciplinar#Proteção disciplinar|Proteção disciplinar]]



## Atuação e digestão

Interpretação original do papel **Paladino Disciplinar** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S5 - Paladino Disciplinar]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Árbitro - Juiz]]. Próxima: [[Sequência 4 - Árbitro - Mago Imperativo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
