---
titulo: "Poder - Prisioneiro S5 - Visita espectral"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Prisioneiro"
sequencia: 5
nome_pacote: "Pacote de Espectro — Prisioneiro S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Prisioneiro S5 - Visita espectral

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Espectro, Prisioneiro S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Prisioneiro - Espectro]] ou melhor no [[Caminho do Prisioneiro]]. **Referência nominal:** Wraith. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Natureza espectral:** Pode alternar entre carne e espírito pela técnica. Na forma espiritual, não come ou respira; percebe contornos espirituais expostos.

## Técnicas adquiridas

### Corpo de espectro

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

Fique incorpóreo pela cena: ataques puramente físicos ordinários não o atingem e atravessa parede inerte fina. Técnicas espirituais, luz e raio continuam eficazes; não transporta outra pessoa ou atravessa selo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Salto em reflexo

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND13 sob oposição |

Desloque-se entre duas superfícies refletoras conhecidas da cena ou até 100 m, sem ataque junto.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Possessão

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON contra DEF.M |

Sobreponha-se à percepção de um alvo e crie Possessão 0/6. Ao completar, NPC pode ser controlado enquanto houver vínculo; seu corpo original não ganha outro turno. PJs usam a regra de agência.

**Limites:** Uma possessão; após início, contribuições custam 10 PM. Dano espiritual ou expulsão pode interromper; não cria nova característica.

## Evolução e acúmulo

S4 atua como marionete amaldiçoada, distinta do servo do Vidente. A maldição atual substitui as anteriores.

## Preparação e oposição

Recipientes preparados, purificação e reconhecimento da âncora. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Prisioneiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
