---
titulo: "Poder - Aprendiz S0 - Autoridade de Porta"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Aprendiz"
sequencia: 0
nome_pacote: "Pacote de Porta — Aprendiz S0"
quantidade_tecnicas: 2
quantidade_capacidades: 1
quantidade_operacoes: 1
---

# Poder - Aprendiz S0 - Autoridade de Porta

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Porta, Aprendiz S0.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 0 - Aprendiz - Porta]] ou melhor no [[Caminho do Aprendiz]]. **Referência nominal:** Door. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Transformação de Porta:** Representa acesso e fronteira espacial no domínio estabelecido, com destinos e entidades reais.

## Técnicas adquiridas

### Abrir fronteira

| Parâmetro | Regra |
|---|---|
| Custo | 50 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND16 em obstáculo sem ficha |

Abra um acesso local entre duas fronteiras conhecidas, permitindo trânsito por uma cena até contestado.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

### Fechar fronteira

| Parâmetro | Regra |
|---|---|
| Custo | 50 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND16 em obstáculo sem ficha |

Feche uma passagem espacial identificada; seres e autoridades equivalentes podem iniciar disputa para reabri-la.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

## Feito de operação

Abrir ou fechar uma fronteira conceitual específica mediante vínculo, brecha e âncoras.

**Procedimento:** [[Módulo angelical e divino]]. Reúna três chaves, declare alvo, transformação e consequência do perigo. O portador inicia uma vez por operação, ação Poder, 50 PM e primeiro teste ND16; objetivo de 16 seções. Cada PJ contribui uma vez por rodada com Objetivo e margens normais, sem pagar novamente a taxa. Não use esse relógio para atrasar as aplicações locais sem oposição equivalente.

## Evolução e acúmulo

Conserva todos os pacotes anteriores. O novo grau amplia a natureza do que pode fazer, não soma automaticamente dano ou bônus de todas as formas. Capacidades de operação seguem seu módulo e Escala e confrontos sobrenaturais.

## Preparação e oposição

Selos, destinos não conhecidos e falta de observação prévia. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Aprendiz]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
