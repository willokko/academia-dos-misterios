---
titulo: "Sequência 5 - Suplicante de Segredos - Pastor"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Suplicante de Segredos"
sequencia: 5
nome_ingles: "Shepherd"
---

# Sequência 5 - Suplicante de Segredos - Pastor

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Suplicante de Segredos]]. **Sequência:** 5. **Nome de referência:** Shepherd. Tradução editorial: Pastor.

## O que a poção transforma

O [[Poder - Suplicante de Segredos S5 - Pastoreio de eco|pacote completo de Pastor]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Pastoreio.

- [[Poder - Suplicante de Segredos S5 - Pastoreio de eco#Vincular alma|Vincular alma]]
- [[Poder - Suplicante de Segredos S5 - Pastoreio de eco#Manifestar alma|Manifestar alma]]
- [[Poder - Suplicante de Segredos S5 - Pastoreio de eco#Liberar o rebanho|Liberar o rebanho]]



## Atuação e digestão

Interpretação original do papel **Pastor** no tema de escuta perigosa, sombras, carne e almas. Princípio de partida: buscar conhecimento sem entregar a própria responsabilidade à voz que responde. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Suplicante de Segredos#S5 - Pastor]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Suplicante de Segredos - Bispo da Rosa]]. Próxima: [[Sequência 4 - Suplicante de Segredos - Cavaleiro Negro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
