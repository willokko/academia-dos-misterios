---
titulo: "Sequência 3 - Monstro - Caminhante do Caos"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 3
nome_ingles: "Chaoswalker"
---

# Sequência 3 - Monstro - Caminhante do Caos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 3. **Nome de referência:** Chaoswalker. Tradução editorial: Caminhante do Caos.

## O que a poção transforma

O [[Poder - Monstro S3 - Autoridade de Caminhante do Caos|pacote completo de Caminhante do Caos]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Caminhante do Caos.

- [[Poder - Monstro S3 - Autoridade de Caminhante do Caos#Passo no caos|Passo no caos]]
- [[Poder - Monstro S3 - Autoridade de Caminhante do Caos#Padrão quebrado|Padrão quebrado]]

Operação: [[Poder - Monstro S3 - Autoridade de Caminhante do Caos#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Caminhante do Caos** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S3 - Caminhante do Caos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Monstro - Mago do Infortúnio]]. Próxima: [[Sequência 2 - Monstro - Adivinho]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
