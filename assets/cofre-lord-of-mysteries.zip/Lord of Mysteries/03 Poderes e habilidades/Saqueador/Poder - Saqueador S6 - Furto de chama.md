---
titulo: "Poder - Saqueador S6 - Furto de chama"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Saqueador"
sequencia: 6
nome_pacote: "Pacote de Prometeu — Saqueador S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Saqueador S6 - Furto de chama

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Prometeu, Saqueador S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Saqueador - Prometeu]] ou melhor no [[Caminho do Saqueador]]. **Referência nominal:** Prometheus. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Furto espiritual:** Reconhece manifestações de técnicas em uso. Não recebe um catálogo secreto de alvos.

## Técnicas adquiridas

### Roubar poder

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Dez minutos |
| Teste | DES+VON contra DEF.M |

Roube uma técnica ativa S9–5 observada. NPC perde seu uso até o fim do terceiro turno dele; você pode usá-la por dez minutos pagando os custos originais. Dois espaços, um roubo por alvo. Contra PJ, não bloqueia sem acordo.

**Limites:** Um espaço guarda uma técnica, nunca pacote inteiro. Sem cópia ou roubo recursivo.

### Furto à distância

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | 30 m |
| Duração | Instantânea |
| Teste | DES+AST contra DEF |

Retire ou plante um pequeno objeto percebido em até 30 m. Se empunhado por adversário alerta, primeiro conclua Captura 0/4, com uma ação e este custo por contribuição.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Rastrear valor

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Perceba direção e tipo geral de objeto valioso num recinto, sem atravessar ocultação. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S5 aumenta para três espaços e uma hora de retenção. A variante de Amon não é adquirida automaticamente.

## Preparação e oposição

Vigilância cruzada, vínculos protegidos e ações sem habilidade ativa. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Saqueador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
