---
titulo: "Sequência 8 - Boticário - Domador de Bestas"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 8
nome_ingles: "Beast Tamer"
---

# Sequência 8 - Boticário - Domador de Bestas

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 8. **Nome de referência:** Beast Tamer. Tradução editorial: Domador de Bestas.

## O que a poção transforma

O [[Poder - Boticário S8 - Entendimento da besta|pacote completo de Domador de Bestas]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Afinidade animal.

- [[Poder - Boticário S8 - Entendimento da besta#Vínculo de besta|Vínculo de besta]]
- [[Poder - Boticário S8 - Entendimento da besta#Comandar companheira|Comandar companheira]]
- [[Poder - Boticário S8 - Entendimento da besta#Instinto da besta|Instinto da besta]]



## Atuação e digestão

Interpretação original do papel **Domador de Bestas** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S8 - Domador de Bestas]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Boticário - Boticário]]. Próxima: [[Sequência 7 - Boticário - Vampiro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
