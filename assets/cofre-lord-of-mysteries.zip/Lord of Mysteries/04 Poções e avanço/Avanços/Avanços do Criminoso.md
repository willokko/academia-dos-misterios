---
titulo: "Avanços do Criminoso"
tipo: "poções-e-avanço"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "ritos-e-altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
---

# Avanços do Criminoso

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

Esta nota é a referência única de fórmulas e ritos do [[Caminho do Criminoso]]. Custos e preparação: [[Poções e fórmulas]], [[Fórmulas e ingredientes]] e [[Avanço e consumo]]. Não foram verificadas receitas completas para todas as Sequências deste Caminho.

**Fórmula jogável original comum, S9–1:** uma característica íntegra da Sequência desejada, com proveniência registrada, mais auxiliares simbólicos do orçamento. Use um objeto, substância e gesto associados a **malícia, perigo, desejos e corrupção**; as quantidades e o preparo não pretendem reproduzir o romance. Sem uma característica disponível, não há poção. **Na S0, não use essa simplificação:** é preciso reunir a Unicidade e três características S1 do Caminho, além do rito e das condições do [[Módulo angelical e divino]]. Ver [[Características Beyonder]].

**Princípio geral original:** Reconhecer a tentação de dominar sem entregar a ela o comando.

## S9 - Criminoso

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** A primeira poção é antecedente de criação; obtenha a fórmula de um patrono e declare a dívida, sem rolagem inicial. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 9 - Criminoso - Criminoso]] e [[Poder - Criminoso S9 - Sentido de ameaça]].

## S8 - Anjo sem Asas

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Anjo sem Asas numa situação com consequência: reconhecer a tentação de dominar sem entregar a ela o comando. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 8 - Criminoso - Anjo sem Asas]] e [[Poder - Criminoso S8 - Frieza calculada]].

## S7 - Assassino em Série

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Assassino em Série numa situação com consequência: reconhecer a tentação de dominar sem entregar a ela o comando. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 7 - Criminoso - Assassino em Série]] e [[Poder - Criminoso S7 - Padrão predatório]].

## S6 - Diabo

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Diabo numa situação com consequência: reconhecer a tentação de dominar sem entregar a ela o comando. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 6 - Criminoso - Diabo]] e [[Poder - Criminoso S6 - Chama do diabo]].

## S5 - Apóstolo do Desejo

> [!quote] Rito relatado pela wiki
> A fonte relata uma série ritual de 13 a 49 mortes, com intervalos de três a nove dias e consumo de órgãos. É conteúdo cruel da obra; a alternativa original desta campanha deliberadamente substitui essa exigência, sem afirmar equivalência canônica. [Fonte secundária](https://lordofthemysteries.fandom.com/wiki/Potion_System/List_of_Advancement_Rituals). O procedimento numérico abaixo continua sendo adaptação.

**Prova original opcional para esta campanha:** Demonstre o papel de Apóstolo do Desejo numa situação com consequência: reconhecer a tentação de dominar sem entregar a ela o comando. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 5 - Criminoso - Apóstolo do Desejo]] e [[Poder - Criminoso S5 - Desejo exposto]].

## S4 - Demônio

> [!quote] Rito relatado pela wiki
> Induzir ao menos dez mil seres inteligentes a vender voluntariamente suas almas e adquiri-las; a fonte prevê ajuste por patamar. A prova original oferece uma alteração explícita para campanha cooperativa. [Fonte secundária](https://lordofthemysteries.fandom.com/wiki/Potion_System/List_of_Advancement_Rituals). O procedimento numérico abaixo continua sendo adaptação.

**Prova original opcional para esta campanha:** Demonstre o papel de Demônio numa situação com consequência: reconhecer a tentação de dominar sem entregar a ela o comando. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Criminoso S4 - Autoridade de Demônio]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 4 - Criminoso - Demônio]] e [[Poder - Criminoso S4 - Autoridade de Demônio]].

## S3 - Tagarela

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Tagarela numa situação com consequência: reconhecer a tentação de dominar sem entregar a ela o comando. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Criminoso S3 - Autoridade de Tagarela]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 3 - Criminoso - Tagarela]] e [[Poder - Criminoso S3 - Autoridade de Tagarela]].

## S2 - Arquiduque Sangrento

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Arquiduque Sangrento numa situação com consequência: reconhecer a tentação de dominar sem entregar a ela o comando. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Criminoso S2 - Autoridade de Arquiduque Sangrento]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 2 - Criminoso - Arquiduque Sangrento]] e [[Poder - Criminoso S2 - Autoridade de Arquiduque Sangrento]].

## S1 - Monarca da Imundície

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Monarca da Imundície numa situação com consequência: reconhecer a tentação de dominar sem entregar a ela o comando. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Criminoso S1 - Autoridade de Monarca da Imundície]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 1 - Criminoso - Monarca da Imundície]] e [[Poder - Criminoso S1 - Autoridade de Monarca da Imundície]].

## S0 - Abismo

> [!quote] Rito relatado pela wiki
> Transformar um continente em Abismo. É um objetivo de escala divina, sem equivalência com um ritual comum de dano. [Fonte secundária](https://lordofthemysteries.fandom.com/wiki/Abyss_Pathway/Advancement). O procedimento numérico abaixo continua sendo adaptação.

**Prova original opcional para esta campanha:** Demonstre o papel de Abismo numa situação com consequência: reconhecer a tentação de dominar sem entregar a ela o comando. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Criminoso S0 - Autoridade de Abismo]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 0 - Criminoso - Abismo]] e [[Poder - Criminoso S0 - Autoridade de Abismo]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
