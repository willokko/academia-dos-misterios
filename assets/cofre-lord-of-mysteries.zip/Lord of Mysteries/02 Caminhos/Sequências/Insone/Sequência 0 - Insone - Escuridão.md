---
titulo: "Sequência 0 - Insone - Escuridão"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 0
nome_ingles: "Darkness"
---

# Sequência 0 - Insone - Escuridão

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 0. **Nome de referência:** Darkness. Tradução editorial: Escuridão.

## O que a poção transforma

O [[Poder - Insone S0 - Autoridade de Escuridão|pacote completo de Escuridão]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Escuridão.

- [[Poder - Insone S0 - Autoridade de Escuridão#Noite do domínio|Noite do domínio]]
- [[Poder - Insone S0 - Autoridade de Escuridão#Repouso da manifestação|Repouso da manifestação]]

Operação: [[Poder - Insone S0 - Autoridade de Escuridão#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Escuridão** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S0 - Escuridão]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Insone - Cavaleiro do Infortúnio]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
