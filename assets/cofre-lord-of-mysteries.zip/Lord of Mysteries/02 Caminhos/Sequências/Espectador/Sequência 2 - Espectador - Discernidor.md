---
titulo: "Sequência 2 - Espectador - Discernidor"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 2
nome_ingles: "Discerner"
---

# Sequência 2 - Espectador - Discernidor

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 2. **Nome de referência:** Discerner. Tradução editorial: Discernidor.

## O que a poção transforma

O [[Poder - Espectador S2 - Autoridade de Discernidor|pacote completo de Discernidor]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Discernidor.

- [[Poder - Espectador S2 - Autoridade de Discernidor#Discernir vulnerabilidade|Discernir vulnerabilidade]]
- [[Poder - Espectador S2 - Autoridade de Discernidor#Labirinto de mentes|Labirinto de mentes]]

Operação: [[Poder - Espectador S2 - Autoridade de Discernidor#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Discernidor** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S2 - Discernidor]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Espectador - Tecelão de Sonhos]]. Próxima: [[Sequência 1 - Espectador - Autor]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
