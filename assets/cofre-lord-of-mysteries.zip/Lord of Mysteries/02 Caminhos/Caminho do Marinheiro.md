---
titulo: "Caminho do Marinheiro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
nome_divino: "Tirano"
referencia: "https://lordofthemysteries.fandom.com/wiki/Tyrant_Pathway"
---

# Caminho do Marinheiro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Tirano. **Tema:** Mar, fúria, vento e tempestade. **Função:** Mobilidade, resgate e pressão ofensiva.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Marinheiro - Marinheiro|Marinheiro]] | [[Poder - Marinheiro S9 - Corpo das marés|3 técnicas]] |
| 8 | [[Sequência 8 - Marinheiro - Povo da Fúria|Povo da Fúria]] | [[Poder - Marinheiro S8 - Investida da fúria|3 técnicas]] |
| 7 | [[Sequência 7 - Marinheiro - Navegante|Navegante]] | [[Poder - Marinheiro S7 - Rumo contra a tempestade|3 técnicas]] |
| 6 | [[Sequência 6 - Marinheiro - Abençoado pelo Vento|Abençoado pelo Vento]] | [[Poder - Marinheiro S6 - Passagem do vento|3 técnicas]] |
| 5 | [[Sequência 5 - Marinheiro - Cantor do Oceano|Cantor do Oceano]] | [[Poder - Marinheiro S5 - Voz do oceano|3 técnicas]] |
| 4 | [[Sequência 4 - Marinheiro - Sepultador de Cataclismos|Sepultador de Cataclismos]] | [[Poder - Marinheiro S4 - Autoridade de Sepultador de Cataclismos|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Marinheiro - Rei do Mar|Rei do Mar]] | [[Poder - Marinheiro S3 - Autoridade de Rei do Mar|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Marinheiro - Calamidade|Calamidade]] | [[Poder - Marinheiro S2 - Autoridade de Calamidade|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Marinheiro - Deus do Trovão|Deus do Trovão]] | [[Poder - Marinheiro S1 - Autoridade de Deus do Trovão|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Marinheiro - Tirano|Tirano]] | [[Poder - Marinheiro S0 - Autoridade de Tirano|2 técnicas + operação]] |

## Como jogar

Reconhecer correntes, decidir quando enfrentar e quando conduzir a força. As ferramentas da S9 são corpo aquático, equilíbrio naval e escamas. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Média: ambiente e alcance. **Oposição:** Locais sem acesso aéreo/aquático, preparação interrompida e proteção elemental. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Marinheiro]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Tyrant_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
