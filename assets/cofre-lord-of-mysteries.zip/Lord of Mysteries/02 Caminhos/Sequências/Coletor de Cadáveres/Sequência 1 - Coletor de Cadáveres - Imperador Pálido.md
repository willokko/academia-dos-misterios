---
titulo: "Sequência 1 - Coletor de Cadáveres - Imperador Pálido"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 1
nome_ingles: "Pale Emperor"
---

# Sequência 1 - Coletor de Cadáveres - Imperador Pálido

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 1. **Nome de referência:** Pale Emperor. Tradução editorial: Imperador Pálido.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido|pacote completo de Imperador Pálido]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Imperador Pálido.

- [[Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido#Édito pálido|Édito pálido]]
- [[Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido#Exército funerário|Exército funerário]]

Operação: [[Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Imperador Pálido** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S1 - Imperador Pálido]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Coletor de Cadáveres - Cônsul da Morte]]. Próxima: [[Sequência 0 - Coletor de Cadáveres - Morte]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
