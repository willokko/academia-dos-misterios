---
titulo: "Sequência 4 - Caçador - Cavaleiro de Sangue e Ferro"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
sequencia: 4
nome_ingles: "Iron-blooded Knight"
---

# Sequência 4 - Caçador - Cavaleiro de Sangue e Ferro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Caçador]]. **Sequência:** 4. **Nome de referência:** Iron-blooded Knight. Tradução editorial: Cavaleiro de Sangue e Ferro.

## O que a poção transforma

O [[Poder - Caçador S4 - Autoridade de Cavaleiro de Sangue e Ferro|pacote completo de Cavaleiro de Sangue e Ferro]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Cavaleiro de Sangue e Ferro.

- [[Poder - Caçador S4 - Autoridade de Cavaleiro de Sangue e Ferro#Vínculo de ferro|Vínculo de ferro]]
- [[Poder - Caçador S4 - Autoridade de Cavaleiro de Sangue e Ferro#Sangue em comum|Sangue em comum]]

Operação: [[Poder - Caçador S4 - Autoridade de Cavaleiro de Sangue e Ferro#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Cavaleiro de Sangue e Ferro** no tema de rastreio, provocação, fogo e guerra. Princípio de partida: conhecer a presa sem reduzir toda relação a caça. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Caçador#S4 - Cavaleiro de Sangue e Ferro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Caçador - Ceifador]]. Próxima: [[Sequência 3 - Caçador - Bispo da Guerra]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
