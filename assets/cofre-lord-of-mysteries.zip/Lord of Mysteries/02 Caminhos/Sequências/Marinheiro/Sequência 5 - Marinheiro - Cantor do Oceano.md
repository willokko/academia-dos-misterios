---
titulo: "Sequência 5 - Marinheiro - Cantor do Oceano"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 5
nome_ingles: "Ocean Songster"
---

# Sequência 5 - Marinheiro - Cantor do Oceano

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 5. **Nome de referência:** Ocean Songster. Tradução editorial: Cantor do Oceano.

## O que a poção transforma

O [[Poder - Marinheiro S5 - Voz do oceano|pacote completo de Cantor do Oceano]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Habitante das águas; Afinidade com criaturas marinhas.

- [[Poder - Marinheiro S5 - Voz do oceano#Relâmpago do oceano|Relâmpago do oceano]]
- [[Poder - Marinheiro S5 - Voz do oceano#Canto tempestuoso|Canto tempestuoso]]
- [[Poder - Marinheiro S5 - Voz do oceano#Ordem às águas|Ordem às águas]]



## Atuação e digestão

Interpretação original do papel **Cantor do Oceano** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S5 - Cantor do Oceano]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Marinheiro - Abençoado pelo Vento]]. Próxima: [[Sequência 4 - Marinheiro - Sepultador de Cataclismos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
