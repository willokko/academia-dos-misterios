---
titulo: "Sequência 0 - Vidente - Louco"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 0
nome_ingles: "Fool"
---

# Sequência 0 - Vidente - Louco

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 0. **Nome de referência:** Fool. Tradução editorial: Louco.

## O que a poção transforma

O [[Poder - Vidente S0 - Autoridade de Louco|pacote completo de Louco]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Louco.

- [[Poder - Vidente S0 - Autoridade de Louco#Enganar a percepção|Enganar a percepção]]
- [[Poder - Vidente S0 - Autoridade de Louco#Enganar a relação|Enganar a relação]]

Operação: [[Poder - Vidente S0 - Autoridade de Louco#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Louco** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S0 - Louco]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Vidente - Servidor dos Mistérios]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
