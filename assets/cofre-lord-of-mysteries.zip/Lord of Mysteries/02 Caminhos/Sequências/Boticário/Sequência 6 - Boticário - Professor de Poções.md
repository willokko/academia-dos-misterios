---
titulo: "Sequência 6 - Boticário - Professor de Poções"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 6
nome_ingles: "Potions Professor"
---

# Sequência 6 - Boticário - Professor de Poções

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 6. **Nome de referência:** Potions Professor. Tradução editorial: Professor de Poções.

## O que a poção transforma

O [[Poder - Boticário S6 - Preparado de estabilidade|pacote completo de Professor de Poções]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Professor de poções.

- [[Poder - Boticário S6 - Preparado de estabilidade#Destilar essência|Destilar essência]]
- [[Poder - Boticário S6 - Preparado de estabilidade#Perfume de invisibilidade|Perfume de invisibilidade]]
- [[Poder - Boticário S6 - Preparado de estabilidade#Antissonho|Antissonho]]



## Atuação e digestão

Interpretação original do papel **Professor de Poções** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S6 - Professor de Poções]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Boticário - Vampiro]]. Próxima: [[Sequência 5 - Boticário - Erudito Escarlate]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
