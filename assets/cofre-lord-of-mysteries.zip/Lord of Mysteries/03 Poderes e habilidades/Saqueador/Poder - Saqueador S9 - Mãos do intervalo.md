---
titulo: "Poder - Saqueador S9 - Mãos do intervalo"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Saqueador"
sequencia: 9
nome_pacote: "Pacote de Saqueador — Saqueador S9"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Saqueador S9 - Mãos do intervalo

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Saqueador, Saqueador S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Saqueador - Saqueador]] ou melhor no [[Caminho do Saqueador]]. **Referência nominal:** Marauder. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Olho para o valioso:** Identifica objetos valiosos expostos; +2 para procurar objetos escondidos por meios físicos, sem atravessar selos.

## Técnicas adquiridas

### Mão leve

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | DES+AST contra DEF |

Tome ou plante um objeto pequeno não equipado. Não retira característica integrada.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Dedos extraordinários

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

+2 ao próximo teste para abrir fechadura mecânica ou desatar um fecho.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Inventário observado

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Descubra onde alguém guardou um objeto que exibiu nesta cena; não revela o que nunca viu. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S6 permite furto a distância. Até S7 o roubo afeta objetos, não poderes.

## Preparação e oposição

Vigilância cruzada, vínculos protegidos e ações sem habilidade ativa. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Saqueador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
