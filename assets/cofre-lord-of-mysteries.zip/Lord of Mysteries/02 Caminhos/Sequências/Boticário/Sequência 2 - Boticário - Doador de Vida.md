---
titulo: "Sequência 2 - Boticário - Doador de Vida"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Boticário"
sequencia: 2
nome_ingles: "Life-Giver"
---

# Sequência 2 - Boticário - Doador de Vida

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Boticário]]. **Sequência:** 2. **Nome de referência:** Life-Giver. Tradução editorial: Doador de Vida.

## O que a poção transforma

O [[Poder - Boticário S2 - Autoridade de Doador de Vida|pacote completo de Doador de Vida]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Doador de Vida.

- [[Poder - Boticário S2 - Autoridade de Doador de Vida#Doar vida|Doar vida]]
- [[Poder - Boticário S2 - Autoridade de Doador de Vida#Vida adaptada|Vida adaptada]]

Operação: [[Poder - Boticário S2 - Autoridade de Doador de Vida#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Doador de Vida** no tema de medicina, bestas, sangue e invocação lunar. Princípio de partida: cuidar de uma vida concreta antes de tratar vida como matéria. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Boticário#S2 - Doador de Vida]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Boticário - Alto Invocador]]. Próxima: [[Sequência 1 - Boticário - Deusa da Beleza]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
