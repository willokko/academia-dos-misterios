---
titulo: "Sequência 4 - Vidente - Feiticeiro Bizarro"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Vidente"
sequencia: 4
nome_ingles: "Bizarro Sorcerer"
---

# Sequência 4 - Vidente - Feiticeiro Bizarro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Vidente]]. **Sequência:** 4. **Nome de referência:** Bizarro Sorcerer. Tradução editorial: Feiticeiro Bizarro.

## O que a poção transforma

O [[Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro|pacote completo de Feiticeiro Bizarro]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Feiticeiro Bizarro.

- [[Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro#Troca pelos fios|Troca pelos fios]]
- [[Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro#Espírito partilhado|Espírito partilhado]]

Operação: [[Poder - Vidente S4 - Autoridade de Feiticeiro Bizarro#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Feiticeiro Bizarro** no tema de presságios, máscaras e controle por vínculos espirituais. Princípio de partida: interpretar sinais sem confundir previsão com certeza. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Vidente#S4 - Feiticeiro Bizarro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Vidente - Marionetista]]. Próxima: [[Sequência 3 - Vidente - Erudito do Passado]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
