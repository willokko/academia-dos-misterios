---
titulo: "Sequência 1 - Espectador - Autor"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 1
nome_ingles: "Author"
---

# Sequência 1 - Espectador - Autor

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 1. **Nome de referência:** Author. Tradução editorial: Autor.

## O que a poção transforma

O [[Poder - Espectador S1 - Autoridade de Autor|pacote completo de Autor]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Autor.

- [[Poder - Espectador S1 - Autoridade de Autor#Arranjo plausível|Arranjo plausível]]
- [[Poder - Espectador S1 - Autoridade de Autor#Personagem imaginado|Personagem imaginado]]

Operação: [[Poder - Espectador S1 - Autoridade de Autor#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Autor** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S1 - Autor]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Espectador - Discernidor]]. Próxima: [[Sequência 0 - Espectador - Visionário]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
