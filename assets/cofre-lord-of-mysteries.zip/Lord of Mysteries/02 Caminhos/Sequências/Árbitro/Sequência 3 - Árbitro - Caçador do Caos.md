---
titulo: "Sequência 3 - Árbitro - Caçador do Caos"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 3
nome_ingles: "Chaos Hunter"
---

# Sequência 3 - Árbitro - Caçador do Caos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 3. **Nome de referência:** Chaos Hunter. Tradução editorial: Caçador do Caos.

## O que a poção transforma

O [[Poder - Árbitro S3 - Autoridade de Caçador do Caos|pacote completo de Caçador do Caos]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Caçador do Caos.

- [[Poder - Árbitro S3 - Autoridade de Caçador do Caos#Rastrear desordem|Rastrear desordem]]
- [[Poder - Árbitro S3 - Autoridade de Caçador do Caos#Ordem de captura|Ordem de captura]]

Operação: [[Poder - Árbitro S3 - Autoridade de Caçador do Caos#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Caçador do Caos** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S3 - Caçador do Caos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Árbitro - Mago Imperativo]]. Próxima: [[Sequência 2 - Árbitro - Equilibrador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
