---
titulo: "Poder - Bardo S5 - Purificação focal"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Bardo"
sequencia: 5
nome_pacote: "Pacote de Sacerdote da Luz — Bardo S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Bardo S5 - Purificação focal

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Sacerdote da Luz, Bardo S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Bardo - Sacerdote da Luz]] ou melhor no [[Caminho do Bardo]]. **Referência nominal:** Priest of Light. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Presença sagrada:** Reconhece mortos e sombras expostos. Não percebe maldade, culpa ou religião secretas.

## Técnicas adquiridas

### Luz sagrada

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+25 de dano luz em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Exorcismo

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até expulsar ou interromper |
| Teste | AST+VON contra DEF.M do invasor |

Crie Expulsar 0/4 contra uma possessão percebida de igual patamar ou menor. Cada ação paga o custo e contribui pelas margens; não precisa ferir o hospedeiro.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Santuário provisório

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | Automático |

Você e dois voluntários reduzem em 10 o próximo dano de uma fonte espiritual declarada na ativação; um benefício por protegido, sem resistência permanente.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 desenvolve domínio luminoso; a identidade inclui proteção e compromissos, além de ataque.

## Preparação e oposição

Obscurecimento, pactos incompatíveis e fontes superiores. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Bardo]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
