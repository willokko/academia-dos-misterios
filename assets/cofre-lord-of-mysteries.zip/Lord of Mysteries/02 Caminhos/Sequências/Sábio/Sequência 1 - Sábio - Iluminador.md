---
titulo: "Sequência 1 - Sábio - Iluminador"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 1
nome_ingles: "Illuminator"
---

# Sequência 1 - Sábio - Iluminador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 1. **Nome de referência:** Illuminator. Tradução editorial: Iluminador.

## O que a poção transforma

O [[Poder - Sábio S1 - Autoridade de Iluminador|pacote completo de Iluminador]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Iluminador.

- [[Poder - Sábio S1 - Autoridade de Iluminador#Iluminação técnica|Iluminação técnica]]
- [[Poder - Sábio S1 - Autoridade de Iluminador#Cultura de invenção|Cultura de invenção]]

Operação: [[Poder - Sábio S1 - Autoridade de Iluminador#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Iluminador** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S1 - Iluminador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Sábio - Magíster do Conhecimento]]. Próxima: [[Sequência 0 - Sábio - Paragon]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
