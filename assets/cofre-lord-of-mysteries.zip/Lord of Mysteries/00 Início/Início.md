---
titulo: "Início"
tipo: "início"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Início

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Lord of Mysteries × Fabula Ultima · edição de trabalho 0.2.0 · 21/10/2026**

Um suplemento para investigação sobrenatural, vínculos humanos e ascensão perigosa. Requer o livro básico de Fabula Ultima. O material pode ser usado sem plugins comunitários.

> [!warning] Spoilers e acesso
> Os nomes das Sequências revelam progressões do romance. As pastas de mestre contêm a solução da aventura. Essa organização não impede que alguém leia os arquivos.

## Na sessão

| Preciso de… | Abrir |
|---|---|
| Criar um personagem | [[Criação de personagens]] · [[Personagens prontos]] |
| Resolver uma ação | [[Testes e cooperação]] · [[Combate e alcance]] · [[Condições]] |
| Encontrar um poder | [[Índice de poderes]] · [[Índice dos 22 Caminhos]] |
| Consumir ou digerir uma poção | [[Poções e fórmulas]] · [[Digestão e atuação]] · [[Avanço e consumo]] |
| Lidar com perigo espiritual | [[Corrupção]] · [[Perda de controle]] · [[Tratamento e recuperação]] |
| Executar magia ritualística | [[Procedimento de rituais]] · [[Catálogo de rituais]] |
| Consultar um objeto | [[Objetos selados]] · [[Características Beyonder]] |
| Conduzir a primeira aventura | [[A sineta sob a chuva - Guia do mestre]] |

## Ler e preparar

Comece em [[Como usar este cofre]], depois [[Diagnóstico das fontes]], [[Arquitetura da adaptação]] e [[Regras dos poderes]]. Para jogar hoje, leia [[Criação de personagens]], escolha um de [[Personagens prontos]] e use [[A sineta sob a chuva - Apresentação]].

Os três protótipos são [[Caminho do Vidente]], [[Caminho do Espectador]] e [[Caminho do Marinheiro]]. Todos os 22 têm regras convencionais das Sequências 9–5. Sequências 4–3 usam [[Módulo dos santos]]; 2–0 usam [[Módulo angelical e divino]], com resolução por objetivos e autoridades.

## Estado editorial

[[Estado de desenvolvimento]] · [[Registro de decisões]] · [[Validação e exemplos]] · [[Limitações e pendências]] · [[Relatório de verificação]] · [[Índice geral]]

**Pronto para usar como protótipo; não validado em mesa.** Os nomes em inglês ajudam a conferir as traduções editoriais em português. As fichas de poderes são recortes originais jogáveis, não catálogos exaustivos das capacidades do romance.

## Edição 0.2 — Caminhos como transformação

Comece por [[Migração para a versão 0.2]] e [[Classes e identidade sobrenatural]]. Cada poção entrega o pacote inteiro: capacidades, técnicas e evolução. Referências de sessão: [[Servos e repertórios]], [[Controle mental e agência]], [[Escala e confrontos sobrenaturais]] e [[Exemplos da revisão 0.2]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
