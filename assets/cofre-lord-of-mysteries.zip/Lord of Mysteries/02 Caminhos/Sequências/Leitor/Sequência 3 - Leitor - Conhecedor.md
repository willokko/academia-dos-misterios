---
titulo: "Sequência 3 - Leitor - Conhecedor"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 3
nome_ingles: "Cognizer"
---

# Sequência 3 - Leitor - Conhecedor

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 3. **Nome de referência:** Cognizer. Tradução editorial: Conhecedor.

## O que a poção transforma

O [[Poder - Leitor S3 - Autoridade de Conhecedor|pacote completo de Conhecedor]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Conhecedor.

- [[Poder - Leitor S3 - Autoridade de Conhecedor#Conhecer a estrutura|Conhecer a estrutura]]
- [[Poder - Leitor S3 - Autoridade de Conhecedor#Aplicar princípio|Aplicar princípio]]

Operação: [[Poder - Leitor S3 - Autoridade de Conhecedor#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Conhecedor** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S3 - Conhecedor]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Leitor - Profeta]]. Próxima: [[Sequência 2 - Leitor - Anjo da Sabedoria]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
