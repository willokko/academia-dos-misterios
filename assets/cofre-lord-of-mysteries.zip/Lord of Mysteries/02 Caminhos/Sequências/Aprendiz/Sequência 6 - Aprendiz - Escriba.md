---
titulo: "Sequência 6 - Aprendiz - Escriba"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Aprendiz"
sequencia: 6
nome_ingles: "Scribe"
---

# Sequência 6 - Aprendiz - Escriba

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Aprendiz]]. **Sequência:** 6. **Nome de referência:** Scribe. Tradução editorial: Escriba.

## O que a poção transforma

O [[Poder - Aprendiz S6 - Registro único|pacote completo de Escriba]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Livro espiritual.

- [[Poder - Aprendiz S6 - Registro único#Registrar técnica|Registrar técnica]]
- [[Poder - Aprendiz S6 - Registro único#Liberar registro|Liberar registro]]
- [[Poder - Aprendiz S6 - Registro único#Compartilhar abertura|Compartilhar abertura]]



## Atuação e digestão

Interpretação original do papel **Escriba** no tema de passagem, registro de poderes e espaço. Princípio de partida: abrir possibilidades e preparar uma rota de retorno. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Aprendiz#S6 - Escriba]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Aprendiz - Astrólogo]]. Próxima: [[Sequência 5 - Aprendiz - Viajante]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
