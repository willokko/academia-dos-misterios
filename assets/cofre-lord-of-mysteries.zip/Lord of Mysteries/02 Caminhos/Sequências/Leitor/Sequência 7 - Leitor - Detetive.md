---
titulo: "Sequência 7 - Leitor - Detetive"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 7
nome_ingles: "Detective"
---

# Sequência 7 - Leitor - Detetive

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 7. **Nome de referência:** Detective. Tradução editorial: Detetive.

## O que a poção transforma

O [[Poder - Leitor S7 - Dedução de campo|pacote completo de Detetive]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Sentidos do detetive.

- [[Poder - Leitor S7 - Dedução de campo#Reconstruir passagem|Reconstruir passagem]]
- [[Poder - Leitor S7 - Dedução de campo#Ler técnica|Ler técnica]]
- [[Poder - Leitor S7 - Dedução de campo#Antecipação tática|Antecipação tática]]



## Atuação e digestão

Interpretação original do papel **Detetive** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S7 - Detetive]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Leitor - Estudante do Raciocínio]]. Próxima: [[Sequência 6 - Leitor - Polímata]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
