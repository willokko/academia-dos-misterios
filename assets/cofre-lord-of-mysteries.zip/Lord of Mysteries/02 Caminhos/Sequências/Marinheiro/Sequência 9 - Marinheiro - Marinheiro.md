---
titulo: "Sequência 9 - Marinheiro - Marinheiro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 9
nome_ingles: "Sailor"
---

# Sequência 9 - Marinheiro - Marinheiro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 9. **Nome de referência:** Sailor. Tradução editorial: Marinheiro.

## O que a poção transforma

O [[Poder - Marinheiro S9 - Corpo das marés|pacote completo de Marinheiro]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Corpo aquático; Equilíbrio naval e escamas.

- [[Poder - Marinheiro S9 - Corpo das marés#Resgate das marés|Resgate das marés]]
- [[Poder - Marinheiro S9 - Corpo das marés#Golpe de marujo|Golpe de marujo]]
- [[Poder - Marinheiro S9 - Corpo das marés#Firmar o convés|Firmar o convés]]



## Atuação e digestão

Interpretação original do papel **Marinheiro** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S9 - Marinheiro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Marinheiro - Povo da Fúria]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
