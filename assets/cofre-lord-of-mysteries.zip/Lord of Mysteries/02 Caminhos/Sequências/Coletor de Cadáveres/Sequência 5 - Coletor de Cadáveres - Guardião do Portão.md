---
titulo: "Sequência 5 - Coletor de Cadáveres - Guardião do Portão"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 5
nome_ingles: "Gatekeeper"
---

# Sequência 5 - Coletor de Cadáveres - Guardião do Portão

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 5. **Nome de referência:** Gatekeeper. Tradução editorial: Guardião do Portão.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S5 - Portão contido|pacote completo de Guardião do Portão]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Abrigo do portão.

- [[Poder - Coletor de Cadáveres S5 - Portão contido#Portão do submundo|Portão do submundo]]
- [[Poder - Coletor de Cadáveres S5 - Portão contido#Manifestar o abrigado|Manifestar o abrigado]]
- [[Poder - Coletor de Cadáveres S5 - Portão contido#Fechar o limiar|Fechar o limiar]]



## Atuação e digestão

Interpretação original do papel **Guardião do Portão** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S5 - Guardião do Portão]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Coletor de Cadáveres - Guia Espiritual]]. Próxima: [[Sequência 4 - Coletor de Cadáveres - Imorredouro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
