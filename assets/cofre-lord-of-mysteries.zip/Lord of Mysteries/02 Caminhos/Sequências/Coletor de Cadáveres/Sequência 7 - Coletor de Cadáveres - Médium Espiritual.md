---
titulo: "Sequência 7 - Coletor de Cadáveres - Médium Espiritual"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 7
nome_ingles: "Spirit Medium"
---

# Sequência 7 - Coletor de Cadáveres - Médium Espiritual

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 7. **Nome de referência:** Spirit Medium. Tradução editorial: Médium Espiritual.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S7 - Audiência dos mortos|pacote completo de Médium Espiritual]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Afinidade com espíritos.

- [[Poder - Coletor de Cadáveres S7 - Audiência dos mortos#Canalizar falecido|Canalizar falecido]]
- [[Poder - Coletor de Cadáveres S7 - Audiência dos mortos#Consultar espírito local|Consultar espírito local]]
- [[Poder - Coletor de Cadáveres S7 - Audiência dos mortos#Máscara de morto|Máscara de morto]]



## Atuação e digestão

Interpretação original do papel **Médium Espiritual** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S7 - Médium Espiritual]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Coletor de Cadáveres - Coveiro]]. Próxima: [[Sequência 6 - Coletor de Cadáveres - Guia Espiritual]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
