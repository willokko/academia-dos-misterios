---
titulo: "Sequência 4 - Plantador - Alquimista Antigo"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
sequencia: 4
nome_ingles: "Ancient Alchemist"
---

# Sequência 4 - Plantador - Alquimista Antigo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Plantador]]. **Sequência:** 4. **Nome de referência:** Ancient Alchemist. Tradução editorial: Alquimista Antigo.

## O que a poção transforma

O [[Poder - Plantador S4 - Autoridade de Alquimista Antigo|pacote completo de Alquimista Antigo]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Alquimista Antigo.

- [[Poder - Plantador S4 - Autoridade de Alquimista Antigo#Quimera pesquisada|Quimera pesquisada]]
- [[Poder - Plantador S4 - Autoridade de Alquimista Antigo#Receptáculo vivo|Receptáculo vivo]]

Operação: [[Poder - Plantador S4 - Autoridade de Alquimista Antigo#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Alquimista Antigo** no tema de cultivo, medicina, vida e transformações orgânicas. Princípio de partida: cultivar condições para que outros vivam sem possuir seu futuro. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Plantador#S4 - Alquimista Antigo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Plantador - Druida]]. Próxima: [[Sequência 3 - Plantador - Portador do Caixão]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
