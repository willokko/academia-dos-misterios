---
titulo: "Sequência 3 - Insone - Bispo do Horror"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 3
nome_ingles: "Horror Bishop"
---

# Sequência 3 - Insone - Bispo do Horror

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 3. **Nome de referência:** Horror Bishop. Tradução editorial: Bispo do Horror.

## O que a poção transforma

O [[Poder - Insone S3 - Autoridade de Bispo do Horror|pacote completo de Bispo do Horror]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Bispo do Horror.

- [[Poder - Insone S3 - Autoridade de Bispo do Horror#Mundo do pesadelo|Mundo do pesadelo]]
- [[Poder - Insone S3 - Autoridade de Bispo do Horror#Espada de escuridão|Espada de escuridão]]

Operação: [[Poder - Insone S3 - Autoridade de Bispo do Horror#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Bispo do Horror** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S3 - Bispo do Horror]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Insone - Vigilante Noturno]]. Próxima: [[Sequência 2 - Insone - Servo da Ocultação]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
