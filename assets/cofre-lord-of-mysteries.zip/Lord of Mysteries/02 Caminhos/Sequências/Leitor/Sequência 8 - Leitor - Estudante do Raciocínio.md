---
titulo: "Sequência 8 - Leitor - Estudante do Raciocínio"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Leitor"
sequencia: 8
nome_ingles: "Student of Ratiocination"
---

# Sequência 8 - Leitor - Estudante do Raciocínio

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Leitor]]. **Sequência:** 8. **Nome de referência:** Student of Ratiocination. Tradução editorial: Estudante do Raciocínio.

## O que a poção transforma

O [[Poder - Leitor S8 - Hipótese contrastada|pacote completo de Estudante do Raciocínio]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Raciocínio.

- [[Poder - Leitor S8 - Hipótese contrastada#Cadeia de inferência|Cadeia de inferência]]
- [[Poder - Leitor S8 - Hipótese contrastada#Encontrar contradição|Encontrar contradição]]
- [[Poder - Leitor S8 - Hipótese contrastada#Prever o método|Prever o método]]



## Atuação e digestão

Interpretação original do papel **Estudante do Raciocínio** no tema de conhecimento, dedução e reprodução por compreensão. Princípio de partida: testar uma hipótese e admitir o que os dados ainda não sustentam. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Leitor#S8 - Estudante do Raciocínio]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Leitor - Leitor]]. Próxima: [[Sequência 7 - Leitor - Detetive]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
