---
titulo: "Sequência 2 - Criminoso - Arquiduque Sangrento"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 2
nome_ingles: "Bloody Archduke"
---

# Sequência 2 - Criminoso - Arquiduque Sangrento

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 2. **Nome de referência:** Bloody Archduke. Tradução editorial: Arquiduque Sangrento.

## O que a poção transforma

O [[Poder - Criminoso S2 - Autoridade de Arquiduque Sangrento|pacote completo de Arquiduque Sangrento]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Arquiduque Sangrento.

- [[Poder - Criminoso S2 - Autoridade de Arquiduque Sangrento#Manifestação sangrenta|Manifestação sangrenta]]
- [[Poder - Criminoso S2 - Autoridade de Arquiduque Sangrento#Desejo coletivo|Desejo coletivo]]

Operação: [[Poder - Criminoso S2 - Autoridade de Arquiduque Sangrento#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Arquiduque Sangrento** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S2 - Arquiduque Sangrento]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Criminoso - Tagarela]]. Próxima: [[Sequência 1 - Criminoso - Monarca da Imundície]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
