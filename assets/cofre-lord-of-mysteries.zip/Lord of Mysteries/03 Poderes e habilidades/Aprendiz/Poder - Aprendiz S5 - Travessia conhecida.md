---
titulo: "Poder - Aprendiz S5 - Travessia conhecida"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Aprendiz"
sequencia: 5
nome_pacote: "Pacote de Viajante — Aprendiz S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Aprendiz S5 - Travessia conhecida

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Viajante, Aprendiz S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Aprendiz - Viajante]] ou melhor no [[Caminho do Aprendiz]]. **Referência nominal:** Traveler. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Sentido do viajante:** Mantém orientação numa rota espiritual estudada; destinos novos precisam de pesquisa ou exploração.

## Técnicas adquiridas

### Viagem espiritual

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Uma travessia |
| Teste | Automático em rota segura; AST+VON ND13 contra interferência |

Leve você e até três voluntários a local visitado ou precisamente vinculado no mesmo país. Destino novo exige Objetivo de exploração, sem proibição absoluta de descoberta.

**Limites:** Selos e mundos hostis precisam de brecha e proteção. Não transporta navio ou exército.

### Porta em conflito

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | Automático; AST+VON ND13 sob oposição espacial |

Teleporte você e um voluntário para ponto desimpedido conhecido na cena; não inclui ataque.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Saída elevada

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob perigo |

Prepare uma chegada em apoio elevado ou queda controlada ao terminar a travessia. Não cria voo permanente e não acrescenta outro teleporte.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 oculta recintos; S3 alcança destinos extramundanos estudados. Registros mantêm graus e custos.

## Preparação e oposição

Selos, destinos não conhecidos e falta de observação prévia. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Aprendiz]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
