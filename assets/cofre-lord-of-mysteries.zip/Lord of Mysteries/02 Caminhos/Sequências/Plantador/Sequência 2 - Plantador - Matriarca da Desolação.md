---
titulo: "Sequência 2 - Plantador - Matriarca da Desolação"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
sequencia: 2
nome_ingles: "Desolate Matriarch"
---

# Sequência 2 - Plantador - Matriarca da Desolação

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Plantador]]. **Sequência:** 2. **Nome de referência:** Desolate Matriarch. Tradução editorial: Matriarca da Desolação.

## O que a poção transforma

O [[Poder - Plantador S2 - Autoridade de Matriarca da Desolação|pacote completo de Matriarca da Desolação]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Matriarca da Desolação.

- [[Poder - Plantador S2 - Autoridade de Matriarca da Desolação#Terreno desolado|Terreno desolado]]
- [[Poder - Plantador S2 - Autoridade de Matriarca da Desolação#Reaver nutrientes|Reaver nutrientes]]

Operação: [[Poder - Plantador S2 - Autoridade de Matriarca da Desolação#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Matriarca da Desolação** no tema de cultivo, medicina, vida e transformações orgânicas. Princípio de partida: cultivar condições para que outros vivam sem possuir seu futuro. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Plantador#S2 - Matriarca da Desolação]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Plantador - Portador do Caixão]]. Próxima: [[Sequência 1 - Plantador - Caminhante da Natureza]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
