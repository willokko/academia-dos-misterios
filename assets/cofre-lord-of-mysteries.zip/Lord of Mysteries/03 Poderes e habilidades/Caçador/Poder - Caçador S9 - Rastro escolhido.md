---
titulo: "Poder - Caçador S9 - Rastro escolhido"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Caçador"
sequencia: 9
nome_pacote: "Pacote de Caçador — Caçador S9"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Caçador S9 - Rastro escolhido

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Caçador, Caçador S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Caçador - Caçador]] ou melhor no [[Caminho do Caçador]]. **Referência nominal:** Hunter. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Sentidos de caça:** +2 para rastrear pegadas, cheiros ou alterações físicas existentes; a fonte pode estar mascarada ou ser falsa.

## Técnicas adquiridas

### Rastro recente

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Determine direção e uma característica física de uma passagem a partir do rastro. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Armadilha preparada

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até disparar |
| Teste | DES+AST contra DEF no disparo |

Com material disponível, prepare um ponto: o primeiro alvo que o atravessar enfrenta DES+AST contra DEF e sofre RA+10 físicos se atingido. Um disparo, sem outra iniciativa.

**Limites:** Duas armadilhas preparadas por usuário; local e gatilho declarados, sem inventar material retroativamente.

### Emboscada do caçador

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um ataque |
| Teste | Automático |

Após confirmar um rastro e ocultar posição, +2 ao próximo ataque contra essa presa nesta cena.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S7 introduz fogo; não recebe pirocinese na poção inicial.

## Preparação e oposição

Terreno estudado pelo oponente, objetivos múltiplos e proteção contra fogo. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Caçador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
