---
titulo: "Sequência 1 - Prisioneiro - Abominação"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 1
nome_ingles: "Abomination"
---

# Sequência 1 - Prisioneiro - Abominação

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 1. **Nome de referência:** Abomination. Tradução editorial: Abominação.

## O que a poção transforma

O [[Poder - Prisioneiro S1 - Autoridade de Abominação|pacote completo de Abominação]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Abominação.

- [[Poder - Prisioneiro S1 - Autoridade de Abominação#Forma abominável|Forma abominável]]
- [[Poder - Prisioneiro S1 - Autoridade de Abominação#Desejo aprisionado|Desejo aprisionado]]

Operação: [[Poder - Prisioneiro S1 - Autoridade de Abominação#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Abominação** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S1 - Abominação]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Prisioneiro - Flagelo Antigo]]. Próxima: [[Sequência 0 - Prisioneiro - Acorrentado]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
