---
titulo: "Poder - Plantador S5 - Forma de travessia"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Plantador"
sequencia: 5
nome_pacote: "Pacote de Druida — Plantador S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Plantador S5 - Forma de travessia

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Druida, Plantador S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Plantador - Druida]] ou melhor no [[Caminho do Plantador]]. **Referência nominal:** Druid. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Forma druídica:** Conhece duas formas animais ordinárias estudadas; não adquire características Beyonder do animal nem outra reserva de PV.

## Técnicas adquiridas

### Assumir forma

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

Transforme corpo numa das formas: escolha voo curto, natação ou farejo conforme a espécie. Mantém PV, PM e ações; técnicas incompatíveis com a anatomia ficam suspensas.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Caminho subterrâneo

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND13 sob oposição |

Atravesse solo não selado até ponto conhecido na cena; não atravessa fundação ritual ou leva automaticamente aliados.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Filho do carvalho

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um golpe e uma cena |
| Teste | Automático |

Pele de madeira ou pedra reduz em 10 o próximo dano; até o fim da cena, +2 para resistir a empurrão enquanto em contato com solo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 amplia alquimia viva; não cria uma economia infinita de matéria ou características.

## Preparação e oposição

Ambiente estéril, escassez de amostra e contaminação da fonte. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Plantador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
