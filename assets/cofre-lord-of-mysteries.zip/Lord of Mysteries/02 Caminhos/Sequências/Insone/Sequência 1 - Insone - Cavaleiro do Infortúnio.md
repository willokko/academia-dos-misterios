---
titulo: "Sequência 1 - Insone - Cavaleiro do Infortúnio"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 1
nome_ingles: "Knight of Misfortune"
---

# Sequência 1 - Insone - Cavaleiro do Infortúnio

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 1. **Nome de referência:** Knight of Misfortune. Tradução editorial: Cavaleiro do Infortúnio.

## O que a poção transforma

O [[Poder - Insone S1 - Autoridade de Cavaleiro do Infortúnio|pacote completo de Cavaleiro do Infortúnio]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Cavaleiro do Infortúnio.

- [[Poder - Insone S1 - Autoridade de Cavaleiro do Infortúnio#Marca de infortúnio|Marca de infortúnio]]
- [[Poder - Insone S1 - Autoridade de Cavaleiro do Infortúnio#Cavaleiro da noite|Cavaleiro da noite]]

Operação: [[Poder - Insone S1 - Autoridade de Cavaleiro do Infortúnio#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Cavaleiro do Infortúnio** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S1 - Cavaleiro do Infortúnio]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Insone - Servo da Ocultação]]. Próxima: [[Sequência 0 - Insone - Escuridão]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
