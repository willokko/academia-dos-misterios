---
titulo: "Regras dos poderes"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Regras dos poderes

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

## Aquisição do pacote inteiro

Uma poção concede todas as capacidades permanentes e técnicas da ficha correspondente. Não escolhe uma dentre elas. Grau menor conserva os pacotes anteriores; evoluções que dizem substituir alcance, fórmula ou quantidade substituem esse parâmetro, sem somar versões. Cada ficha tem uma seção de evolução e um vínculo com a Sequência.

Capacidade permanente funciona sem ativação, salvo quando o texto exige manifestar uma forma ou foco. Uma permissão não precisa de PM apenas para existir: visão espiritual, equilíbrio e respiração aquática seguem seus textos. Examinar algo, obter vantagem ou intervir numa disputa usa ação e teste quando indicados. Efeitos cosméticos não produzem benefício mecânico gratuito.

## Ação, reação e manutenção

Uma técnica com ação Poder consome a ação principal. Fora de conflito, um minuto ou dez minutos não vira uma ação de combate. Uma reação ocorre no gatilho declarado: no máximo uma reação de Caminho por rodada, incluindo todas as fontes, e nunca depois de resolver o dano ou crítico salvo texto expresso. Reações oficiais de classe conservam suas regras, mas não duplicam o mesmo efeito de Caminho.

Manter efeito pela cena não exige repetir ação nem PM, salvo texto expresso. Voo, máscara e invisibilidade não deixam de funcionar a cada turno. A técnica informa o que rompe o efeito. Ação de ataque, manipulação ou Objetivo pode interromper uma ocultação quando isso fizer parte de seu limite.

## Custos e limites comuns

1. Pague PM na declaração, inclusive em falha. Custo 0 não dispensa ação, material ou requisito. Onde a ficha diz pagar na preparação, não pague de novo ao liberar.
2. Em cada teste ou defesa, os bônus de Caminho somam no máximo +2. Penalidades iguais não se multiplicam. Não altera o dado básico e os máximos de PV/PM sem texto expresso.
3. Reduções fixas de Caminho sobre um mesmo dano usam somente a maior, antes das afinidades; não somam escamas, casulo e efígie. Benefícios oficiais seguem seus próprios textos. Dano final mínimo 0.
4. Uma nova rolagem forçada por usuário por rodada, sem refazer crítico ou uma nova rolagem. A técnica ainda deve permitir o uso e sua frequência específica.
5. Um servo ou projeção executa uma ação paga com a do controlador; não ganha iniciativa adicional. [[Servos e repertórios]] contém estoques e fichas.
6. Um controle decisivo precisa de progresso, oposição e meio de quebrar vínculo. [[Controle mental e agência]] governa PJs, NPCs, sonhos e possessão.
7. RA é o resultado do maior dado do teste, antes de bônus na soma. A fórmula impressa define dano; não soma níveis ou Sequência automaticamente. Um aprimoramento explicitamente impresso pode substituir a fórmula.
8. Dissipar um efeito de Caminho de cena percebido usa ação Poder, 10 PM e AST+VON contra DEF.M do criador, se de patamar igual ou menor. Isso não destrói característica, dispensa uma proteção de escala ou dissipa feitiços oficiais por engano.

## Leitura operacional

Automático significa que o poder funciona nas condições escritas. Teste sob oposição não torna impossível uma permissão básica. Nunca peça ação de classe para acessar poder que o pacote já concede. [[Escala e confrontos sobrenaturais]] separa uma porta comum, um selo de outro santo e uma operação de alcance regional. [[Classes e identidade sobrenatural]] distingue fonte e especialização.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
