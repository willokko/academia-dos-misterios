---
titulo: "Sequência 3 - Saqueador - Mentor do Engano"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 3
nome_ingles: "Mentor of Deceit"
---

# Sequência 3 - Saqueador - Mentor do Engano

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 3. **Nome de referência:** Mentor of Deceit. Tradução editorial: Mentor do Engano.

## O que a poção transforma

O [[Poder - Saqueador S3 - Autoridade de Mentor do Engano|pacote completo de Mentor do Engano]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Mentor do Engano.

- [[Poder - Saqueador S3 - Autoridade de Mentor do Engano#Enganar o mecanismo|Enganar o mecanismo]]
- [[Poder - Saqueador S3 - Autoridade de Mentor do Engano#Roubo de posição|Roubo de posição]]

Operação: [[Poder - Saqueador S3 - Autoridade de Mentor do Engano#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Mentor do Engano** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S3 - Mentor do Engano]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Saqueador - Parasita]]. Próxima: [[Sequência 2 - Saqueador - Cavalo de Troia do Destino]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
