---
titulo: "Sequência 8 - Bardo - Suplicante da Luz"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 8
nome_ingles: "Light Suppliant"
---

# Sequência 8 - Bardo - Suplicante da Luz

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 8. **Nome de referência:** Light Suppliant. Tradução editorial: Suplicante da Luz.

## O que a poção transforma

O [[Poder - Bardo S8 - Luz que denuncia|pacote completo de Suplicante da Luz]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Luz portátil.

- [[Poder - Bardo S8 - Luz que denuncia#Raio solar|Raio solar]]
- [[Poder - Bardo S8 - Luz que denuncia#Água solar|Água solar]]
- [[Poder - Bardo S8 - Luz que denuncia#Foco luminoso|Foco luminoso]]



## Atuação e digestão

Interpretação original do papel **Suplicante da Luz** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S8 - Suplicante da Luz]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Bardo - Bardo]]. Próxima: [[Sequência 7 - Bardo - Sumo Sacerdote Solar]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
