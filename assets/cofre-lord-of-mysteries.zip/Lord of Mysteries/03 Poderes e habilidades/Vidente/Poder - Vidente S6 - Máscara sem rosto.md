---
titulo: "Poder - Vidente S6 - Máscara sem rosto"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Vidente"
sequencia: 6
nome_pacote: "Pacote de Sem Rosto — Vidente S6"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Vidente S6 - Máscara sem rosto

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Sem Rosto, Vidente S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Vidente - Sem Rosto]] ou melhor no [[Caminho do Vidente]]. **Referência nominal:** Faceless. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Memória de rostos:** Recorda aparência e voz de pessoas estudadas. Isso fornece modelos; não concede história privada, conhecimentos nem confirmação infalível de identidade.
- **Controle da carne:** Pode ajustar detalhes do rosto e cheiro. Mudar de identidade de corpo inteiro usa a técnica própria.

## Técnicas adquiridas

### Máscara sem rosto

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Até mudar novamente ou descansar |
| Teste | Automático; AST+VON oposto à AST+VON sob escrutínio com evidência |

Molde rosto, proporções, voz e cheiro de uma identidade observada ou inventada. Mantém massa e porte próximos; não copia roupa, mente, poderes ou assinatura espiritual.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Estudar uma identidade

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Observe alguém por um minuto: registre três sinais públicos concretos para sustentar uma imitação e um ponto que precisará investigar. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Preparar a troca

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Próximo teste na cena |
| Teste | Automático |

Combine uma máscara já estudada com figurino preparado: +2 ao próximo teste de infiltração social. Exige material e oportunidade real; não é invisibilidade.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

As técnicas S9–7 permanecem. A máscara dura além de uma cena, corrigindo a limitação anterior; uma mudança não cura feridas nem recupera PM.

## Preparação e oposição

Ocultação de vínculos, identidades verificadas por relações e interrupção de preparação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Vidente]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
