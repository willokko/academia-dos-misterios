---
titulo: "Sequência 4 - Espreitador de Mistérios - Misticólogo"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espreitador de Mistérios"
sequencia: 4
nome_ingles: "Mysticologist"
---

# Sequência 4 - Espreitador de Mistérios - Misticólogo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espreitador de Mistérios]]. **Sequência:** 4. **Nome de referência:** Mysticologist. Tradução editorial: Misticólogo.

## O que a poção transforma

O [[Poder - Espreitador de Mistérios S4 - Autoridade de Misticólogo|pacote completo de Misticólogo]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Misticólogo.

- [[Poder - Espreitador de Mistérios S4 - Autoridade de Misticólogo#Reencenar um mito|Reencenar um mito]]
- [[Poder - Espreitador de Mistérios S4 - Autoridade de Misticólogo#Conhecimento vivo|Conhecimento vivo]]

Operação: [[Poder - Espreitador de Mistérios S4 - Autoridade de Misticólogo#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Misticólogo** no tema de conhecimento oculto, símbolos e histórias com poder. Princípio de partida: investigar sem confundir curiosidade com direito a toda resposta. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espreitador de Mistérios#S4 - Misticólogo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Espreitador de Mistérios - Mestre das Constelações]]. Próxima: [[Sequência 3 - Espreitador de Mistérios - Clarividente]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
