---
titulo: "Poder - Monstro S7 - Desvio de sorte"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Monstro"
sequencia: 7
nome_pacote: "Pacote de Sortudo — Monstro S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Monstro S7 - Desvio de sorte

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Sortudo, Monstro S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Monstro - Sortudo]] ou melhor no [[Caminho do Monstro]]. **Referência nominal:** Lucky One. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Sorte intermitente:** Uma vez por cena, ao chegar a um lugar, o jogador pode propor coincidência pequena e possível, como ferramenta ordinária esquecida. Não cria ingrediente, característica ou fortuna.

## Técnicas adquiridas

### Segunda chance

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Um teste |
| Teste | Automático |

Antes de resolver um teste seu não crítico, refaça um dado e use o novo resultado. Pode piorar.

**Limites:** Uma reação por rodada e um uso por cena. Nunca refaz crítico ou uma nova rolagem.

### Acaso protetor

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um ataque |
| Teste | Automático |

Após anunciar ataque e antes da rolagem, receba +2 DEF contra ele graças a coincidência fisicamente possível.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Encontrar oportunidade

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

O mestre oferece um detalhe aproveitável já possível no ambiente; aproveitá-lo exige sua ação normal, sem declarar vitória. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S5 permite preparar sorte em vez de depender só do acaso; limite por cena não multiplica por descanso.

## Preparação e oposição

Consequências sem teste, escolhas comprometidas e vínculos opacos. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Monstro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
