---
titulo: "Poder - Boticário S6 - Preparado de estabilidade"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Boticário"
sequencia: 6
nome_pacote: "Pacote de Professor de Poções — Boticário S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Boticário S6 - Preparado de estabilidade

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Professor de Poções, Boticário S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Boticário - Professor de Poções]] ou melhor no [[Caminho do Boticário]]. **Referência nominal:** Potions Professor. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Professor de poções:** Pode manter quatro doses sobrenaturais preparadas; são consumíveis de oficina, não poções de avanço ou objetos permanentes.

## Técnicas adquiridas

### Destilar essência

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até liberar |
| Teste | AST+AST ND10 |

Escolha cura 20 PV, resistência a um tipo de dano por um golpe ou ocultar cheiro por uma cena. Custa 25 zênites e os PM desta técnica por dose.

**Limites:** Quatro doses no total; uma ação por dose na liberação. Não acumula resistências para imunidade.

### Perfume de invisibilidade

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até liberar |
| Teste | AST+AST ND13 ao preparar |

Prepare uma dose com 50 zênites; sua liberação oculta da visão comum até atacar ou fim da cena. Odor, toque e percepção adequada ainda podem descobrir o alvo.

**Limites:** Conta no limite de quatro doses; uma ação para aplicar, sem segundo pagamento de PM.

### Antissonho

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até liberar |
| Teste | AST+AST ND10 |

Prepare dose de 25 zênites: uma ação ao ingerir concede +2 ao próximo teste contra invasão onírica e avisa o alvo quando ela começar.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5: seis doses. Ingredientes especiais de um efeito novo exigem pesquisa e aventura, não uma frase genérica.

## Preparação e oposição

Limitações de amostra, necessidade de consentimento e selos de invocação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Boticário]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
