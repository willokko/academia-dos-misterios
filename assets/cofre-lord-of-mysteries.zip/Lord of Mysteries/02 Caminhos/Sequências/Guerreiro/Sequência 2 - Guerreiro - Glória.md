---
titulo: "Sequência 2 - Guerreiro - Glória"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
sequencia: 2
nome_ingles: "Glory"
---

# Sequência 2 - Guerreiro - Glória

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Guerreiro]]. **Sequência:** 2. **Nome de referência:** Glory. Tradução editorial: Glória.

## O que a poção transforma

O [[Poder - Guerreiro S2 - Autoridade de Glória|pacote completo de Glória]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Glória.

- [[Poder - Guerreiro S2 - Autoridade de Glória#Glória manifesta|Glória manifesta]]
- [[Poder - Guerreiro S2 - Autoridade de Glória#Ocultar pela luz|Ocultar pela luz]]

Operação: [[Poder - Guerreiro S2 - Autoridade de Glória#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Glória** no tema de força, armas, proteção e declínio. Princípio de partida: escolher o que proteger e conhecer o limite da força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Guerreiro#S2 - Glória]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 3 - Guerreiro - Cavaleiro de Prata]]. Próxima: [[Sequência 1 - Guerreiro - Mão de Deus]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
