---
titulo: "Avanços do Plantador"
tipo: "poções-e-avanço"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "ritos-e-altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
---

# Avanços do Plantador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

Esta nota é a referência única de fórmulas e ritos do [[Caminho do Plantador]]. Custos e preparação: [[Poções e fórmulas]], [[Fórmulas e ingredientes]] e [[Avanço e consumo]]. Não foram verificadas receitas completas para todas as Sequências deste Caminho.

**Fórmula jogável original comum, S9–1:** uma característica íntegra da Sequência desejada, com proveniência registrada, mais auxiliares simbólicos do orçamento. Use um objeto, substância e gesto associados a **cultivo, medicina, vida e transformações orgânicas**; as quantidades e o preparo não pretendem reproduzir o romance. Sem uma característica disponível, não há poção. **Na S0, não use essa simplificação:** é preciso reunir a Unicidade e três características S1 do Caminho, além do rito e das condições do [[Módulo angelical e divino]]. Ver [[Características Beyonder]].

**Princípio geral original:** Cultivar condições para que outros vivam sem possuir seu futuro.

## S9 - Plantador

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** A primeira poção é antecedente de criação; obtenha a fórmula de um patrono e declare a dívida, sem rolagem inicial. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 9 - Plantador - Plantador]] e [[Poder - Plantador S9 - Leitura do solo]].

## S8 - Médico

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Médico numa situação com consequência: cultivar condições para que outros vivam sem possuir seu futuro. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 8 - Plantador - Médico]] e [[Poder - Plantador S8 - Cuidados de campo]].

## S7 - Sacerdote da Colheita

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Sacerdote da Colheita numa situação com consequência: cultivar condições para que outros vivam sem possuir seu futuro. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 7 - Plantador - Sacerdote da Colheita]] e [[Poder - Plantador S7 - Crescimento oportuno]].

## S6 - Biólogo

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Biólogo numa situação com consequência: cultivar condições para que outros vivam sem possuir seu futuro. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 6 - Plantador - Biólogo]] e [[Poder - Plantador S6 - Análise orgânica]].

## S5 - Druida

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Druida numa situação com consequência: cultivar condições para que outros vivam sem possuir seu futuro. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 5 - Plantador - Druida]] e [[Poder - Plantador S5 - Forma de travessia]].

## S4 - Alquimista Antigo

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Alquimista Antigo numa situação com consequência: cultivar condições para que outros vivam sem possuir seu futuro. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Plantador S4 - Autoridade de Alquimista Antigo]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 4 - Plantador - Alquimista Antigo]] e [[Poder - Plantador S4 - Autoridade de Alquimista Antigo]].

## S3 - Portador do Caixão

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Portador do Caixão numa situação com consequência: cultivar condições para que outros vivam sem possuir seu futuro. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Plantador S3 - Autoridade de Portador do Caixão]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 3 - Plantador - Portador do Caixão]] e [[Poder - Plantador S3 - Autoridade de Portador do Caixão]].

## S2 - Matriarca da Desolação

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Matriarca da Desolação numa situação com consequência: cultivar condições para que outros vivam sem possuir seu futuro. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Plantador S2 - Autoridade de Matriarca da Desolação]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 2 - Plantador - Matriarca da Desolação]] e [[Poder - Plantador S2 - Autoridade de Matriarca da Desolação]].

## S1 - Caminhante da Natureza

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Caminhante da Natureza numa situação com consequência: cultivar condições para que outros vivam sem possuir seu futuro. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Plantador S1 - Autoridade de Caminhante da Natureza]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 1 - Plantador - Caminhante da Natureza]] e [[Poder - Plantador S1 - Autoridade de Caminhante da Natureza]].

## S0 - Mãe

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Mãe numa situação com consequência: cultivar condições para que outros vivam sem possuir seu futuro. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Plantador S0 - Autoridade de Mãe]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 0 - Plantador - Mãe]] e [[Poder - Plantador S0 - Autoridade de Mãe]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
