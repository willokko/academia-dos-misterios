---
titulo: "Caminho do Plantador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Plantador"
nome_divino: "Mãe"
referencia: "https://lordofthemysteries.fandom.com/wiki/Mother_Pathway"
---

# Caminho do Plantador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Mãe. **Tema:** Cultivo, medicina, vida e transformações orgânicas. **Função:** Suporte, sobrevivência e ambiente.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Plantador - Plantador|Plantador]] | [[Poder - Plantador S9 - Leitura do solo|3 técnicas]] |
| 8 | [[Sequência 8 - Plantador - Médico|Médico]] | [[Poder - Plantador S8 - Cuidados de campo|3 técnicas]] |
| 7 | [[Sequência 7 - Plantador - Sacerdote da Colheita|Sacerdote da Colheita]] | [[Poder - Plantador S7 - Crescimento oportuno|3 técnicas]] |
| 6 | [[Sequência 6 - Plantador - Biólogo|Biólogo]] | [[Poder - Plantador S6 - Análise orgânica|3 técnicas]] |
| 5 | [[Sequência 5 - Plantador - Druida|Druida]] | [[Poder - Plantador S5 - Forma de travessia|3 técnicas]] |
| 4 | [[Sequência 4 - Plantador - Alquimista Antigo|Alquimista Antigo]] | [[Poder - Plantador S4 - Autoridade de Alquimista Antigo|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Plantador - Portador do Caixão|Portador do Caixão]] | [[Poder - Plantador S3 - Autoridade de Portador do Caixão|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Plantador - Matriarca da Desolação|Matriarca da Desolação]] | [[Poder - Plantador S2 - Autoridade de Matriarca da Desolação|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Plantador - Caminhante da Natureza|Caminhante da Natureza]] | [[Poder - Plantador S1 - Autoridade de Caminhante da Natureza|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Plantador - Mãe|Mãe]] | [[Poder - Plantador S0 - Autoridade de Mãe|2 técnicas + operação]] |

## Como jogar

Cultivar condições para que outros vivam sem possuir seu futuro. As ferramentas da S9 são mestre do cultivo. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Média a alta: cura e vida. **Oposição:** Ambiente estéril, escassez de amostra e contaminação da fonte. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Plantador]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Mother_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
