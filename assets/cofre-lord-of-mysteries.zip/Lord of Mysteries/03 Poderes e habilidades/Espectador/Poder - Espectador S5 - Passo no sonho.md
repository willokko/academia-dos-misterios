---
titulo: "Poder - Espectador S5 - Passo no sonho"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espectador"
sequencia: 5
nome_pacote: "Pacote de Caminhante dos Sonhos — Espectador S5"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Espectador S5 - Passo no sonho

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Caminhante dos Sonhos, Espectador S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Espectador - Caminhante dos Sonhos]] ou melhor no [[Caminho do Espectador]]. **Referência nominal:** Dreamwalker. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Corpo e sonho:** Reconhece quando está num sonho que visitou por sua técnica; o corpo fica vulnerável fora dele.
- **Limites da imagem:** Distingue lembrança alegada de evento verificado; um sonho não é gravação infalível.

## Técnicas adquiridas

### Entrar no sonho

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Dez minutos |
| Alcance | Toque ou vínculo ritual confirmado |
| Duração | Até dez minutos |
| Teste | Automático com consentimento; AST+VON contra DEF.M se resistido |

Visite o sonho de uma pessoa adormecida próxima ou ligada por vestígio pertinente. Pode conversar, buscar uma imagem e perceber uma porta mental protegida.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Moldar o cenário

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena onírica |
| Teste | AST+VON oposto à AST+VON |

Altere um cenário do sonho para reenquadrar uma lembrança ou testar uma hipótese. Um NPC resistente faz oposição; o sucesso fornece uma pista ou avança tratamento em uma seção, sem modificar passado.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Sair com companhia

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma travessia |
| Teste | Automático; AST+VON ND13 contra prisão |

Leve dois voluntários para fora de um sonho comum ou de sua própria visita. Contra prisão onírica, crie Saída 0/4 e contribua com esse teste; a técnica cria a possibilidade de fuga.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

A S4 amplia trabalho individual para manipulação de padrões coletivos; os participantes continuam com suas ações próprias.

## Preparação e oposição

Máscaras sociais treinadas, registros materiais e sujeitos sem mente acessível. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espectador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
