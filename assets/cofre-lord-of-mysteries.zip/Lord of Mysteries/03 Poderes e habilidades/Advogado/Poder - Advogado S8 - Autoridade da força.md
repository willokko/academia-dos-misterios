---
titulo: "Poder - Advogado S8 - Autoridade da força"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Advogado"
sequencia: 8
nome_pacote: "Pacote de Bárbaro — Advogado S8"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Advogado S8 - Autoridade da força

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Bárbaro, Advogado S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Advogado - Bárbaro]] ou melhor no [[Caminho do Advogado]]. **Referência nominal:** Barbarian. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Corpo do bárbaro:** +2 em VIG para erguer, quebrar e suportar esforço. A força não reduz capacidade de pensar ou decidir.

## Técnicas adquiridas

### Força bárbara

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Corpo a corpo |
| Duração | Instantânea |
| Teste | VIG+VIG contra DEF |

Um alvo sofre RA+15 de dano físico em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Intimidação por demonstração

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | VIG+VIG ND10 |

Rompa ou erga um obstáculo inerte pequeno e ganhe +2 ao próximo teste de negociação apoiado nessa demonstração. Não causa dano a pessoa na mesma ação.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Avanço obstinado

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

+2 ao próximo Objetivo para atravessar contenção física; não cruza selo espiritual.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S7 usa a interação para construir suborno, não para perder todas as limitações da ordem.

## Preparação e oposição

Termos claros, ausência de troca aceita e jurisdição rival. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Advogado]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
