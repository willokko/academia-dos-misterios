---
titulo: "Poder - Coletor de Cadáveres S9 - Exame do último vestígio"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Coletor de Cadáveres"
sequencia: 9
nome_pacote: "Pacote de Coletor de Cadáveres — Coletor de Cadáveres S9"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Coletor de Cadáveres S9 - Exame do último vestígio

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Coletor de Cadáveres, Coletor de Cadáveres S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Coletor de Cadáveres - Coletor de Cadáveres]] ou melhor no [[Caminho do Coletor de Cadáveres]]. **Referência nominal:** Corpse Collector. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Olho da morte:** Enxerga presenças espirituais expostas e distingue corpo morto de vivo comum; não atravessa disfarce superior.
- **Ofício funerário:** Manipula restos e conhece cuidados de preservação; miasma ordinário de cadáver não o deixa envenenado.

## Técnicas adquiridas

### Ler os restos

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Examine um corpo: obtenha causa física aparente ou tempo aproximado da morte, e um sinal que sustenta a conclusão. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Preservar o vestígio

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Toque |
| Duração | Até o próximo descanso |
| Teste | Automático |

Preserve um cadáver ou vestígio para que não perca detalhes por deterioração ordinária até o próximo descanso.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Perceber o fim

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Descubra se um vestígio de morte tem influência espiritual ativa, sem contatar a alma. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S7 conversa diretamente com espíritos; o cadáver não fornece lembranças na S9.

## Preparação e oposição

Purificação, restos sem identidade e espíritos sob domínio alheio. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Coletor de Cadáveres]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
