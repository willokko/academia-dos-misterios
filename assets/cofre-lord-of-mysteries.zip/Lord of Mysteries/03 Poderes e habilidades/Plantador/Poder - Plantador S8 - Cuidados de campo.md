---
titulo: "Poder - Plantador S8 - Cuidados de campo"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Plantador"
sequencia: 8
nome_pacote: "Pacote de Médico — Plantador S8"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Plantador S8 - Cuidados de campo

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Médico, Plantador S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Plantador - Médico]] ou melhor no [[Caminho do Plantador]]. **Referência nominal:** Doctor. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Visão de saúde:** Enxerga desequilíbrios corporais aparentes com exame; causa espiritual oculta ainda precisa ser investigada.

## Técnicas adquiridas

### Tratamento

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Toque |
| Duração | Instantânea |
| Teste | Automático |

Um voluntário recupera 25 PV. Exige toque ou ferramenta de atendimento, sem substituir um teste de cirurgia grave.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Remover debilidade

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Toque |
| Duração | Instantânea |
| Teste | Automático se identificado |

Remova fraco ou envenenado de causa fisiológica identificada em um voluntário. Uma condição por uso.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Cirurgia guiada

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Um intervalo de trabalho |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+AST ND13 |

Com instrumentos e tempo, contribua com +2 para Objetivo de reparar ferida grave. O procedimento não revive morto ou remove característica.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6 amplia conhecimento biológico; diagnóstico não é controle sobre o corpo de um PJ.

## Preparação e oposição

Ambiente estéril, escassez de amostra e contaminação da fonte. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Plantador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
