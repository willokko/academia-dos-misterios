---
titulo: "Avanços do Espectador"
tipo: "poções-e-avanço"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "ritos-e-altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
---

# Avanços do Espectador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

Esta nota é a referência única de fórmulas e ritos do [[Caminho do Espectador]]. Custos e preparação: [[Poções e fórmulas]], [[Fórmulas e ingredientes]] e [[Avanço e consumo]]. Não foram verificadas receitas completas para todas as Sequências deste Caminho.

**Fórmula jogável original comum, S9–1:** uma característica íntegra da Sequência desejada, com proveniência registrada, mais auxiliares simbólicos do orçamento. Use um objeto, substância e gesto associados a **observação, emoções, sonhos e construção mental**; as quantidades e o preparo não pretendem reproduzir o romance. Sem uma característica disponível, não há poção. **Na S0, não use essa simplificação:** é preciso reunir a Unicidade e três características S1 do Caminho, além do rito e das condições do [[Módulo angelical e divino]]. Ver [[Características Beyonder]].

**Princípio geral original:** Observar padrões, ajudar sem reduzir uma pessoa a um papel.

## S9 - Espectador

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** A primeira poção é antecedente de criação; obtenha a fórmula de um patrono e declare a dívida, sem rolagem inicial. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 9 - Espectador - Espectador]] e [[Poder - Espectador S9 - Leitura da plateia]].

## S8 - Telepata

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Telepata numa situação com consequência: observar padrões, ajudar sem reduzir uma pessoa a um papel. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 8 - Espectador - Telepata]] e [[Poder - Espectador S8 - Eco de pensamento]].

## S7 - Psiquiatra

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Psiquiatra numa situação com consequência: observar padrões, ajudar sem reduzir uma pessoa a um papel. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 7 - Espectador - Psiquiatra]] e [[Poder - Espectador S7 - Recompor a identidade]].

## S6 - Hipnotizador

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Hipnotizador numa situação com consequência: observar padrões, ajudar sem reduzir uma pessoa a um papel. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 6 - Espectador - Hipnotizador]] e [[Poder - Espectador S6 - Sugestão de um gesto]].

## S5 - Caminhante dos Sonhos

> [!quote] Rito relatado pela wiki
> Procurar uma harpia no mundo espiritual, firmar contrato e, segurando uma pena da cauda, consumir sob alegria ou raiva intensas. [Fonte secundária](https://lordofthemysteries.fandom.com/wiki/Visionary_Pathway/Advancement). O procedimento numérico abaixo continua sendo adaptação.

**Prova original opcional para esta campanha:** Demonstre o papel de Caminhante dos Sonhos numa situação com consequência: observar padrões, ajudar sem reduzir uma pessoa a um papel. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 5 - Espectador - Caminhante dos Sonhos]] e [[Poder - Espectador S5 - Passo no sonho]].

## S4 - Manipulador

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Manipulador numa situação com consequência: observar padrões, ajudar sem reduzir uma pessoa a um papel. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Espectador S4 - Autoridade de Manipulador]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 4 - Espectador - Manipulador]] e [[Poder - Espectador S4 - Autoridade de Manipulador]].

## S3 - Tecelão de Sonhos

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Tecelão de Sonhos numa situação com consequência: observar padrões, ajudar sem reduzir uma pessoa a um papel. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Espectador S3 - Autoridade de Tecelão de Sonhos]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 3 - Espectador - Tecelão de Sonhos]] e [[Poder - Espectador S3 - Autoridade de Tecelão de Sonhos]].

## S2 - Discernidor

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Discernidor numa situação com consequência: observar padrões, ajudar sem reduzir uma pessoa a um papel. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Espectador S2 - Autoridade de Discernidor]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 2 - Espectador - Discernidor]] e [[Poder - Espectador S2 - Autoridade de Discernidor]].

## S1 - Autor

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Autor numa situação com consequência: observar padrões, ajudar sem reduzir uma pessoa a um papel. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Espectador S1 - Autoridade de Autor]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 1 - Espectador - Autor]] e [[Poder - Espectador S1 - Autoridade de Autor]].

## S0 - Visionário

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Visionário numa situação com consequência: observar padrões, ajudar sem reduzir uma pessoa a um papel. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Espectador S0 - Autoridade de Visionário]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 0 - Espectador - Visionário]] e [[Poder - Espectador S0 - Autoridade de Visionário]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
