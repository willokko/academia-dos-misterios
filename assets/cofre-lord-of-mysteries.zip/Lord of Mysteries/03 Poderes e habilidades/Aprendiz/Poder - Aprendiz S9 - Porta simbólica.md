---
titulo: "Poder - Aprendiz S9 - Porta simbólica"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Aprendiz"
sequencia: 9
nome_pacote: "Pacote de Aprendiz — Aprendiz S9"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Aprendiz S9 - Porta simbólica

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Aprendiz, Aprendiz S9.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 9 - Aprendiz - Aprendiz]] ou melhor no [[Caminho do Aprendiz]]. **Referência nominal:** Apprentice. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Sentido de passagem:** Reconhece a estrutura de uma porta ou recinto adjacente conhecido. Selo produz aviso, não conhecimento do outro lado.

## Técnicas adquiridas

### Abrir passagem

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Toque |
| Duração | Instantânea |
| Teste | Automático; AST+VON ND10 sob pressão |

Atravesse porta ou parede fina inerte conhecida, sem cruzar selo ou corpo.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Examinar o limiar

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Identifique fechadura, proteção ritual ou interferência espacial exposta. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Fuga por fresta

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Um teste |
| Teste | Automático |

+2 ao próximo Objetivo para fugir por passagem fisicamente possível. Não abre outra porta como ação gratuita.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5 transforma a passagem em viagem espiritual com passageiros.

## Preparação e oposição

Selos, destinos não conhecidos e falta de observação prévia. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Aprendiz]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
