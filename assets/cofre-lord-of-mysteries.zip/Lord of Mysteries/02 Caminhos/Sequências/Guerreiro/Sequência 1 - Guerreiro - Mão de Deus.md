---
titulo: "Sequência 1 - Guerreiro - Mão de Deus"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
sequencia: 1
nome_ingles: "Hand of God"
---

# Sequência 1 - Guerreiro - Mão de Deus

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Guerreiro]]. **Sequência:** 1. **Nome de referência:** Hand of God. Tradução editorial: Mão de Deus.

## O que a poção transforma

O [[Poder - Guerreiro S1 - Autoridade de Mão de Deus|pacote completo de Mão de Deus]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Mão de Deus.

- [[Poder - Guerreiro S1 - Autoridade de Mão de Deus#Mão esmagadora|Mão esmagadora]]
- [[Poder - Guerreiro S1 - Autoridade de Mão de Deus#Amparo da mão|Amparo da mão]]

Operação: [[Poder - Guerreiro S1 - Autoridade de Mão de Deus#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Mão de Deus** no tema de força, armas, proteção e declínio. Princípio de partida: escolher o que proteger e conhecer o limite da força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Guerreiro#S1 - Mão de Deus]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Guerreiro - Glória]]. Próxima: [[Sequência 0 - Guerreiro - Gigante do Crepúsculo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
