---
titulo: "Poder - Vidente S5 - Fios da marionete"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Vidente"
sequencia: 5
nome_pacote: "Pacote de Marionetista — Vidente S5"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Vidente S5 - Fios da marionete

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Marionetista, Vidente S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Vidente - Marionetista]] ou melhor no [[Caminho do Vidente]]. **Referência nominal:** Marionettist. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Visão dos fios:** Enxerga fios espirituais de criaturas presentes, inclusive quando o corpo está invisível sem ocultar os fios. Selos e ocultação de patamar maior exigem investigação.
- **Repertório acumulado:** Todas as técnicas anteriores continuam disponíveis; apenas uma ação principal e uma reação de Caminho por rodada.

## Técnicas adquiridas

### Capturar os fios

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até romper ou concluir |
| Teste | AST+VON contra DEF.M |

Inicie Captura 0/6 em um alvo vivo na cena, pagando 10 PM; cada ação posterior paga 5 PM e testa novamente. O primeiro sucesso deixa o alvo lento enquanto mantiver o contato. Ao completar contra NPC, converte-o numa marionete persistente; sua pessoa morreu. A decisão e as consequências são explícitas.

**Limites:** Só uma captura por vez. Linha rompida apaga duas seções; alvo ou aliado pode usar Objetivo VON+VON ND10 para apagar seções. Contra PJs, usar Controle mental e agência; não converte um PJ sem acordo.

### Operar marionete

| Parâmetro | Regra |
|---|---|
| Custo | PM da técnica ou 0 PM para ataque ordinário |
| Ação | Poder |
| Alcance | Mesma cena; até 100 m |
| Duração | Uma ação |
| Teste | Conforme a técnica usada |

Gaste sua ação para usar um ataque ordinário ou uma técnica ativa da ficha da marionete S9–5, pagando os PM dela com sua reserva. Pode observar pelos sentidos dela. Até duas marionetes mantidas, uma operando por vez.

**Limites:** Não cria turnos. Corpo conserva identidade física e características reais; não imprime cópias dos poderes do controlador nesta Sequência. PV e destruição seguem Servos e repertórios.

### Olhos emprestados

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Um minuto |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Observe por uma marionete vinculada por até dez minutos, mantendo seu corpo desatento. Obtenha apenas aquilo que ela de fato percebe. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

Na S4, operar também permite troca de posição e partilha de técnicas pelo vínculo, conforme o novo pacote. Marionetes deixaram de ser um controle de um turno, sem ganhar iniciativas gratuitas.

## Preparação e oposição

Ocultação de vínculos, identidades verificadas por relações e interrupção de preparação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Vidente]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
