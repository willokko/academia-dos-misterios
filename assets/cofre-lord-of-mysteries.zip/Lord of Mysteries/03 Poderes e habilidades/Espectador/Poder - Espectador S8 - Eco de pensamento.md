---
titulo: "Poder - Espectador S8 - Eco de pensamento"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espectador"
sequencia: 8
nome_pacote: "Pacote de Telepata — Espectador S8"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Espectador S8 - Eco de pensamento

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Telepata, Espectador S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Espectador - Telepata]] ou melhor no [[Caminho do Espectador]]. **Referência nominal:** Telepathist. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Percepção mental:** Distingue agitação, concentração e presença de mente acessível na cena; não lê conteúdo sem uma técnica.
- **Observação aprofundada:** Sua memória inclui imagens mentais efetivamente recebidas, com a incerteza da pessoa de origem.

## Técnicas adquiridas

### Eco de pensamento

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Receba uma palavra ou imagem da mente superficial de um alvo. Contra resistência, AST+VON contra DEF.M; falha revela o contato. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Vínculo telepático

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Um voluntário |
| Duração | Uma cena |
| Teste | Automático |

Você e um voluntário presente trocam frases silenciosas durante a cena. Não transmite sentidos nem atravessa selo mental.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Comparar gesto e mente

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Compare uma emoção observada com um impulso recebido: obtenha uma discrepância ou confirme sua coerência. É leitura do estado atual, não verdade objetiva. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

## Evolução e acúmulo

S7: vínculo alcança dois voluntários pelo mesmo custo. S5: pode manter o vínculo com um participante de um sonho visitado enquanto ambos permanecerem nele.

## Preparação e oposição

Máscaras sociais treinadas, registros materiais e sujeitos sem mente acessível. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espectador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
