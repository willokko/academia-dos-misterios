---
titulo: "Sequência 1 - Advogado - Príncipe da Abolição"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Advogado"
sequencia: 1
nome_ingles: "Prince of Abolition"
---

# Sequência 1 - Advogado - Príncipe da Abolição

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Advogado]]. **Sequência:** 1. **Nome de referência:** Prince of Abolition. Tradução editorial: Príncipe da Abolição.

## O que a poção transforma

O [[Poder - Advogado S1 - Autoridade de Príncipe da Abolição|pacote completo de Príncipe da Abolição]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Príncipe da Abolição.

- [[Poder - Advogado S1 - Autoridade de Príncipe da Abolição#Redefinir suporte|Redefinir suporte]]
- [[Poder - Advogado S1 - Autoridade de Príncipe da Abolição#Abolir cláusula|Abolir cláusula]]

Operação: [[Poder - Advogado S1 - Autoridade de Príncipe da Abolição#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Príncipe da Abolição** no tema de brechas, suborno e distorção de regras. Princípio de partida: conhecer a regra antes de escolher a brecha e assumir o efeito de usá-la. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Advogado#S1 - Príncipe da Abolição]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Advogado - Duque da Entropia]]. Próxima: [[Sequência 0 - Advogado - Imperador Negro]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
