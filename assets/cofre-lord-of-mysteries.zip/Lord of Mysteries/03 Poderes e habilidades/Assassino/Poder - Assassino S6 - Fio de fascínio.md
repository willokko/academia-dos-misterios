---
titulo: "Poder - Assassino S6 - Fio de fascínio"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Assassino"
sequencia: 6
nome_pacote: "Pacote de Prazer — Assassino S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Assassino S6 - Fio de fascínio

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Prazer, Assassino S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Assassino - Prazer]] ou melhor no [[Caminho do Assassino]]. **Referência nominal:** Pleasure. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Fios sutis:** Pode estender fios finos de cabelo para sentir toque e movimento num pequeno limite preparado; não lê mentes nem dispara ataques gratuitos.

## Técnicas adquiridas

### Fios de contenção

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica lento e um feixe prende o alvo a um apoio; cortar os fios ou vencer Objetivo VIG+VIG ND10 remove a contenção.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

### Casulo

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Até um golpe ou próximo turno |
| Teste | Automático |

Receba redução 15 no próximo dano e recupere 10 PV. Enquanto o casulo durar não pode deslocar-se; rompê-lo encerra a proteção.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Presença fascinante

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o próximo turno |
| Teste | AST+VON contra DEF.M |

Explore atenção já estabelecida: em sucesso, NPC hesita em atacar você até o próximo turno e pode dirigir a ação a outro objetivo. PJ escolhe efeito equivalente de hesitação. Não exige desejo ou intimidade.

**Limites:** Uma tentativa por alvo por cena; dano seu encerra o efeito.

## Evolução e acúmulo

S5 pode manipular pequenos objetos com fios e preparar reflexos mais amplos; não ganha um servo invisível com iniciativa.

## Preparação e oposição

Luz, espelhos preparados, distanciamento e purificação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Assassino]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
