---
titulo: "Sequência 7 - Monstro - Sortudo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 7
nome_ingles: "Lucky One"
---

# Sequência 7 - Monstro - Sortudo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 7. **Nome de referência:** Lucky One. Tradução editorial: Sortudo.

## O que a poção transforma

O [[Poder - Monstro S7 - Desvio de sorte|pacote completo de Sortudo]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Sorte intermitente.

- [[Poder - Monstro S7 - Desvio de sorte#Segunda chance|Segunda chance]]
- [[Poder - Monstro S7 - Desvio de sorte#Acaso protetor|Acaso protetor]]
- [[Poder - Monstro S7 - Desvio de sorte#Encontrar oportunidade|Encontrar oportunidade]]



## Atuação e digestão

Interpretação original do papel **Sortudo** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S7 - Sortudo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Monstro - Robô]]. Próxima: [[Sequência 6 - Monstro - Sacerdote da Calamidade]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
