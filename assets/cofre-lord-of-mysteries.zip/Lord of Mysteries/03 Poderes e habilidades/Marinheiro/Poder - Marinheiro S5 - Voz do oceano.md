---
titulo: "Poder - Marinheiro S5 - Voz do oceano"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Marinheiro"
sequencia: 5
nome_pacote: "Pacote de Cantor do Oceano — Marinheiro S5"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Marinheiro S5 - Voz do oceano

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Cantor do Oceano, Marinheiro S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Marinheiro - Cantor do Oceano]] ou melhor no [[Caminho do Marinheiro]]. **Referência nominal:** Ocean Songster. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Habitante das águas:** Respira sob a água ordinária e se orienta nela; pressão sobrenatural e contaminação ainda importam.
- **Afinidade com criaturas marinhas:** Pode estabelecer comunicação básica com animais aquáticos presentes, limitada à percepção deles e sem obediência automática.

## Técnicas adquiridas

### Relâmpago do oceano

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+25 de dano raio em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Canto tempestuoso

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo atingido fica abalado e sofre RA+10 de raio; se desejar dois alvos, pague 10 PM adicionais e teste separadamente.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Ordem às águas

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | AST+VON ND13 sob oposição |

Mova água existente para erguer um apoio, separar uma rota de travessia ou impedir uma embarcação pequena de derivar. Sob disputa, abra um Objetivo de quatro seções; um teste por ação.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4 amplia fenômenos para cataclismos delimitados; S3 governa uma costa. A passagem de escala não depende apenas de aumentar o dano de raio.

## Preparação e oposição

Locais sem acesso aéreo/aquático, preparação interrompida e proteção elemental. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Marinheiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
