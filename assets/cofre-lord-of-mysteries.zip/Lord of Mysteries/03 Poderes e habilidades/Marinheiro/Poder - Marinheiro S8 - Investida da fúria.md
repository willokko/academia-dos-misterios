---
titulo: "Poder - Marinheiro S8 - Investida da fúria"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Marinheiro"
sequencia: 8
nome_pacote: "Pacote de Povo da Fúria — Marinheiro S8"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Marinheiro S8 - Investida da fúria

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Povo da Fúria, Marinheiro S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Marinheiro - Povo da Fúria]] ou melhor no [[Caminho do Marinheiro]]. **Referência nominal:** Folk of Rage. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Vigor tempestuoso:** +2 em testes de VIG para arrombar, erguer e resistir a esforço; não altera VIG básico nem recursos.
- **Fúria escolhida:** A intensidade é decidida pelo jogador. Não recebe licença para turnos extras ou agressão compulsória.

## Técnicas adquiridas

### Ira da tempestade

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Até um acerto ou próximo turno |
| Teste | Automático |

Até o próximo turno, seus golpes corporais recebem +5 dano e sua DEF cai em 2. Só vale para um acerto, sem ação de ataque adicional.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Impacto furioso

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Corpo a corpo |
| Duração | Instantânea |
| Teste | VIG+VIG contra DEF |

Um alvo sofre RA+15 de dano físico em sucesso. Pode trocar 5 de dano por deixar o alvo fraco até o próximo turno dele.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Acumular o golpe

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Guarda |
| Alcance | Pessoal |
| Duração | Até seu próximo turno |
| Teste | Automático |

Faça Guarda e retenha a energia: pague 5 PM além da ação normal. Seu próximo Impacto furioso até o fim do próximo turno recebe +5 dano. Um preparo por vez; receber vários golpes não multiplica o bônus.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S7 permite levar o impacto à água sem penalidade de meio. S5 o modo ofensivo passa a RA+25 por 20 PM, substituindo a fórmula anterior, sem empilhar modos.

## Preparação e oposição

Locais sem acesso aéreo/aquático, preparação interrompida e proteção elemental. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Marinheiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
