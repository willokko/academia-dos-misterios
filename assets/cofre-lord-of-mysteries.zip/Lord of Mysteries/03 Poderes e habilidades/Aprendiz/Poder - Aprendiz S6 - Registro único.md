---
titulo: "Poder - Aprendiz S6 - Registro único"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Aprendiz"
sequencia: 6
nome_pacote: "Pacote de Escriba — Aprendiz S6"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Aprendiz S6 - Registro único

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Escriba, Aprendiz S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Aprendiz - Escriba]] ou melhor no [[Caminho do Aprendiz]]. **Referência nominal:** Scribe. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Livro espiritual:** Oito espaços, até dois com técnicas S5–6 e os restantes S7–9. Cada registro contém um uso e persiste até ser consumido, sem sumir ao descansar.

## Técnicas adquiridas

### Registrar técnica

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até consumir |
| Teste | AST+VON, ND conforme o grau |

Após observar técnica integralmente: ND10 para S7–9, ND13 para S5–6. Falhar exige outra demonstração. Registre um uso elegível.

**Limites:** Sem registros de passivo, cópia, roubo, autoridade ou efeito que gere poderes.

### Liberar registro

| Parâmetro | Regra |
|---|---|
| Custo | PM da técnica liberada |
| Ação | Conforme técnica |
| Alcance | Cena |
| Duração | Conforme técnica |
| Teste | Conforme técnica |

Use a técnica com ação, PM, teste e limitações originais; consuma um registro. Não paga novamente o custo de registrar.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Compartilhar abertura

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o fim do turno |
| Teste | Como Abrir passagem |

Uma passagem criada por você permanece até o fim do turno para um voluntário em contato. Não supera selo que já a barrava.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5: doze espaços, até quatro de S5–6. Essas capacidades de armazenamento são limites editoriais, não quantidades literais da wiki.

## Preparação e oposição

Selos, destinos não conhecidos e falta de observação prévia. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Aprendiz]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
