---
titulo: "Sequência 4 - Sábio - Alquimista"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Sábio"
sequencia: 4
nome_ingles: "Alchemist"
---

# Sequência 4 - Sábio - Alquimista

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Sábio]]. **Sequência:** 4. **Nome de referência:** Alchemist. Tradução editorial: Alquimista.

## O que a poção transforma

O [[Poder - Sábio S4 - Autoridade de Alquimista|pacote completo de Alquimista]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Alquimista.

- [[Poder - Sábio S4 - Autoridade de Alquimista#Transmutação de oficina|Transmutação de oficina]]
- [[Poder - Sábio S4 - Autoridade de Alquimista#Dispositivo alquímico|Dispositivo alquímico]]

Operação: [[Poder - Sábio S4 - Autoridade de Alquimista#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Alquimista** no tema de memória, técnica, avaliação e fabricação. Princípio de partida: compreender como algo funciona e responder pelas consequências de construí-lo. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Sábio#S4 - Alquimista]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Sábio - Astrônomo]]. Próxima: [[Sequência 3 - Sábio - Erudito Arcano]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
