---
titulo: "Sequência 6 - Árbitro - Juiz"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 6
nome_ingles: "Judge"
---

# Sequência 6 - Árbitro - Juiz

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 6. **Nome de referência:** Judge. Tradução editorial: Juiz.

## O que a poção transforma

O [[Poder - Árbitro S6 - Proibição enunciada|pacote completo de Juiz]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Autoridade do juiz.

- [[Poder - Árbitro S6 - Proibição enunciada#Proibição|Proibição]]
- [[Poder - Árbitro S6 - Proibição enunciada#Veredito|Veredito]]
- [[Poder - Árbitro S6 - Proibição enunciada#Pena de restrição|Pena de restrição]]



## Atuação e digestão

Interpretação original do papel **Juiz** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S6 - Juiz]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Árbitro - Interrogador]]. Próxima: [[Sequência 5 - Árbitro - Paladino Disciplinar]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
