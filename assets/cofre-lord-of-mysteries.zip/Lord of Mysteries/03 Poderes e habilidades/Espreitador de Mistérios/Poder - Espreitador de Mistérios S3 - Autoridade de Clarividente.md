---
titulo: "Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Espreitador de Mistérios"
sequencia: 3
nome_pacote: "Pacote de Clarividente — Espreitador de Mistérios S3"
quantidade_tecnicas: 2
quantidade_capacidades: 1
quantidade_operacoes: 1
---

# Poder - Espreitador de Mistérios S3 - Autoridade de Clarividente

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Clarividente, Espreitador de Mistérios S3.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 3 - Espreitador de Mistérios - Clarividente]] ou melhor no [[Caminho do Espreitador de Mistérios]]. **Referência nominal:** Clairvoyant. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Transformação de Clarividente:** Clarividência exige vínculo e é contestável por ocultação, sem virar vigilância mundial automática.

## Técnicas adquiridas

### Olhar distante

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND13 em obstáculo sem ficha |

Veja por um vestígio preparado um local conhecido por uma cena; seu corpo fica desatento.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

### Reconhecer o oculto

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Poder |
| Alcance | Um alvo, recinto ou passagem da cena; vínculo quando exigido |
| Duração | Uma cena, salvo duração expressa; dano uma vez |
| Teste | Automático sem oposição; AST+VON contra DEF.M se hostil; ND13 em obstáculo sem ficha |

Revele um sinal de uma presença escondida equivalente em oposição, ou inferior sem oposição extraordinária.

**Limites:** Não encerra uma fonte de autoridade equivalente persistente sem operação; não cria ação, característica ou alma gratuita.

## Feito de operação

Descobrir uma estrutura oculta reunindo fontes que a própria ocultação não conseguiu apagar.

**Procedimento:** [[Módulo dos santos]]. Reúna duas chaves, declare alvo, transformação e consequência do perigo. O portador inicia uma vez por cena, ação Poder, 20 PM e primeiro teste ND13; objetivo de 10 seções. Cada PJ contribui uma vez por rodada com Objetivo e margens normais, sem pagar novamente a taxa. Não use esse relógio para atrasar as aplicações locais sem oposição equivalente.

## Evolução e acúmulo

Conserva todos os pacotes anteriores. O novo grau amplia a natureza do que pode fazer, não soma automaticamente dano ou bônus de todas as formas. Capacidades de operação seguem seu módulo e Escala e confrontos sobrenaturais.

## Preparação e oposição

Informação falsa, falta de correspondência e revelação vedada. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Espreitador de Mistérios]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
