---
titulo: "Avanços do Monstro"
tipo: "poções-e-avanço"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "ritos-e-altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
---

# Avanços do Monstro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

Esta nota é a referência única de fórmulas e ritos do [[Caminho do Monstro]]. Custos e preparação: [[Poções e fórmulas]], [[Fórmulas e ingredientes]] e [[Avanço e consumo]]. Não foram verificadas receitas completas para todas as Sequências deste Caminho.

**Fórmula jogável original comum, S9–1:** uma característica íntegra da Sequência desejada, com proveniência registrada, mais auxiliares simbólicos do orçamento. Use um objeto, substância e gesto associados a **intuição, sorte, infortúnio e ciclos**; as quantidades e o preparo não pretendem reproduzir o romance. Sem uma característica disponível, não há poção. **Na S0, não use essa simplificação:** é preciso reunir a Unicidade e três características S1 do Caminho, além do rito e das condições do [[Módulo angelical e divino]]. Ver [[Características Beyonder]].

**Princípio geral original:** Reconhecer acaso e escolha sem usar destino como desculpa.

## S9 - Monstro

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** A primeira poção é antecedente de criação; obtenha a fórmula de um patrono e declare a dívida, sem rolagem inicial. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 9 - Monstro - Monstro]] e [[Poder - Monstro S9 - Pressentir a ruptura]].

## S8 - Robô

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Robô numa situação com consequência: reconhecer acaso e escolha sem usar destino como desculpa. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 8 - Monstro - Robô]] e [[Poder - Monstro S8 - Rotina calculada]].

## S7 - Sortudo

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Sortudo numa situação com consequência: reconhecer acaso e escolha sem usar destino como desculpa. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 7 - Monstro - Sortudo]] e [[Poder - Monstro S7 - Desvio de sorte]].

## S6 - Sacerdote da Calamidade

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Sacerdote da Calamidade numa situação com consequência: reconhecer acaso e escolha sem usar destino como desculpa. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 6 - Monstro - Sacerdote da Calamidade]] e [[Poder - Monstro S6 - Aviso de calamidade]].

## S5 - Vencedor

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Vencedor numa situação com consequência: reconhecer acaso e escolha sem usar destino como desculpa. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 5 - Monstro - Vencedor]] e [[Poder - Monstro S5 - Janela do vencedor]].

## S4 - Mago do Infortúnio

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Mago do Infortúnio numa situação com consequência: reconhecer acaso e escolha sem usar destino como desculpa. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Monstro S4 - Autoridade de Mago do Infortúnio]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 4 - Monstro - Mago do Infortúnio]] e [[Poder - Monstro S4 - Autoridade de Mago do Infortúnio]].

## S3 - Caminhante do Caos

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Caminhante do Caos numa situação com consequência: reconhecer acaso e escolha sem usar destino como desculpa. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Monstro S3 - Autoridade de Caminhante do Caos]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 3 - Monstro - Caminhante do Caos]] e [[Poder - Monstro S3 - Autoridade de Caminhante do Caos]].

## S2 - Adivinho

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Adivinho numa situação com consequência: reconhecer acaso e escolha sem usar destino como desculpa. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Monstro S2 - Autoridade de Adivinho]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 2 - Monstro - Adivinho]] e [[Poder - Monstro S2 - Autoridade de Adivinho]].

## S1 - Serpente de Mercúrio

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Serpente de Mercúrio numa situação com consequência: reconhecer acaso e escolha sem usar destino como desculpa. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Monstro S1 - Autoridade de Serpente de Mercúrio]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 1 - Monstro - Serpente de Mercúrio]] e [[Poder - Monstro S1 - Autoridade de Serpente de Mercúrio]].

## S0 - Roda da Fortuna

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Roda da Fortuna numa situação com consequência: reconhecer acaso e escolha sem usar destino como desculpa. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Monstro S0 - Autoridade de Roda da Fortuna]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 0 - Monstro - Roda da Fortuna]] e [[Poder - Monstro S0 - Autoridade de Roda da Fortuna]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
