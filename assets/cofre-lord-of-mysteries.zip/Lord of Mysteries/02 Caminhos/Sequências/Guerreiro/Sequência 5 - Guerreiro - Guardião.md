---
titulo: "Sequência 5 - Guerreiro - Guardião"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
sequencia: 5
nome_ingles: "Guardian"
---

# Sequência 5 - Guerreiro - Guardião

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Guerreiro]]. **Sequência:** 5. **Nome de referência:** Guardian. Tradução editorial: Guardião.

## O que a poção transforma

O [[Poder - Guerreiro S5 - Bastião de um nome|pacote completo de Guardião]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Robustez do guardião.

- [[Poder - Guerreiro S5 - Bastião de um nome#Muralha de proteção|Muralha de proteção]]
- [[Poder - Guerreiro S5 - Bastião de um nome#Interpor-se|Interpor-se]]
- [[Poder - Guerreiro S5 - Bastião de um nome#Força dos gigantes|Força dos gigantes]]



## Atuação e digestão

Interpretação original do papel **Guardião** no tema de força, armas, proteção e declínio. Princípio de partida: escolher o que proteger e conhecer o limite da força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Guerreiro#S5 - Guardião]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Guerreiro - Paladino da Alvorada]]. Próxima: [[Sequência 4 - Guerreiro - Caçador de Demônios]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
