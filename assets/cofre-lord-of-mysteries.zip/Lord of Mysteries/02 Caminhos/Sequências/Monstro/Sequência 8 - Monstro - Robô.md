---
titulo: "Sequência 8 - Monstro - Robô"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 8
nome_ingles: "Robot"
---

# Sequência 8 - Monstro - Robô

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 8. **Nome de referência:** Robot. Tradução editorial: Robô.

## O que a poção transforma

O [[Poder - Monstro S8 - Rotina calculada|pacote completo de Robô]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Cálculo do robô.

- [[Poder - Monstro S8 - Rotina calculada#Movimento calculado|Movimento calculado]]
- [[Poder - Monstro S8 - Rotina calculada#Padrão de ruído|Padrão de ruído]]
- [[Poder - Monstro S8 - Rotina calculada#Estatística do risco|Estatística do risco]]



## Atuação e digestão

Interpretação original do papel **Robô** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S8 - Robô]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Monstro - Monstro]]. Próxima: [[Sequência 7 - Monstro - Sortudo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
