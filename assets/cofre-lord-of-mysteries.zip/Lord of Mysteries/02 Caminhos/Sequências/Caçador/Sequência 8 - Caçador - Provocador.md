---
titulo: "Sequência 8 - Caçador - Provocador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
sequencia: 8
nome_ingles: "Provoker"
---

# Sequência 8 - Caçador - Provocador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Caçador]]. **Sequência:** 8. **Nome de referência:** Provoker. Tradução editorial: Provocador.

## O que a poção transforma

O [[Poder - Caçador S8 - Provocação calculada|pacote completo de Provocador]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Olho do provocador.

- [[Poder - Caçador S8 - Provocação calculada#Provocação|Provocação]]
- [[Poder - Caçador S8 - Provocação calculada#Ferir o orgulho|Ferir o orgulho]]
- [[Poder - Caçador S8 - Provocação calculada#Provocar a resposta|Provocar a resposta]]



## Atuação e digestão

Interpretação original do papel **Provocador** no tema de rastreio, provocação, fogo e guerra. Princípio de partida: conhecer a presa sem reduzir toda relação a caça. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Caçador#S8 - Provocador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Caçador - Caçador]]. Próxima: [[Sequência 7 - Caçador - Piromaníaco]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
