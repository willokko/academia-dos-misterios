---
titulo: "Poder - Criminoso S6 - Chama do diabo"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Criminoso"
sequencia: 6
nome_pacote: "Pacote de Diabo — Criminoso S6"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Criminoso S6 - Chama do diabo

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Diabo, Criminoso S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Criminoso - Diabo]] ou melhor no [[Caminho do Criminoso]]. **Referência nominal:** Devil. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Detecção do perigo:** Uma intenção hostil dirigida a você deixa presságio quando se torna ameaça concreta. Permite tomar precaução, sem revelar toda conspiração.
- **Linhagem diabólica:** Escolha uma aparência ao adquirir o pacote; efeitos mecânicos são os escritos, sem vantagens novas por inventar anatomia.

## Técnicas adquiridas

### Forma diabólica

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Uma cena |
| Teste | Automático |

Pela cena, desenvolva corpo ameaçador e voo curto por uma travessia; reduz 5 de dano físico e deixa presença evidente.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Chama sulfúrica

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+20 de dano fogo em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Palavra profana

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica fraco e a palavra atinge o espírito exposto; não exige que o alvo compreenda seu idioma.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

## Evolução e acúmulo

S5 passa a explorar desejo. A linhagem não concede automaticamente todos os poderes individuais descritos na wiki.

## Preparação e oposição

Intenções protegidas, ausência de hostilidade e investigação paciente. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Criminoso]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
