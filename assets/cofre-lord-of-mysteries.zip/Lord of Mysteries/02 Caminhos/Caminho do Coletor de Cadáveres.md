---
titulo: "Caminho do Coletor de Cadáveres"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
nome_divino: "Morte"
referencia: "https://lordofthemysteries.fandom.com/wiki/Death_Pathway"
---

# Caminho do Coletor de Cadáveres

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Morte. **Tema:** Restos, espíritos, passagem e repouso. **Função:** Forense, contato espiritual e contenção.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Coletor de Cadáveres - Coletor de Cadáveres|Coletor de Cadáveres]] | [[Poder - Coletor de Cadáveres S9 - Exame do último vestígio|3 técnicas]] |
| 8 | [[Sequência 8 - Coletor de Cadáveres - Coveiro|Coveiro]] | [[Poder - Coletor de Cadáveres S8 - Voz junto à sepultura|3 técnicas]] |
| 7 | [[Sequência 7 - Coletor de Cadáveres - Médium Espiritual|Médium Espiritual]] | [[Poder - Coletor de Cadáveres S7 - Audiência dos mortos|3 técnicas]] |
| 6 | [[Sequência 6 - Coletor de Cadáveres - Guia Espiritual|Guia Espiritual]] | [[Poder - Coletor de Cadáveres S6 - Guia do limiar|3 técnicas]] |
| 5 | [[Sequência 5 - Coletor de Cadáveres - Guardião do Portão|Guardião do Portão]] | [[Poder - Coletor de Cadáveres S5 - Portão contido|3 técnicas]] |
| 4 | [[Sequência 4 - Coletor de Cadáveres - Imorredouro|Imorredouro]] | [[Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Coletor de Cadáveres - Barqueiro|Barqueiro]] | [[Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Coletor de Cadáveres - Cônsul da Morte|Cônsul da Morte]] | [[Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Coletor de Cadáveres - Imperador Pálido|Imperador Pálido]] | [[Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Coletor de Cadáveres - Morte|Morte]] | [[Poder - Coletor de Cadáveres S0 - Autoridade de Morte|2 técnicas + operação]] |

## Como jogar

Devolver nome e destino a quem foi reduzido a vestígio. As ferramentas da S9 são olho da morte, ofício funerário. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: mortos não são testemunhas oniscientes. **Oposição:** Purificação, restos sem identidade e espíritos sob domínio alheio. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Coletor de Cadáveres]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Death_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
