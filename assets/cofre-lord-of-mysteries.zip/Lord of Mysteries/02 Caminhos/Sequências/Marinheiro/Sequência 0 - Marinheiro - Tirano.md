---
titulo: "Sequência 0 - Marinheiro - Tirano"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Marinheiro"
sequencia: 0
nome_ingles: "Tyrant"
---

# Sequência 0 - Marinheiro - Tirano

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Marinheiro]]. **Sequência:** 0. **Nome de referência:** Tyrant. Tradução editorial: Tirano.

## O que a poção transforma

O [[Poder - Marinheiro S0 - Autoridade de Tirano|pacote completo de Tirano]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Tirano.

- [[Poder - Marinheiro S0 - Autoridade de Tirano#Imposição do tirano|Imposição do tirano]]
- [[Poder - Marinheiro S0 - Autoridade de Tirano#Maré de energia|Maré de energia]]

Operação: [[Poder - Marinheiro S0 - Autoridade de Tirano#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Tirano** no tema de mar, fúria, vento e tempestade. Princípio de partida: reconhecer correntes, decidir quando enfrentar e quando conduzir a força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Marinheiro#S0 - Tirano]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Marinheiro - Deus do Trovão]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
