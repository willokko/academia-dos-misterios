---
titulo: "Sequência 0 - Assassino - Demoness"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Assassino"
sequencia: 0
nome_ingles: "Demoness"
---

# Sequência 0 - Assassino - Demoness

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Assassino]]. **Sequência:** 0. **Nome de referência:** Demoness. Tradução editorial: Demoness.

## O que a poção transforma

O [[Poder - Assassino S0 - Autoridade de Demoness|pacote completo de Demoness]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Demoness.

- [[Poder - Assassino S0 - Autoridade de Demoness#Mundo de reflexos|Mundo de reflexos]]
- [[Poder - Assassino S0 - Autoridade de Demoness#Retorno ao caos|Retorno ao caos]]

Operação: [[Poder - Assassino S0 - Autoridade de Demoness#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Demoness** no tema de sombras, desejo, espelhos e aflição. Princípio de partida: compreender o poder de uma presença sem tornar outra pessoa um objeto. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Assassino#S0 - Demoness]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Assassino - Apocalipse]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
