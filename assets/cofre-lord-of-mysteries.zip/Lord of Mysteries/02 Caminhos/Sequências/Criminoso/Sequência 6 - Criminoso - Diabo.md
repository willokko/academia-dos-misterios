---
titulo: "Sequência 6 - Criminoso - Diabo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 6
nome_ingles: "Devil"
---

# Sequência 6 - Criminoso - Diabo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 6. **Nome de referência:** Devil. Tradução editorial: Diabo.

## O que a poção transforma

O [[Poder - Criminoso S6 - Chama do diabo|pacote completo de Diabo]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Detecção do perigo; Linhagem diabólica.

- [[Poder - Criminoso S6 - Chama do diabo#Forma diabólica|Forma diabólica]]
- [[Poder - Criminoso S6 - Chama do diabo#Chama sulfúrica|Chama sulfúrica]]
- [[Poder - Criminoso S6 - Chama do diabo#Palavra profana|Palavra profana]]



## Atuação e digestão

Interpretação original do papel **Diabo** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S6 - Diabo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Criminoso - Assassino em Série]]. Próxima: [[Sequência 5 - Criminoso - Apóstolo do Desejo]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
