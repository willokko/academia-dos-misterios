---
titulo: "Sequência 4 - Criminoso - Demônio"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Criminoso"
sequencia: 4
nome_ingles: "Demon"
---

# Sequência 4 - Criminoso - Demônio

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Criminoso]]. **Sequência:** 4. **Nome de referência:** Demon. Tradução editorial: Demônio.

## O que a poção transforma

O [[Poder - Criminoso S4 - Autoridade de Demônio|pacote completo de Demônio]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Demônio.

- [[Poder - Criminoso S4 - Autoridade de Demônio#Mutação diabólica|Mutação diabólica]]
- [[Poder - Criminoso S4 - Autoridade de Demônio#Domínio do desejo|Domínio do desejo]]

Operação: [[Poder - Criminoso S4 - Autoridade de Demônio#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Demônio** no tema de malícia, perigo, desejos e corrupção. Princípio de partida: reconhecer a tentação de dominar sem entregar a ela o comando. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Criminoso#S4 - Demônio]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 5 - Criminoso - Apóstolo do Desejo]]. Próxima: [[Sequência 3 - Criminoso - Tagarela]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
