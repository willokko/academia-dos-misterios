---
titulo: "Caminho do Prisioneiro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "progressao-completa"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
nome_divino: "Acorrentado"
referencia: "https://lordofthemysteries.fandom.com/wiki/Chained_Pathway"
---

# Caminho do Prisioneiro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Nome divino de referência:** Acorrentado. **Tema:** Instinto, contenção, formas mutantes e maldições. **Função:** Resistência, infiltração e controle de vínculos.

## Identidade e progressão

Cada poção transforma seu repertório; não entrega só a técnica que aparece no título antigo do arquivo. Adquire o pacote inteiro e conserva os anteriores. Capacidades, técnicas e melhorias são regras originais; a distribuição não é catálogo literal do romance.

| Sequência | Papel | Pacote adquirido |
|---|---|---|
| 9 | [[Sequência 9 - Prisioneiro - Prisioneiro|Prisioneiro]] | [[Poder - Prisioneiro S9 - Limites da cela|3 técnicas]] |
| 8 | [[Sequência 8 - Prisioneiro - Lunático|Lunático]] | [[Poder - Prisioneiro S8 - Instinto contido|3 técnicas]] |
| 7 | [[Sequência 7 - Prisioneiro - Lobisomem|Lobisomem]] | [[Poder - Prisioneiro S7 - Garras do limiar|3 técnicas]] |
| 6 | [[Sequência 6 - Prisioneiro - Zumbi|Zumbi]] | [[Poder - Prisioneiro S6 - Corpo do frio|3 técnicas]] |
| 5 | [[Sequência 5 - Prisioneiro - Espectro|Espectro]] | [[Poder - Prisioneiro S5 - Visita espectral|3 técnicas]] |
| 4 | [[Sequência 4 - Prisioneiro - Marionete|Marionete]] | [[Poder - Prisioneiro S4 - Autoridade de Marionete|2 técnicas + operação]] |
| 3 | [[Sequência 3 - Prisioneiro - Discípulo do Silêncio|Discípulo do Silêncio]] | [[Poder - Prisioneiro S3 - Autoridade de Discípulo do Silêncio|2 técnicas + operação]] |
| 2 | [[Sequência 2 - Prisioneiro - Flagelo Antigo|Flagelo Antigo]] | [[Poder - Prisioneiro S2 - Autoridade de Flagelo Antigo|2 técnicas + operação]] |
| 1 | [[Sequência 1 - Prisioneiro - Abominação|Abominação]] | [[Poder - Prisioneiro S1 - Autoridade de Abominação|2 técnicas + operação]] |
| 0 | [[Sequência 0 - Prisioneiro - Acorrentado|Acorrentado]] | [[Poder - Prisioneiro S0 - Autoridade de Acorrentado|2 técnicas + operação]] |

## Como jogar

Reconhecer um impulso sem permitir que ele decida por você. As ferramentas da S9 são corpo encarcerado. Avançar traz novas formas de agir sem depender de classe para conceder o sobrenatural que o Caminho promete. Classes especializam e dão treinamento por [[Classes e identidade sobrenatural]].

**Dificuldade de adaptação:** Alta: possessão e autonomia. **Oposição:** Recipientes preparados, purificação e reconhecimento da âncora. Essas diretrizes precisam de evidências e manifestações em cena; não são bônus ou imunidades universais.

## Poções, atuação e fontes

[[Avanços do Prisioneiro]] centraliza o que foi verificado de fórmulas e ritos e as provas originais identificadas. [[Digestão e atuação]] rege integração; [[Servos e repertórios]] rege ajudantes e cópias; [[Escala e confrontos sobrenaturais]] explica o salto dos santos e anjos.

[Habilidades da wiki](https://lordofthemysteries.fandom.com/wiki/Chained_Pathway/Abilities). Consulta por trechos indexados, com limites em [[Pesquisa da revisão 0.2]]. Não se afirma leitura integral da página ou de seus capítulos primários.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
