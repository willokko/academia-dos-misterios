---
titulo: "Sequência 3 - Guerreiro - Cavaleiro de Prata"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
sequencia: 3
nome_ingles: "Silver Knight"
---

# Sequência 3 - Guerreiro - Cavaleiro de Prata

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Guerreiro]]. **Sequência:** 3. **Nome de referência:** Silver Knight. Tradução editorial: Cavaleiro de Prata.

## O que a poção transforma

O [[Poder - Guerreiro S3 - Autoridade de Cavaleiro de Prata|pacote completo de Cavaleiro de Prata]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Cavaleiro de Prata.

- [[Poder - Guerreiro S3 - Autoridade de Cavaleiro de Prata#Corpo de prata|Corpo de prata]]
- [[Poder - Guerreiro S3 - Autoridade de Cavaleiro de Prata#Espada de alvorada|Espada de alvorada]]

Operação: [[Poder - Guerreiro S3 - Autoridade de Cavaleiro de Prata#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Cavaleiro de Prata** no tema de força, armas, proteção e declínio. Princípio de partida: escolher o que proteger e conhecer o limite da força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Guerreiro#S3 - Cavaleiro de Prata]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Guerreiro - Caçador de Demônios]]. Próxima: [[Sequência 2 - Guerreiro - Glória]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
