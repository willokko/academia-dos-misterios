---
titulo: "Classes e identidade sobrenatural"
tipo: "regras-fundamentais"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Classes e identidade sobrenatural

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

## Regra da fonte

No modo principal desta edição, uma capacidade impossível exige uma fonte: pacote de Caminho adquirido; técnica copiada por regra expressa; objeto selado real; ou ritual aprendido com seus preparos. Classes continuam oficiais em níveis, custos, habilidades e recursos, mas uma escolha não fornece sozinha uma origem sobrenatural incompatível com o cenário.

Ao escolher feitiço ou habilidade de classe, registre uma destas situações:

| Situação | Procedimento |
|---|---|
| Treinamento, estudo, liderança ou equipamento ordinário | Funciona normalmente, sem fonte mística adicional |
| A técnica expressa capacidade já adquirida do Caminho | Pode ser comprada; usa números e ação da classe quando for utilizada como habilidade de classe |
| A técnica depende de objeto ou pacto obtido na história | Registre a fonte, seus protocolos e como pode ser perdida; ter a classe não cria o objeto |
| A técnica faria algo que nenhuma fonte sua permite | Escolha outra habilidade ou deixe a compra para quando adquirir a fonte; não gaste um nível numa opção inutilizável |

Não se cobram os dois custos ao mesmo tempo: usar a versão de classe paga a ficha de classe; usar a versão do Caminho paga a técnica. Não combina dano de uma com gatilho da outra. Benefícios exclusivos de Feitiço ou Ataque só se aplicam quando a ação efetivamente for dessa categoria.

## Exemplos concretos

- Vidente S9 pode estudar e adivinhar pelo Caminho; não dispara Lux nem regenera feridas sem outra fonte. Erudito, Orador e treinamento de combate continuam possíveis.
- Piromaníaco S7 pode adquirir magia de fogo de Elementalista: sua poção já permite fogo. A classe oferece especialização, não libera gelo e teleporte por associação.
- Médico S8 pode especializar cura por uma classe apropriada. Espectador S9 pode encorajar e recuperar fôlego, mas terapia sobrenatural só aparece no seu pacote S7.
- Um artesão S6 já possui habilitação para projetos selados. Inventor ainda traz seus benefícios próprios e outros projetos, sem produzir características do nada.

Essas restrições de origem são adaptação, não regra oficial de FU. Para misturar livremente magia de classes, a mesa pode adotar o modo híbrido anterior, mas ele muda a premissa e precisa ser registrado como variante. O padrão e as fichas prontas usam o modo centrado nos Caminhos.

## Migração

Antes da próxima sessão, retreine sem custo opções que perderam fonte: redistribua os mesmos níveis, recalcule benefícios iniciais e recursos, ou registre uma fonte externa já obtida. Não invente um artefato gratuito para conservar uma construção incompatível. A personagem Irene foi retreinada e aparece atualizada em [[Personagens prontos]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
