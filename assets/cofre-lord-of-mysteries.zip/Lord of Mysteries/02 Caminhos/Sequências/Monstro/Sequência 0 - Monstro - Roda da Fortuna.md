---
titulo: "Sequência 0 - Monstro - Roda da Fortuna"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Monstro"
sequencia: 0
nome_ingles: "Wheel of Fortune"
---

# Sequência 0 - Monstro - Roda da Fortuna

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Monstro]]. **Sequência:** 0. **Nome de referência:** Wheel of Fortune. Tradução editorial: Roda da Fortuna.

## O que a poção transforma

O [[Poder - Monstro S0 - Autoridade de Roda da Fortuna|pacote completo de Roda da Fortuna]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Roda da Fortuna.

- [[Poder - Monstro S0 - Autoridade de Roda da Fortuna#Roda favorável|Roda favorável]]
- [[Poder - Monstro S0 - Autoridade de Roda da Fortuna#Destino em suspenso|Destino em suspenso]]

Operação: [[Poder - Monstro S0 - Autoridade de Roda da Fortuna#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Roda da Fortuna** no tema de intuição, sorte, infortúnio e ciclos. Princípio de partida: reconhecer acaso e escolha sem usar destino como desculpa. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Monstro#S0 - Roda da Fortuna]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Monstro - Serpente de Mercúrio]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
