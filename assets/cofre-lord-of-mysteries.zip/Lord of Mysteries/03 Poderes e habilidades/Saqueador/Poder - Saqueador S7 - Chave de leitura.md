---
titulo: "Poder - Saqueador S7 - Chave de leitura"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Saqueador"
sequencia: 7
nome_pacote: "Pacote de Criptologista — Saqueador S7"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Saqueador S7 - Chave de leitura

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Criptologista, Saqueador S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Saqueador - Criptologista]] ou melhor no [[Caminho do Saqueador]]. **Referência nominal:** Cryptologist. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Decifração:** Reconhece padrões em códigos e atos observados; sem texto ou vestígio não cria informação.

## Técnicas adquiridas

### Quebrar a cifra

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Revele uma regra do código encontrado e +2 ao próximo Objetivo para decifrá-lo. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Decifrar uma técnica

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON ND10 sob pressão; sem teste se não houver risco |

Após ver uma técnica, descubra seu gatilho ou condição de interrupção, sem receber o poder nem toda a ficha. Uma resposta é limitada pelo vestígio disponível; interferência deixa um sinal de ocultação.

**Limites:** Sem nova evidência, repetir a consulta não produz informação adicional.

### Ruído na leitura

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Até o próximo descanso |
| Teste | Automático |

Uma consulta sobre um vestígio seu exige AST+VON oposto à sua AST+VON; a interferência deixa sinal.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

Na S6, decifrar permite selecionar a técnica no roubo, sem alvo aleatório. Não dá certeza sobre autoridades superiores.

## Preparação e oposição

Vigilância cruzada, vínculos protegidos e ações sem habilidade ativa. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Saqueador]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
