---
titulo: "Sequência 7 - Guerreiro - Mestre das Armas"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Guerreiro"
sequencia: 7
nome_ingles: "Weapon Master"
---

# Sequência 7 - Guerreiro - Mestre das Armas

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Guerreiro]]. **Sequência:** 7. **Nome de referência:** Weapon Master. Tradução editorial: Mestre das Armas.

## O que a poção transforma

O [[Poder - Guerreiro S7 - Leitura do adversário|pacote completo de Mestre das Armas]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Domínio das armas.

- [[Poder - Guerreiro S7 - Leitura do adversário#Leitura do armamento|Leitura do armamento]]
- [[Poder - Guerreiro S7 - Leitura do adversário#Arremesso preciso|Arremesso preciso]]
- [[Poder - Guerreiro S7 - Leitura do adversário#Desarmar por técnica|Desarmar por técnica]]



## Atuação e digestão

Interpretação original do papel **Mestre das Armas** no tema de força, armas, proteção e declínio. Princípio de partida: escolher o que proteger e conhecer o limite da força. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Guerreiro#S7 - Mestre das Armas]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Guerreiro - Pugilista]]. Próxima: [[Sequência 6 - Guerreiro - Paladino da Alvorada]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
