---
titulo: "Sequência 0 - Saqueador - Erro"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Saqueador"
sequencia: 0
nome_ingles: "Error"
---

# Sequência 0 - Saqueador - Erro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Saqueador]]. **Sequência:** 0. **Nome de referência:** Error. Tradução editorial: Erro.

## O que a poção transforma

O [[Poder - Saqueador S0 - Autoridade de Erro|pacote completo de Erro]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Erro.

- [[Poder - Saqueador S0 - Autoridade de Erro#Erro na identificação|Erro na identificação]]
- [[Poder - Saqueador S0 - Autoridade de Erro#Erro no vínculo|Erro no vínculo]]

Operação: [[Poder - Saqueador S0 - Autoridade de Erro#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Erro** no tema de subtração, engano e brechas de identidade. Princípio de partida: encontrar uma brecha e reconhecer aquilo que não se pode tomar. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Saqueador#S0 - Erro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 1 - Saqueador - Verme do Tempo]]. Não há promoção ordinária acima de S0 neste suplemento.

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
