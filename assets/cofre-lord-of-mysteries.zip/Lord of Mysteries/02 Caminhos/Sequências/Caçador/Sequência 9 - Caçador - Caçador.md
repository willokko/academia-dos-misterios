---
titulo: "Sequência 9 - Caçador - Caçador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Caçador"
sequencia: 9
nome_ingles: "Hunter"
---

# Sequência 9 - Caçador - Caçador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Caçador]]. **Sequência:** 9. **Nome de referência:** Hunter. Tradução editorial: Caçador.

## O que a poção transforma

O [[Poder - Caçador S9 - Rastro escolhido|pacote completo de Caçador]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Sentidos de caça.

- [[Poder - Caçador S9 - Rastro escolhido#Rastro recente|Rastro recente]]
- [[Poder - Caçador S9 - Rastro escolhido#Armadilha preparada|Armadilha preparada]]
- [[Poder - Caçador S9 - Rastro escolhido#Emboscada do caçador|Emboscada do caçador]]



## Atuação e digestão

Interpretação original do papel **Caçador** no tema de rastreio, provocação, fogo e guerra. Princípio de partida: conhecer a presa sem reduzir toda relação a caça. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Caçador#S9 - Caçador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Esta é a poção de entrada. Próxima: [[Sequência 8 - Caçador - Provocador]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
