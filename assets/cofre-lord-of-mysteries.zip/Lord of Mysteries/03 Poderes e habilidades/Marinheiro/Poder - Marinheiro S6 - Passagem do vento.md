---
titulo: "Poder - Marinheiro S6 - Passagem do vento"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Marinheiro"
sequencia: 6
nome_pacote: "Pacote de Abençoado pelo Vento — Marinheiro S6"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Marinheiro S6 - Passagem do vento

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Abençoado pelo Vento, Marinheiro S6.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 6 - Marinheiro - Abençoado pelo Vento]] ou melhor no [[Caminho do Marinheiro]]. **Referência nominal:** Wind-blessed. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Afinidade aérea:** Sente mudanças locais de pressão e direção do vento; não identifica automaticamente a origem de uma tempestade.
- **Brisa manipulada:** Pode ventilar e limpar fumaça ordinária num pequeno espaço sem criar ataque gratuito.

## Técnicas adquiridas

### Voo do vendaval

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Três rodadas ou uma travessia |
| Teste | Automático |

Voe pela cena durante três rodadas ou por uma travessia curta fora de combate. Pode carregar um voluntário em contato; uma vez ativado, não gasta a ação apenas para permanecer no ar.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Lâmina de vento

| Parâmetro | Regra |
|---|---|
| Custo | 15 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | AST+VON contra DEF.M |

Um alvo sofre RA+20 de dano físico em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Parede de vento

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até o próximo turno |
| Teste | Automático |

Você e até dois aliados recebem +2 DEF contra projéteis até o início do próximo turno. Não bloqueia sons, maldições ou ataques sem trajetória aérea.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S5: voo dura a cena; levar dois passageiros custa 5 PM adicionais na ativação. Voo deixou de exigir nova ação a cada rodada.

## Preparação e oposição

Locais sem acesso aéreo/aquático, preparação interrompida e proteção elemental. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Marinheiro]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
