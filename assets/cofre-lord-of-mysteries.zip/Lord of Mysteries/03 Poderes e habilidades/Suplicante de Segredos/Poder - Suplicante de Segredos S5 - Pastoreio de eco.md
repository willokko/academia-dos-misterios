---
titulo: "Poder - Suplicante de Segredos S5 - Pastoreio de eco"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Suplicante de Segredos"
sequencia: 5
nome_pacote: "Pacote de Pastor — Suplicante de Segredos S5"
quantidade_tecnicas: 3
quantidade_capacidades: 1
quantidade_operacoes: 0
---

# Poder - Suplicante de Segredos S5 - Pastoreio de eco

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Pastor, Suplicante de Segredos S5.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 5 - Suplicante de Segredos - Pastor]] ou melhor no [[Caminho do Suplicante de Segredos]]. **Referência nominal:** Shepherd. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Pastoreio:** Três almas S9–5, cada uma com até três técnicas ativas escolhidas da ficha real. Uma alma fornece poderes por vez; não são três iniciativas.

## Técnicas adquiridas

### Vincular alma

| Parâmetro | Regra |
|---|---|
| Custo | 20 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Até liberar ou romper |
| Teste | AST+VON ND13 |

Vincule alma disponível por consentimento, derrota ou ritual de contenção. Sem alma exposta, primeiro vença o conflito. Registre sua característica; ela fica indisponível para outra poção ou objeto.

**Limites:** Uma alma superior exige arco e módulo próprio. Alma coagida pode opor-se numa crise anunciada; não é uma fábrica gratuita.

### Manifestar alma

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM para trocar; técnica usada paga custo próprio |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até trocar |
| Teste | Conforme a técnica |

Troque a alma ativa como ação sem PM. Depois, use uma de suas técnicas com ação, PM e atributos seus, mantendo materiais e limites. Pode continuar usando técnicas próprias.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Liberar o rebanho

| Parâmetro | Regra |
|---|---|
| Custo | 0 PM |
| Ação | Dez minutos |
| Alcance | Cena |
| Duração | Permanente |
| Teste | Automático se não há oposição |

Liberte alma e característica registrada em local preparado, perdendo acesso ao repertório dela. Informação só se ela aceitar conversar.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S4: cinco almas S9–5. O limite é editorial; impede produção recursiva de almas, poderes e características.

## Preparação e oposição

Purificação, recusa de pactos e exposição da fonte dos sussurros. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Suplicante de Segredos]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
