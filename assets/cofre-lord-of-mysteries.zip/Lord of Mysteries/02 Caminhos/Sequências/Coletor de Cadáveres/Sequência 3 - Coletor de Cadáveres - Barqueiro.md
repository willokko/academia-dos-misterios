---
titulo: "Sequência 3 - Coletor de Cadáveres - Barqueiro"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 3
nome_ingles: "Ferryman"
---

# Sequência 3 - Coletor de Cadáveres - Barqueiro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 3. **Nome de referência:** Ferryman. Tradução editorial: Barqueiro.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro|pacote completo de Barqueiro]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Barqueiro.

- [[Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro#Barca espiritual|Barca espiritual]]
- [[Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro#Rito de passagem|Rito de passagem]]

Operação: [[Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Barqueiro** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S3 - Barqueiro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Coletor de Cadáveres - Imorredouro]]. Próxima: [[Sequência 2 - Coletor de Cadáveres - Cônsul da Morte]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
