---
titulo: "Servos e repertórios"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
---

# Servos e repertórios

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

## Regras que todos compartilham

O limite escrito de cada repertório substitui o antigo limite universal de um registro. Uma técnica ocupa um espaço, não um Caminho ou pacote inteiro. Todos os espaços, fontes, durações e custos são registrados. Um mesmo registro não existe simultaneamente em livro, alma, pergaminho e objeto se isso duplicar uma unidade real.

| Método | Estoque inicial | Uso e persistência |
|---|---|---|
| Roubo S6 do Saqueador | 2 técnicas; S5: 3 | Uso repetível por 10 minutos; S5: uma hora; bloqueio do NPC só três turnos |
| Registro S6 do Aprendiz | 8, até 2 S5–6; S5: 12, até 4 S5–6 | Cada registro é um uso; persiste até consumir |
| Análise S6 do Leitor | 3 modelos; S5: 6 conhecidos, 4 preparados | Reutilizável; +5 PM e -5 dano/cura por imitação |
| Pastoreio S5 | 3 almas reais, até 3 técnicas cada | Uma alma ativa; mudar exige ação; S4: 5 almas |
| Espíritos do Insone S5 | 3 espíritos reais | 1 técnica ativa por espírito; uma manifestação por vez |
| Abrigo do Coletor S5 | 3 espíritos reais | 1 técnica ativa por espírito; uma manifestação por vez |
| Pergaminho do Espreitador S6 | 4; S5: 6 | Um uso, PM no preparo, material e ação na liberação |
| Marionete do Vidente S5 | 2 corpos reais; S4: 6 | Uma marionete opera por ação, sem prazo artificial de um turno |

Capacidades são **limites editoriais de jogo**, não quantidades literais do romance. Evoluções de um Caminho alteram apenas o seu estoque.

## Elegibilidade

Copiar, registrar e imitar alcançam técnicas ativas S9–5 observadas integralmente. Conservam material, fonte, alcance, condição e custo. Não copiam passivo, poção, rito de avanço, poder heroico, alma, Unicidade, forma mítica ou autoridade. Não copiam cópia, roubo, registro, fabricação de poderes, pergaminho de poderes ou efeito que refaz dados. Um arquivo não alimenta outro arquivo para criar recursão.

Pastoreio e servos usam fichas reais de seres disponíveis. Somente suas técnicas ativas S9–5 podem ser manifestas em conflito convencional. Graus superiores e projeções históricas exigem o pacote e o módulo correspondentes, sem contornar os limites acima. Não se extrai uma característica enquanto ela sustenta um servo, artefato ou poção.

## Ficha de um servo

Registre origem, grau, corpo ou receptáculo, característica se houver, técnicas elegíveis, obrigação e modo de romper o vínculo. Almas e corpos não são gerados pela técnica. A marionete conservada pelo Vidente morreu ao concluir captura; isso tem consequências de investigação, identidade e facção.

Um corpo ordinário operado usa seus atributos do controlador, DEF8, DEF.M8 e 20 PV; um corpo Beyonder S9–5 usa a ficha original e pode ter no máximo nível equivalente ao controlador, sem importar ações múltiplas de chefe. Dano ao corpo não é transferido ao controlador; a destruição remove o servo e expõe a característica real que continha. Espírito sem corpo pode ser disperso rompendo seu vínculo por Objetivo 0/4, AST+VON ND13. Não conta como outra fonte de recompensa se for manifestação do mesmo estoque.

O controlador gasta sua ação e PM para atacar ou usar técnica; movimentar o servo faz parte daquela ação e não dá outro ataque. Comunicação simples e troca de percepção não criam uma ação ofensiva. Quem está fisicamente em risco pode ser alvo normal da oposição.

## Bloqueios e contramedidas

Um roubo bloqueia só a técnica nomeada, por três turnos do NPC; ele conserva ataques e Objetivos. Remover um livro impede novos registros ou liberações, não apaga poção. Purificar uma alma, cortar fios, quebrar receptáculo ou cumprir uma obrigação podem romper um vínculo. A contramedida deve aparecer como pista antes de ser decisiva.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
