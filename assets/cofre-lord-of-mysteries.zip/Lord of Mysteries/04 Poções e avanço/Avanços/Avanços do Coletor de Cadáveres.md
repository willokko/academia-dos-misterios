---
titulo: "Avanços do Coletor de Cadáveres"
tipo: "poções-e-avanço"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "ritos-e-altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
---

# Avanços do Coletor de Cadáveres

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

Esta nota é a referência única de fórmulas e ritos do [[Caminho do Coletor de Cadáveres]]. Custos e preparação: [[Poções e fórmulas]], [[Fórmulas e ingredientes]] e [[Avanço e consumo]]. Não foram verificadas receitas completas para todas as Sequências deste Caminho.

**Fórmula jogável original comum, S9–1:** uma característica íntegra da Sequência desejada, com proveniência registrada, mais auxiliares simbólicos do orçamento. Use um objeto, substância e gesto associados a **restos, espíritos, passagem e repouso**; as quantidades e o preparo não pretendem reproduzir o romance. Sem uma característica disponível, não há poção. **Na S0, não use essa simplificação:** é preciso reunir a Unicidade e três características S1 do Caminho, além do rito e das condições do [[Módulo angelical e divino]]. Ver [[Características Beyonder]].

**Princípio geral original:** Devolver nome e destino a quem foi reduzido a vestígio.

## S9 - Coletor de Cadáveres

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** A primeira poção é antecedente de criação; obtenha a fórmula de um patrono e declare a dívida, sem rolagem inicial. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 9 - Coletor de Cadáveres - Coletor de Cadáveres]] e [[Poder - Coletor de Cadáveres S9 - Exame do último vestígio]].

## S8 - Coveiro

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Coveiro numa situação com consequência: devolver nome e destino a quem foi reduzido a vestígio. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 8 - Coletor de Cadáveres - Coveiro]] e [[Poder - Coletor de Cadáveres S8 - Voz junto à sepultura]].

## S7 - Médium Espiritual

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Médium Espiritual numa situação com consequência: devolver nome e destino a quem foi reduzido a vestígio. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 7 - Coletor de Cadáveres - Médium Espiritual]] e [[Poder - Coletor de Cadáveres S7 - Audiência dos mortos]].

## S6 - Guia Espiritual

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Guia Espiritual numa situação com consequência: devolver nome e destino a quem foi reduzido a vestígio. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 6 - Coletor de Cadáveres - Guia Espiritual]] e [[Poder - Coletor de Cadáveres S6 - Guia do limiar]].

## S5 - Guardião do Portão

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Guardião do Portão numa situação com consequência: devolver nome e destino a quem foi reduzido a vestígio. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 5 - Coletor de Cadáveres - Guardião do Portão]] e [[Poder - Coletor de Cadáveres S5 - Portão contido]].

## S4 - Imorredouro

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Imorredouro numa situação com consequência: devolver nome e destino a quem foi reduzido a vestígio. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 4 - Coletor de Cadáveres - Imorredouro]] e [[Poder - Coletor de Cadáveres S4 - Autoridade de Imorredouro]].

## S3 - Barqueiro

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Barqueiro numa situação com consequência: devolver nome e destino a quem foi reduzido a vestígio. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de estabilização com duas âncoras; o feito temático desta etapa está em [[Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 3 - Coletor de Cadáveres - Barqueiro]] e [[Poder - Coletor de Cadáveres S3 - Autoridade de Barqueiro]].

## S2 - Cônsul da Morte

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Cônsul da Morte numa situação com consequência: devolver nome e destino a quem foi reduzido a vestígio. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 2 - Coletor de Cadáveres - Cônsul da Morte]] e [[Poder - Coletor de Cadáveres S2 - Autoridade de Cônsul da Morte]].

## S1 - Imperador Pálido

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Imperador Pálido numa situação com consequência: devolver nome e destino a quem foi reduzido a vestígio. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 1 - Coletor de Cadáveres - Imperador Pálido]] e [[Poder - Coletor de Cadáveres S1 - Autoridade de Imperador Pálido]].

## S0 - Morte

> [!warning] Pesquisa incompleta
> Rito e ingredientes canônicos específicos **não verificados nesta pesquisa**. Isso não afirma que não existam na obra. Não invente uma receita canônica a partir do nome.

**Prova original opcional para esta campanha:** Demonstre o papel de Morte numa situação com consequência: devolver nome e destino a quem foi reduzido a vestígio. Apresente uma evidência concreta do que aprendeu e preserve uma âncora humana. Resolva um projeto de operação com três âncoras e matéria única rastreada; o feito temático desta etapa está em [[Poder - Coletor de Cadáveres S0 - Autoridade de Morte]]. O mestre prepara uma cena distinta, não exige repetição de uma rotina. Se a mesa adota o rito verificado acima, a prova original é preparação e não substituição desse rito. Onde não houve verificação, escolher a prova substitui explicitamente o rito do cenário nesta adaptação.

**Requisitos mecânicos:** nível e escala de [[Progressão e Sequências]], fórmula, material, digestão e Corrupção segundo [[Avanço e consumo]]. **Após consumir:** [[Sequência 0 - Coletor de Cadáveres - Morte]] e [[Poder - Coletor de Cadáveres S0 - Autoridade de Morte]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
