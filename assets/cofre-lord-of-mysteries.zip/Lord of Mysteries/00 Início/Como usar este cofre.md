---
titulo: "Como usar este cofre"
tipo: "início"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Como usar este cofre

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

Abra esta pasta como cofre existente no Obsidian e abra [[Início]]. Ative somente os recursos nativos que desejar. Links como [[Início]], propriedades YAML, avisos e incorporações funcionam sem plugins de terceiros. A pasta de modelos está configurada para o recurso nativo Modelos.

## Convenções de leitura

> [!quote] Cânone de Lord of Mysteries
> Informação atribuída à obra por uma fonte consultada. Nesta edição, a verificação detalhada depende principalmente da wiki, não de leitura integral do romance.

> [!info] Fabula Ultima oficial
> Regra resumida com referência ao livro local. O suplemento não substitui o livro básico.

> [!example] Adaptação original
> Qualquer custo, dificuldade, limite, tradução editorial, preço, poder, aventura ou procedimento criado aqui é regra da adaptação, mesmo quando inspirado em um evento canônico.

Cada nota possui `origem`, `estado`, `validacao`, `publico`, `spoilers`, `versao` e `tags`. `revisado-teoricamente` significa revisão de coerência, não aprovação por jogadores. `experimental` identifica a escala dos santos e deuses. `canon-secundario` identifica dependência de fonte de apoio.

As referências normativas ficam em notas únicas. Uma Sequência remete à ficha de poder e ao dossiê de avanço, em vez de copiar suas regras. O índice remete aos mesmos documentos. Não aplique uma regra adicional só porque apareceu novamente em um exemplo.

## Jogadores e mestre

Jogadores: pastas 01–07, personagens e apresentação da campanha. Mestre: pasta 08 e subpasta `09 Campanha/Mestre`; fontes e decisões podem conter grandes spoilers. Pastas e etiquetas são organização, não controle de acesso. Para distribuir material sem segredos, exporte uma seleção de notas, não o cofre inteiro.

Os nomes traduzidos são escolhas desta adaptação, não terminologia portuguesa oficial do romance. [[Glossário]] mantém os termos de comparação. O escopo é a primeira obra e os 22 Caminhos tradicionais; acréscimos recentes da wiki podem derivar de materiais posteriores, conforme [[Fontes de Lord of Mysteries]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
