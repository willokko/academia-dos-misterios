---
titulo: "Poder - Vidente S7 - Truques do palco velado"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Vidente"
sequencia: 7
nome_pacote: "Pacote de Mágico — Vidente S7"
quantidade_tecnicas: 6
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Vidente S7 - Truques do palco velado

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Mágico, Vidente S7.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 7 - Vidente - Mágico]] ou melhor no [[Caminho do Vidente]]. **Referência nominal:** Magician. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Repertório do mágico:** Pequenas luzes, sons, manejo de chama presente e truques de bolso sem vantagem mecânica são gratuitos. Efeitos que distraem, ferem ou atravessam obstáculos usam as técnicas abaixo.
- **Respiração por tubo:** Pode formar um tubo de ar de até cinco metros para respirar submerso, com uma extremidade em ar respirável; não atravessa selos.

## Técnicas adquiridas

### Bala de ar

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | DES+AST contra DEF |

Um alvo sofre RA+15 de dano físico em sucesso. 

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Salto flamejante

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | 30 m |
| Duração | Instantânea |
| Teste | Automático em rota desimpedida; AST+VON ND13 sob interferência |

Salte entre duas chamas percebidas na mesma cena, até 30 m. Não atravessa selo espacial; sai ileso do fogo apenas durante o salto.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Substituto de papel

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Um golpe |
| Teste | Automático |

Após ser atingido e antes do dano, consuma uma efígie preparada: reduza o dano antes das afinidades em 15 e reapareça a poucos passos em ponto livre. Não cancela morte já resolvida.

**Limites:** Uma reação por rodada; prepare até duas efígies por descanso em dez minutos com papel. Não duplica efeitos de redução de dano de outra técnica de Caminho.

### Ilusão sensorial

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Até curar a condição ou fim da cena; restrições adicionais seguem o texto |
| Teste | AST+VON contra DEF.M |

Em sucesso, aplica atordoado e o alvo precisa conferir uma imagem ou som falso; interação concreta expõe a ilusão.

**Limites:** Não acumula a mesma condição; seres sem o substrato afetado resistem conforme sua natureza, anunciada antes do gasto.

### Transferir ferimento

| Parâmetro | Regra |
|---|---|
| Custo | 10 PM |
| Ação | Reação |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | Automático |

Transfira uma ferida recém-recebida para uma parte menos vital do próprio corpo: recupere 10 PV. Não transfere para outro personagem e não funciona duas vezes sobre o mesmo golpe.

**Limites:** Uma reação por rodada; uma transferência por golpe. Não recupera de 0 PV.

### Domínio das chamas

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Uma cena |
| Teste | Automático |

Controle uma chama ordinária da cena para apagar um incêndio pequeno ou iluminar uma rota; uma fogueira não vira ataque gratuito.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

S6: bala de ar admite modo RA+20 por 15 PM; tubo de ar chega a dez metros. S5: salto flamejante pode alcançar até 100 m entre chamas conhecidas, sem levar passageiros.

## Preparação e oposição

Ocultação de vínculos, identidades verificadas por relações e interrupção de preparação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Vidente]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
