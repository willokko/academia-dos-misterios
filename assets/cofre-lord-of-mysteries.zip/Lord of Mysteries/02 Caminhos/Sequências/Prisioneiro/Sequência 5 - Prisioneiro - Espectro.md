---
titulo: "Sequência 5 - Prisioneiro - Espectro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Prisioneiro"
sequencia: 5
nome_ingles: "Wraith"
---

# Sequência 5 - Prisioneiro - Espectro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Prisioneiro]]. **Sequência:** 5. **Nome de referência:** Wraith. Tradução editorial: Espectro.

## O que a poção transforma

O [[Poder - Prisioneiro S5 - Visita espectral|pacote completo de Espectro]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Natureza espectral.

- [[Poder - Prisioneiro S5 - Visita espectral#Corpo de espectro|Corpo de espectro]]
- [[Poder - Prisioneiro S5 - Visita espectral#Salto em reflexo|Salto em reflexo]]
- [[Poder - Prisioneiro S5 - Visita espectral#Possessão|Possessão]]



## Atuação e digestão

Interpretação original do papel **Espectro** no tema de instinto, contenção, formas mutantes e maldições. Princípio de partida: reconhecer um impulso sem permitir que ele decida por você. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Prisioneiro#S5 - Espectro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 6 - Prisioneiro - Zumbi]]. Próxima: [[Sequência 4 - Prisioneiro - Marionete]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
