---
titulo: "Sequência 1 - Bardo - Anjo Branco"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Bardo"
sequencia: 1
nome_ingles: "White Angel"
---

# Sequência 1 - Bardo - Anjo Branco

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Bardo]]. **Sequência:** 1. **Nome de referência:** White Angel. Tradução editorial: Anjo Branco.

## O que a poção transforma

O [[Poder - Bardo S1 - Autoridade de Anjo Branco|pacote completo de Anjo Branco]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Anjo Branco.

- [[Poder - Bardo S1 - Autoridade de Anjo Branco#Bênção angelical|Bênção angelical]]
- [[Poder - Bardo S1 - Autoridade de Anjo Branco#Lança branca|Lança branca]]

Operação: [[Poder - Bardo S1 - Autoridade de Anjo Branco#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Anjo Branco** no tema de luz, purificação, contratos e inspiração. Princípio de partida: inspirar coragem sem confundir fé com submissão. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Bardo#S1 - Anjo Branco]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 2 - Bardo - Buscador da Luz]]. Próxima: [[Sequência 0 - Bardo - Sol]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
