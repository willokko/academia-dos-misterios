---
titulo: "Sequência 7 - Árbitro - Interrogador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Árbitro"
sequencia: 7
nome_ingles: "Interrogator"
---

# Sequência 7 - Árbitro - Interrogador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Árbitro]]. **Sequência:** 7. **Nome de referência:** Interrogator. Tradução editorial: Interrogador.

## O que a poção transforma

O [[Poder - Árbitro S7 - Pergunta que pesa|pacote completo de Interrogador]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Interrogador.

- [[Poder - Árbitro S7 - Pergunta que pesa#Perfuração psíquica|Perfuração psíquica]]
- [[Poder - Árbitro S7 - Pergunta que pesa#Pressão interrogativa|Pressão interrogativa]]
- [[Poder - Árbitro S7 - Pergunta que pesa#Confrontar relato|Confrontar relato]]



## Atuação e digestão

Interpretação original do papel **Interrogador** no tema de autoridade, julgamento, proibição e ordem. Princípio de partida: tornar uma regra compreensível e aceitar que ela também o limite. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Árbitro#S7 - Interrogador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Árbitro - Xerife]]. Próxima: [[Sequência 6 - Árbitro - Juiz]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
