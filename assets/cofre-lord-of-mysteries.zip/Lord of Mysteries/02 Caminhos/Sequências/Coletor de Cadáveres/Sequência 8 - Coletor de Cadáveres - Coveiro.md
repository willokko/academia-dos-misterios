---
titulo: "Sequência 8 - Coletor de Cadáveres - Coveiro"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Coletor de Cadáveres"
sequencia: 8
nome_ingles: "Gravedigger"
---

# Sequência 8 - Coletor de Cadáveres - Coveiro

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Coletor de Cadáveres]]. **Sequência:** 8. **Nome de referência:** Gravedigger. Tradução editorial: Coveiro.

## O que a poção transforma

O [[Poder - Coletor de Cadáveres S8 - Voz junto à sepultura|pacote completo de Coveiro]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Força do coveiro.

- [[Poder - Coletor de Cadáveres S8 - Voz junto à sepultura#Disfarce cadavérico|Disfarce cadavérico]]
- [[Poder - Coletor de Cadáveres S8 - Voz junto à sepultura#Afastar morto errante|Afastar morto errante]]
- [[Poder - Coletor de Cadáveres S8 - Voz junto à sepultura#Toque gelado|Toque gelado]]



## Atuação e digestão

Interpretação original do papel **Coveiro** no tema de restos, espíritos, passagem e repouso. Princípio de partida: devolver nome e destino a quem foi reduzido a vestígio. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Coletor de Cadáveres#S8 - Coveiro]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 9 - Coletor de Cadáveres - Coletor de Cadáveres]]. Próxima: [[Sequência 7 - Coletor de Cadáveres - Médium Espiritual]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
