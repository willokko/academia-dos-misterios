---
titulo: "Sequência 7 - Insone - Pesadelo"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Insone"
sequencia: 7
nome_ingles: "Nightmare"
---

# Sequência 7 - Insone - Pesadelo

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Insone]]. **Sequência:** 7. **Nome de referência:** Nightmare. Tradução editorial: Pesadelo.

## O que a poção transforma

O [[Poder - Insone S7 - Limiar de pesadelo|pacote completo de Pesadelo]] concede **1 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Estado de pesadelo.

- [[Poder - Insone S7 - Limiar de pesadelo#Entrar no sonho|Entrar no sonho]]
- [[Poder - Insone S7 - Limiar de pesadelo#Arrastar ao sonho|Arrastar ao sonho]]
- [[Poder - Insone S7 - Limiar de pesadelo#Membros do pesadelo|Membros do pesadelo]]



## Atuação e digestão

Interpretação original do papel **Pesadelo** no tema de noite, sono, espíritos e ocultação. Princípio de partida: velar por alguém sem vigiar todos os aspectos de sua vida. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Insone#S7 - Pesadelo]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 8 - Insone - Poeta da Meia-Noite]]. Próxima: [[Sequência 6 - Insone - Pacificador de Almas]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
