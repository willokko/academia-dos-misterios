---
titulo: "Sequência 3 - Espectador - Tecelão de Sonhos"
tipo: "caminhos"
origem: "misto"
estado: "experimental"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "altas-sequencias"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 3
nome_ingles: "Dream Weaver"
---

# Sequência 3 - Espectador - Tecelão de Sonhos

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 3. **Nome de referência:** Dream Weaver. Tradução editorial: Tecelão de Sonhos.

## O que a poção transforma

O [[Poder - Espectador S3 - Autoridade de Tecelão de Sonhos|pacote completo de Tecelão de Sonhos]] concede **1 capacidade(s) permanente(s) e 2 técnicas**, mais um feito de operação, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Transformação de Tecelão de Sonhos.

- [[Poder - Espectador S3 - Autoridade de Tecelão de Sonhos#Tecer sonho|Tecer sonho]]
- [[Poder - Espectador S3 - Autoridade de Tecelão de Sonhos#Manifestação onírica|Manifestação onírica]]

Operação: [[Poder - Espectador S3 - Autoridade de Tecelão de Sonhos#Feito de operação]].

## Atuação e digestão

Interpretação original do papel **Tecelão de Sonhos** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S3 - Tecelão de Sonhos]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 4 - Espectador - Manipulador]]. Próxima: [[Sequência 2 - Espectador - Discernidor]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
