---
titulo: "Sequência 6 - Espectador - Hipnotizador"
tipo: "caminhos"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "nome-de-sequencia"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
caminho: "Espectador"
sequencia: 6
nome_ingles: "Hypnotist"
---

# Sequência 6 - Espectador - Hipnotizador

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

**Caminho:** [[Caminho do Espectador]]. **Sequência:** 6. **Nome de referência:** Hypnotist. Tradução editorial: Hipnotizador.

## O que a poção transforma

O [[Poder - Espectador S6 - Sugestão de um gesto|pacote completo de Hipnotizador]] concede **2 capacidade(s) permanente(s) e 3 técnicas**, além do repertório anterior. As regras estão só na ficha vinculada; a lista abaixo serve de navegação.

**Capacidades:** Escamas dracônicas; Foco de hipnose.

- [[Poder - Espectador S6 - Sugestão de um gesto#Hipnose preparada|Hipnose preparada]]
- [[Poder - Espectador S6 - Sugestão de um gesto#Invisibilidade psicológica|Invisibilidade psicológica]]
- [[Poder - Espectador S6 - Sugestão de um gesto#Sugestão em conflito|Sugestão em conflito]]



## Atuação e digestão

Interpretação original do papel **Hipnotizador** no tema de observação, emoções, sonhos e construção mental. Princípio de partida: observar padrões, ajudar sem reduzir uma pessoa a um papel. Coloque-o em decisão real e refine por uma descoberta distinta. Não é receita canônica de atuação; [[Digestão e atuação]] é a referência de pontuação, e [[Maldições e humanidade]] distingue papel e identidade.

## Avanço e relações

[[Avanços do Espectador#S6 - Hipnotizador]] registra o estado da fórmula e rito; [[Progressão e Sequências]] contém pisos. Anterior: [[Sequência 7 - Espectador - Psiquiatra]]. Próxima: [[Sequência 5 - Espectador - Caminhante dos Sonhos]].

**Fonte e alcance:** [[Pesquisa da revisão 0.2]]. As técnicas são adaptação, não lista integral de capacidades canônicas.

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
