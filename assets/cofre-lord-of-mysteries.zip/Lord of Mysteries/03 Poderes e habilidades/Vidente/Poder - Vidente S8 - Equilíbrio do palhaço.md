---
titulo: "Poder - Vidente S8 - Equilíbrio do palhaço"
tipo: "poderes-e-habilidades"
origem: "adaptacao"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/adaptacao"]
caminho: "Vidente"
sequencia: 8
nome_pacote: "Pacote de Palhaço — Vidente S8"
quantidade_tecnicas: 3
quantidade_capacidades: 2
quantidade_operacoes: 0
---

# Poder - Vidente S8 - Equilíbrio do palhaço

> [!example] Adaptação original
> Regras não oficiais de Lord of Mysteries para Fabula Ultima. Revisão de projeto; ainda sem teste de mesa.

**Pacote completo — Palhaço, Vidente S8.** Recebe todas as capacidades e técnicas abaixo, além dos pacotes anteriores. Não escolha apenas uma.

**Requisito:** [[Sequência 8 - Vidente - Palhaço]] ou melhor no [[Caminho do Vidente]]. **Referência nominal:** Clown. **Regras:** [[Regras dos poderes]], [[Classes e identidade sobrenatural]].

> [!quote] Fonte e adaptação
> A identidade é inspirada na wiki do Caminho; nomes das técnicas, números, divisão e aplicações são originais. Não é catálogo canônico exaustivo. Conferência e lacunas: [[Pesquisa da revisão 0.2]].

## Capacidades permanentes

- **Corpo do palhaço:** Equilíbrio em apoio real e controle de expressão deixam de exigir teste em situações ordinárias. Sob oposição, +2 aos testes de DES para acrobacia; não é bônus universal de ataque.
- **Expressão escolhida:** Pode sorrir, chorar ou manter o rosto impassível apesar da emoção. Isso não cura medo nem apaga o que sente.

## Técnicas adquiridas

### Esquiva intuitiva

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Até o próximo turno |
| Teste | Automático |

Receba +2 DEF até o início do próximo turno.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Lâmina de papel

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Cena |
| Duração | Instantânea |
| Teste | DES+AST contra DEF |

Um alvo sofre RA+10 de dano físico em sucesso. Exige papel ao alcance; ele vira projétil cortante e depois perde a rigidez.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

### Contorção e saída

| Parâmetro | Regra |
|---|---|
| Custo | 5 PM |
| Ação | Poder |
| Alcance | Pessoal |
| Duração | Instantânea |
| Teste | DES+VIG ND10 sob risco |

Escape de amarras ordinárias ou atravesse um apoio estreito, incluindo reposicionar-se na mesma cena. Contra uma contenção sobrenatural, faça DES+VIG contra o teste do criador.

**Limites:** Uma aplicação por ação; exige alvo percebido e linha de efeito.

## Evolução e acúmulo

Na S7, contorção também permite atravessar uma abertura de tamanho compatível com a cabeça. Na S6, a máscara física conserva o controle de expressão; roupa e memórias continuam relevantes.

## Preparação e oposição

Ocultação de vínculos, identidades verificadas por relações e interrupção de preparação. São pistas de oposição, não penalidades universais ou imunidades inventadas. Um efeito que envolve mente ou corpo de PJ segue [[Controle mental e agência]]; repertórios e ajudantes seguem [[Servos e repertórios]]. Registre fonte, alvo, preparo e o que rompe o efeito. Forma mítica e diferenças de patamar seguem [[Escala e confrontos sobrenaturais]].

**Poção e rito:** [[Avanços do Vidente]]. **Atuação:** [[Digestão e atuação]].


Estados e recursos relacionados: [[Condições]] · [[Corrupção]] · [[Recursos e descanso]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
