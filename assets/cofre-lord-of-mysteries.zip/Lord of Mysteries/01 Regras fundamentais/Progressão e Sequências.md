---
titulo: "Progressão e Sequências"
tipo: "regras-fundamentais"
origem: "misto"
estado: "revisado-teoricamente"
validacao: "sem-teste-de-mesa"
publico: "jogadores"
spoilers: "regras"
versao: "0.2.0"
atualizado: "2026-10-21"
tags: ["lotm-fu", "publico/jogadores", "origem/misto"]
---

# Progressão e Sequências

> [!abstract] Natureza do conteúdo
> Os blocos identificam cânone, regra oficial e adaptação. Consulte [[Como usar este cofre]] e [[Limitações e pendências]].

## Experiência e poções

Níveis e EXP usam o básico: 10 EXP por nível, no máximo um nível ao fechar uma sessão, limite 50, dez níveis por classe e no máximo três classes não dominadas. Dados básicos crescem nos níveis 20 e 40. A recompensa oficial de sessão continua 5 EXP, somada aos Pontos de Ultima gastos e à parcela de Fabula calculada pelo básico. Digestão não substitui EXP.

A tabela abaixo é uma **convenção original revisada**, não equivalência literal com FU ou escala canônica de dano. Distribui a campanha sem reservar todas as altas Sequências ao nível 50. O tipo de desafio muda apesar de o motor de classes continuar.

| Sequência | Nível mínimo | Faixa de referência | Modo de jogo |
|---|---:|---|---|
| 9 | 5 | 5–9 | Baixa Sequência: investigação e capacidades iniciais |
| 8 | 10 | 10–14 | Baixa Sequência: domínio do ofício |
| 7 | 15 | 15–19 | Média Sequência: especialização sobrenatural |
| 6 | 20 | 20–24 | Média Sequência: preparação e alterações profundas |
| 5 | 25 | 25–29 | Média Sequência: repertórios, formas e influência |
| 4 | 30 | 30–34 | Santos e manifestações de escala superior |
| 3 | 35 | 35–39 | Santos e domínio coletivo |
| 2 | 40 | 40–44 | Anjos, âncoras e operações |
| 1 | 45 | 45–49 | Autoridades e conflitos de vínculos |
| 0 | 50 | Epílogo ou domínio | Divindade; ascensão por requisitos materiais reais |

O nível é piso, não poção automática. Ainda precisa de digestão, fórmula, característica e rito. Pode continuar subindo níveis sem promoção. Prepare oportunidades para todos no mesmo arco; diferenças temporárias de um grau não justificam apagar a potência conquistada ou compensar com bônus permanentes.

## Acúmulo e transformação

Recebe o pacote inteiro de cada grau e mantém os anteriores, além das evoluções impressas. Não aumenta atributos, PV ou PM automaticamente por beber. Capacidades corporais e espirituais vêm dos textos: asas, incorporeidade, sentidos, proteção e repertórios. Nas S4–0 ainda pode ganhar níveis de classe, mas estatísticas de nível não descrevem sozinhas sua escala.

## Mudanças de Caminho

Existem vizinhanças e pontos de troca diferentes na obra. **Convenção desta edição:** troca somente ao entrar na S3, entre vizinhos do mesmo grupo abaixo. É simplificação conservadora, não regra canônica universal. Exige fórmula, característica compatível, rito, nova Digestão 0/8 e +1 Corrupção. Mantém pacotes adquiridos; ganha só o pacote do destino, sem a árvore inteira retroativa.

| Grupo de troca usado | Caminhos |
|---|---|
| Mistérios | Vidente, Saqueador, Aprendiz |
| Onipotência | Espectador, Marinheiro, Bardo, Leitor, Suplicante de Segredos |
| Escuridão | Insone, Coletor de Cadáveres, Guerreiro |
| Calamidade | Assassino, Caçador |
| Conhecimento | Espreitador de Mistérios, Sábio |
| Vida | Boticário, Plantador |
| Desejo e prisão | Prisioneiro, Criminoso |
| Ordem | Advogado, Árbitro |
| Destino | Monstro; sem troca habilitada |

CoI e grupos adicionais não ampliam essa regra automaticamente. Veja [[Pesquisa da revisão 0.2]], [[Módulo dos santos]] e [[Módulo angelical e divino]].

---
Navegação: [[Início]] · [[Índice geral]] · [[Glossário]]
